﻿<!doctype html>
<html manifest="urepublicana.appcache">
<head>
  

<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '135599650420182');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=135599650420182&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->

 <!-- Global site tag (gtag.js) - Google Analytics -->



   <script async src="https://www.googletagmanager.com/gtag/js?id=UA-107902131-1"></script>




 <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-107902131-1');
  </script>

    <meta charset="UTF-8">
  <title>Corporación Universitaria Republicana - publicaciones.php</title>
 
<meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />
 <meta name="description" content=" Formar más colombianos sociales, ética y científicamente"  lang="es-ES">


<meta name="keywords"  content="pregrado, postgrado, derecho, ingenierías, trabajo social, contaduría pública, finanzas y comercio internacional, Matemáticas, Posgrados bogota, Pregrados bogotá"  lang="es-ES">


  <meta name="viewport" content="initial-scale=1, maximum-scale=1">
  <link rel="shortcut icon" href="//urepublicana.edu.co/images/web/logo.png">


  <link href="//urepublicana.edu.co/assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="//urepublicana.edu.co/assets/css/bootstrap-colorpicker.min.css" rel="stylesheet">
  
  <!-- Styles of this template -->


  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet"> 
  <link rel="stylesheet" href="//urepublicana.edu.co/assets/css/slider.min.css" type="text/css">
  <!-- LayerSlider styles -->

  <link rel="stylesheet" href="//urepublicana.edu.co/assets/slider/css/layerslider.css" type="text/css">
  <!-- External libraries: jQuery & GreenSock -->
  <script src="//urepublicana.edu.co/assets/slider/js/jquery.min.js" type="text/javascript"></script>
  <script src="//urepublicana.edu.co/assets/slider/js/greensock.min.js"></script>
  <!-- LayerSlider script files -->
  <script src="//urepublicana.edu.co/assets/slider/js/layerslider.transitions.min.js" type="text/javascript"></script>
  <script src="//urepublicana.edu.co/assets/slider/js/layerslider.kreaturamedia.jquery.min.js" type="text/javascript"></script>
  <!-- LayerSlider Popup plugin files -->
  <link rel="stylesheet" href="//urepublicana.edu.co/assets/slider/plugins/origami/layerslider.origami.css" type="text/css">
  <script src="//urepublicana.edu.co/assets/slider/plugins/origami/layerslider.origami.js" type="text/javascript"></script>


  <!-- MATERIALIZE -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="//urepublicana.edu.co/assets/css/materialize.min.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <!-- STYLE -->
  <link href="//urepublicana.edu.co/assets/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  
<style>

body{
	background: #ffffff;
}

h3{
	color: black;
}

h4{
	color: black;
}

.resumen_noticia{
	color: black;
}

.noticia > p{
	color: black;
}

.legal{
	color: black;
	background: #ffffff;
}

.contenido_noticia{
	color: black;
}

.titulo_menu{
	color: #000000 !important; 	
}

.card{
	background: #ffffff;
}

.card-reveal{
	background: #ffffff !important;
}

.tipo_urep{
	color: #a2121c;
	font-family: ;
}

.breadcrumb::before {
    content: '' !important;
}

	/*====================== HEADER */

.tipo_urep{
	font-family: Pinyon Script, cursive;
}

.menu_admin {
	background: linear-gradient(#ffffff87, #fffffff7) !important;	
}

.menu_admin a{
	color: #000000 !important; 	
}

#main_menu{
	background: linear-gradient(#ffffff87, #fffffff7);
}

#menu_mobile{
background: linear-gradient(#ffffff87, #fffffff7);
}

.side-nav li > a {
	color: #000000; 
}

.nav_main a{
	color: #000000; 
}

.nav_aux > li >a{
	color: #000000;
}

.nav_main a:hover{
	color: #a2121c;
}

.menu_all a:hover {
	color: #a2121c;
}

.nav_urep li {
	float: right;
}

.logo_urep{
	float: right !important;
}

.menu_nav{
  padding: 10px 5px !important;
}


/*====================== DESCRIPCION */

.legal_urep{
	color: ;
}



/*====================== ENLACES - BOTONES */

/*====================== NOTICIAS */

.noticia > a{
	color: #a2121c;
	border: 1px solid #a2121c;
}

.noticia > a:hover{
	background-color:#a2121c;
}

.urep_divide {
	border-bottom: solid 15px #a2121c;
}

#btn_menu i{
color: #000000;
}

.noticia > h5 > a{
	color: #a2121c;
}

.more_info{
	color: #a2121c;
}

#solicita_info{
border: 1px solid #a2121c;
}

#btn_informacion{
background-color: #a2121c;
}

#btn_informacion a{
background-color: #a2121c;
}

#btn_informacion a > i{
background-color: #a2121c;
}

.boton_urep{
	background-color: #a2121c;
}

.boton_urep:hover{
	background-color: white;
	color: #a2121c;
	border: 1px solid #a2121c;
}

.noticias_all > div > div > h5 > a{
	color: #a2121c;
}

.leer_mas{
	border: 1px solid #a2121c;
}

.enlace_inter{
	background: #a2121c;
}

.tab > a {
	color: #a2121c !important;
}

.content_inter li b{
	color: #a2121c;
}

.card-action a{
	color: #a2121c !important;
}

.enlace{
	color: #a2121c !important;   
}

.owl-theme .owl-dots .owl-dot.active span, .owl-theme .owl-dots .owl-dot:hover span {
	background: #a2121c;
}

.owl-theme .owl-nav [class*='owl-'] {
	background: #a2121c;
}

.owl-theme .owl-nav [class*='owl-']:hover {
	background:  #a2121c;
}

.footer-copyright{
	background-color: #A2121C;
}

.footer-copyright a{
	color: white;
}

.enlaces_urep{
	color: white;
}

.contacto{
	color: white;
	background-color: #262626;
}


</style>

  <!-- CARRUSEL -->
  <link rel="stylesheet" href="//urepublicana.edu.co/assets/owlcarousel/owl.carousel.css">
  <script src="//urepublicana.edu.co/assets/owlcarousel/owl.carousel.min.js"></script>

  <!-- ANIMATE -->
  <!-- <link rel="stylesheet" href="//urepublicana.edu.co/assets/css/animate.min.css"> -->

  <!-- TEXT -->
  <script src="//urepublicana.edu.co/assets/nic_edit/nicEdit.min.js" type="text/javascript"></script>
  <script type="text/javascript">
  	bkLib.onDomLoaded(function() {
  		new nicEditor({
  			buttonList : ['fontSize','fontFormat','indent','outdent','bold','italic','underline','underline','left','center','right','justify','html','ol','ul','link','unlink','xhtml']
  		}).panelInstance('noticia');
  	});
  </script>
</head>
<body id="body_urep">
  <div class="row" id="main_menu" style="width: 100%;">
      <!-- LOGO - DESCRIPCION -->
    <div class="col s4 m2 l2 right-align menu_nav">
      <a href="//urepublicana.edu.co/pages/"> <img src="//urepublicana.edu.co/images/web/logo.png" class="logo_urep"> </a>
    </div>
    <div class="col s6 m9 l4 left-align menu_nav">
      <div style="display:inline-block;">
        <h1 class="tipo_urep" style="width: 100%; " >Corporación Universitaria Republicana</h1>
        <center><p class="legal_urep"><b>Resolución No. 3061 del 02 de Diciembre de 1999 Min. Educación.<br>
Formamos más Colombianos ética, social y cientificamente
</b>
<br>Iesus Christus hanc dat fructum. Gloria in sancta Trinitate.<br> Et providere nos, misericordem gloriam Dei vivi</p></center>
      </div>
    </div>
    <!-- FIN - LOGO DESCRIPCION -->
      <!-- MENU -->
  <div class="col s2 m1 l6">
    <div class="nav-wrapper">
      <a href="#" id="btn_menu" data-activates="menu_mobile" class="button-collapse"><i class="material-icons">menu</i></a>
      <!-- MOBILE MENU -->
      <ul id="menu_mobile" class="side-nav center-align">
        <a href="//urepublicana.edu.co/pages/"><img src="//urepublicana.edu.co/images/web/logo.png" width="30%"></a>
                    <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Nuestra Institución</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="//urepublicana.edu.co/pages/nosotros/" target="_self">Nosotros</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Estructura_Organizacional.pdf" target="_blank">Organigrama</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/PEI_.pdf" target="_blank">PEI</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/plan_de_desarrollo_2020_2026.pdf" target="_blank">Plan de Desarrollo Institucional</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Estatutos.pdf" target="">Estatutos Generales</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Estudiantil-Ag-30-de-2018.pdf" target="_blank">Reglamento Estudiantil</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Docente.pdf" target="_blank">Reglamento Docente</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/autoevaluacion_y_acreditacion.pdf" target="_blank">Auto Evaluación y Acreditación</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/eae/" target="_blank">Escuela de Altos Estudios</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/Politicas_financieras.pdf" target="_blank">Políticas Financieras</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/1654804160.pdf" target="_blank">Protocolo de Bioseguridad</a></li>
                                                <li><a href=" https://urepublicana.edu.co/images/documentos/derechos_pecuniaros_2024.pdf" target="_blank">Valores y Servicios Académicos 2024 (Acuerdo 226 Derechos Pecuniarios 2024)</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/matricula_financiera_valores_de_matricula_2024.pdf" target="_blank">Resolución Rectoral 2 2024 (Matrícula Financiera)</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/resolucion_030025_dic_2023.pdf" target="_blank">Resolución Educación Para el Trabajo y Desarrollo humano</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Estudiantes</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="//urepublicana.edu.co/images/documentos/estudiantes/requisitos_trabajo_profundizacion_2020_actualizado.pdf" target="_blank">Lineamientos Trabajo de Profundización</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/codigos_para_consignacion" target="_blank">Números de Cuenta y Códigos de Consignación</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/biblioteca.php" target="_blank">Biblioteca</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/centro_idiomas/" target="_self">Centro de Idiomas</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/publicaciones_urepublicana/" target="_blank">Publicaciones</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/calendario_académico_2024.pdf" target="_blank">Calendario académico 2024</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/eae/" target="_self">Escuela de Altos Estudios</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/1726771276.pdf" target="_blank">Resolución Rectoral 5</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect">Programas</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li class="no-padding">
                          <ul class="collapsible collapsible-accordion">
                            <li>
                              <a class="collapsible-header waves-effect">Pregrado</a>
                              <div class="collapsible-body nivel_3">
                                <ul>
                                                                        <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/derecho"> Derecho</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/matematicas"> Matemáticas</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/trabajo_social"> Trabajo Social</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/contaduria_publica"> Contaduría Pública</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/ingenieria_industrial"> Ingeniería Industrial</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/ingenieria_de_sistemas"> Ingeniería de Sistemas</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/finanzas_y_comercio_internacional"> Finanzas y Comercio Internacional</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/administracion_de_mercadeo_virtual"> Administración de Mercadeo Virtual</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/finanzas_y_comercio_internacional_virtual"> Finanzas y Comercio Internacional Virtual</a>
                                      </li>
                                                                      </ul>
                              </div>
                            </li>
                          </ul>
                        </li>
                                                <li class="no-padding">
                          <ul class="collapsible collapsible-accordion">
                            <li>
                              <a class="collapsible-header waves-effect">Posgrado</a>
                              <div class="collapsible-body nivel_3">
                                <ul>
                                                                        <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_publico"> Especialización en Derecho Público</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_comercial"> Especialización en Derecho Comercial</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_revisoria_fiscal"> Especialización en Revisoría Fiscal</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_de_familia"> Especialización en Derecho de Familia</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_tributario"> Especialización en Derecho Tributario</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializcion_en_gerencia_financiera"> Especialización en Gerencia Financiera</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_urbanistico"> Especialización en Derecho Urbanístico</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_contratacion_estatal"> Especialización en Contratación Estatal</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_notarial_y_de_registro"> Especialización en Derecho Notarial y de Registro</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_financiero_y_bursatil"> Especialización en Derecho Financiero y Bursátil</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_administrativo"> Especialización en Derecho Administrativo Virtual</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_procesal_constitucional"> Especialización en Derecho Procesal Constitucional</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_intervencion_y_gerencia_social"> Especialización en Intervención y Gerencia Social</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_laboral_y_seguridad_social"> Especialización en Derecho Laboral y Seguridad Social</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_ciencias_criminologicas_y_penales"> Especialización en Ciencias Criminológicas y Penales</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_responsabilidad_civil_y_del_estado"> Especialización en Responsabilidad Civil y del Estado</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_gerencia_de_instituciones_educativas"> Especialización en Gerencia de Instituciones Educativas</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_probatorio_procesal_y_oralidad_judicial"> Especialización en Derecho Probatorio, Procesal y Oralidad Judicial</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_la_responsabilidad_penal_del_servidor_publico_y_los_delitos_contra_la_administracion_publica"> Especialización en la Responsabilidad Penal del Servidor Público y los Delitos Contra la Administración Pública</a>
                                      </li>
                                                                      </ul>
                              </div>
                            </li>
                          </ul>
                        </li>
                                                <li class="no-padding">
                          <ul class="collapsible collapsible-accordion">
                            <li>
                              <a class="collapsible-header waves-effect">Educación Continua</a>
                              <div class="collapsible-body nivel_3">
                                <ul>
                                                                        <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_en_desarrollo_de_software_seguro"> Diplomado en Desarrollo de Software Seguro</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_en_docencia_universitaria_con_enfasis_en_tic"> Diplomado en Docencia Universitaria con Énfasis en TIC</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/Diplomado_de_insolvencia_de_persona_natural_no_comerciante"> Diplomado de Insolvencia de Persona Natural No Comerciante</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/Diplomado_en_gestion_educativa_en_el_contexto_de_la_participacion"> Diplomado en Gestión Educativa en el Contexto de la Participación</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_de_formacion_y_capacitacion_de_conciliadores_en_derecho"> Diplomado de Formación y Capacitación de Conciliadores en Derecho</a>
                                      </li>
                                                                      </ul>
                              </div>
                            </li>
                          </ul>
                        </li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="//urepublicana.edu.co/pages/bienestar/">Bienestar</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Docentes</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Docente.pdf" target="_blank">Reglamento Docente</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/eae/" target="_blank">Escuela de Altos Estudios</a></li>
                                                <li><a href="https://virtualrepublicana.com/" target="_blank">Campus Virtual</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Servicios</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="http://outlook.com/urepublicana.edu.co" target="_blank">Correo Electrónico</a></li>
                                                <li><a href="http://academiaurepublicana.org/ArKa/test/new_login.php" target="_blank">Consulta de Notas</a></li>
                                                <li><a href="https://academiaurepublicana.org/cur5/reporte1.php" target="_blank">Registro de Notas (Docente)</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/pagos_en_linea" target="_blank">Pagos en Línea</a></li>
                                                <li><a href="https://www.pagosvirtualesavvillas.com.co/personal/pagos/1620" target="_self">Pago en línea AV VILLAS</a></li>
                                                <li><a href=" https://urepublicana.edu.co/images/documentos/1683941661.pdf" target="_blank">Instructivo pagos en línea AV-VILLAS</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="https://republicanaradio.com/">Radio</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="//urepublicana.edu.co/pages/investigacion/">Investigación</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="//urepublicana.edu.co/pages/internacionalizacion/">Internacionalización</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="//urepublicana.edu.co/pages/egresados/">Egresados</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Autoevaluación</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="https://urepublicana.edu.co/images/documentos/autoevaluacion_y_acreditacion.pdf" target="_blank">Acreditación y Autoevaluación</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/autoevaluacion.pdf" target="_blank"> Modelo de Aseguramiento de la Calidad</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="https://urepublicana.edu.co/pages/ccaac/">Centro Conciliación</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                    <li><a href="#"><br></a></li>
        <li><a href="#"><br></a></li> 
      </ul>
      <!-- FIN MENU MOBILE -->
      <div class="row">
        <ul class="right nav_urep">
                        <li class="nav_main"><a class="enlace_menu" target="" href="#!" name="#70">Docentes</a></li>
                            <li class="nav_main"><a class="enlace_menu" target="" href="//urepublicana.edu.co/pages/bienestar/" name="URL_MASTER/pages/bienestar/">Bienestar</a></li>
                            <li class="nav_main"><a class="enlace_menu" target="" href="#programas" name="#programas">Programas</a></li>
                            <li class="nav_main"><a class="enlace_menu" target="" href="#!" name="#20">Estudiantes</a></li>
                            <li class="nav_main"><a class="enlace_menu" target="" href="#!" name="#10">Nuestra Institución</a></li>
                      </ul>
        <ul class="right nav_urep nav_aux">
                        <li><a class="enlace_menu" target="_self" href="https://urepublicana.edu.co/pages/ccaac/" name="https://urepublicana.edu.co/pages/ccaac/">Centro Conciliación</a></li>
                            <li><a class="enlace_menu" target="" href="#60" name="#60">Autoevaluación</a></li>
                            <li><a class="enlace_menu" target="" href="//urepublicana.edu.co/pages/egresados/" name="//urepublicana.edu.co/pages/egresados/">Egresados</a></li>
                            <li><a class="enlace_menu" target="" href="//urepublicana.edu.co/pages/internacionalizacion/" name="//urepublicana.edu.co/pages/internacionalizacion/">Internacionalización</a></li>
                            <li><a class="enlace_menu" target="" href="//urepublicana.edu.co/pages/investigacion/" name="//urepublicana.edu.co/pages/investigacion/">Investigación</a></li>
                            <li><a class="enlace_menu" target="_blank" href="https://republicanaradio.com/" name="https://republicanaradio.com/">Radio</a></li>
                            <li><a class="enlace_menu" target="" href="#50" name="#50">Servicios</a></li>
                      </ul>
      </div>
    </div>
  </div>
  <!-- FIN MENU -->

  
        <div id="70" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Docentes</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Docente.pdf">Reglamento Docente</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/eae/">Escuela de Altos Estudios</a></li>
                                                <li><a target="_blank" href="https://virtualrepublicana.com/">Campus Virtual</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Docentes.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
            <div id="60" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Autoevaluación</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/autoevaluacion_y_acreditacion.pdf">Acreditación y Autoevaluación</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/autoevaluacion.pdf"> Modelo de Aseguramiento de la Calidad</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Autoevaluación.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
            <div id="20" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Estudiantes</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/estudiantes/requisitos_trabajo_profundizacion_2020_actualizado.pdf">Lineamientos Trabajo de Profundización</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/codigos_para_consignacion">Números de Cuenta y Códigos de Consignación</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/biblioteca.php">Biblioteca</a></li>
                                                <li><a target="_self" href="https://urepublicana.edu.co/pages/centro_idiomas/">Centro de Idiomas</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/publicaciones_urepublicana/">Publicaciones</a></li>
                                                  </ul></div><div class="col m4"><ul>                        <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/calendario_académico_2024.pdf">Calendario académico 2024</a></li>
                                                <li><a target="_self" href="https://urepublicana.edu.co/pages/eae/">Escuela de Altos Estudios</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/1726771276.pdf">Resolución Rectoral 5</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Estudiantes.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
            <div id="10" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Nuestra Institución</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_self" href="//urepublicana.edu.co/pages/nosotros/">Nosotros</a></li>
                                                <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Estructura_Organizacional.pdf">Organigrama</a></li>
                                                <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/PEI_.pdf">PEI</a></li>
                                                <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/plan_de_desarrollo_2020_2026.pdf">Plan de Desarrollo Institucional</a></li>
                                                <li><a target="" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Estatutos.pdf">Estatutos Generales</a></li>
                                                  </ul></div><div class="col m4"><ul>                        <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Estudiantil-Ag-30-de-2018.pdf">Reglamento Estudiantil</a></li>
                                                <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Docente.pdf">Reglamento Docente</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/autoevaluacion_y_acreditacion.pdf">Auto Evaluación y Acreditación</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/eae/">Escuela de Altos Estudios</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/Politicas_financieras.pdf">Políticas Financieras</a></li>
                                                  </ul></div><div class="col m4"><ul>                        <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/1654804160.pdf">Protocolo de Bioseguridad</a></li>
                                                <li><a target="_blank" href=" https://urepublicana.edu.co/images/documentos/derechos_pecuniaros_2024.pdf">Valores y Servicios Académicos 2024 (Acuerdo 226 Derechos Pecuniarios 2024)</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/matricula_financiera_valores_de_matricula_2024.pdf">Resolución Rectoral 2 2024 (Matrícula Financiera)</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/resolucion_030025_dic_2023.pdf">Resolución Educación Para el Trabajo y Desarrollo humano</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Nuestra Institución.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
            <div id="50" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Servicios</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_blank" href="http://outlook.com/urepublicana.edu.co">Correo Electrónico</a></li>
                                                <li><a target="_blank" href="http://academiaurepublicana.org/ArKa/test/new_login.php">Consulta de Notas</a></li>
                                                <li><a target="_blank" href="https://academiaurepublicana.org/cur5/reporte1.php">Registro de Notas (Docente)</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/pagos_en_linea">Pagos en Línea</a></li>
                                                <li><a target="_self" href="https://www.pagosvirtualesavvillas.com.co/personal/pagos/1620">Pago en línea AV VILLAS</a></li>
                                                  </ul></div><div class="col m4"><ul>                        <li><a target="_blank" href=" https://urepublicana.edu.co/images/documentos/1683941661.pdf">Instructivo pagos en línea AV-VILLAS</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Servicios.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
      

  <!-- Programas -->
  <div id="programas" class="menu_det ocultar">
    <div class="menu_all">
      <div class="container"  >
        <div class="row">
          <h4 class="center-align" style="color:white !important;">Programas</h4>
          <div class="col m3">
            <ul>
                              <li><a class="enlace_menu_2" name="#prom_Profesional" href="#">Pregrado</a></li>
                              <li><a class="enlace_menu_2" name="#prom_Posgrado" href="#">Posgrado</a></li>
                              <li><a class="enlace_menu_2" name="#prom_Diplomado" href="#">Educación Continua</a></li>
                            <!-- <li><a class="enlace_menu_2" name="#prom_edcontinua" href="#">Educación Continuada</a></li> -->
            </ul>
          </div>
          <div class="col m9" >
                       <ul id="prom_Profesional" class="programas ocultar">
                                <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/derecho"> Derecho</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/matematicas"> Matemáticas</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/trabajo_social"> Trabajo Social</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/contaduria_publica"> Contaduría Pública</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/ingenieria_industrial"> Ingeniería Industrial</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/ingenieria_de_sistemas"> Ingeniería de Sistemas</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/finanzas_y_comercio_internacional"> Finanzas y Comercio Internacional</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/administracion_de_mercadeo_virtual"> Administración de Mercadeo Virtual</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/finanzas_y_comercio_internacional_virtual"> Finanzas y Comercio Internacional Virtual</a>
                  </li>
                   </div>
                              </ul>
                      <ul id="prom_Posgrado" class="programas ocultar">
                                <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_publico"> Especialización en Derecho Público</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_comercial"> Especialización en Derecho Comercial</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_revisoria_fiscal"> Especialización en Revisoría Fiscal</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_de_familia"> Especialización en Derecho de Familia</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_tributario"> Especialización en Derecho Tributario</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializcion_en_gerencia_financiera"> Especialización en Gerencia Financiera</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_urbanistico"> Especialización en Derecho Urbanístico</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_contratacion_estatal"> Especialización en Contratación Estatal</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_notarial_y_de_registro"> Especialización en Derecho Notarial y de Registro</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_financiero_y_bursatil"> Especialización en Derecho Financiero y Bursátil</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_administrativo"> Especialización en Derecho Administrativo Virtual</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_procesal_constitucional"> Especialización en Derecho Procesal Constitucional</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_intervencion_y_gerencia_social"> Especialización en Intervención y Gerencia Social</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_laboral_y_seguridad_social"> Especialización en Derecho Laboral y Seguridad Social</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_ciencias_criminologicas_y_penales"> Especialización en Ciencias Criminológicas y Penales</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_responsabilidad_civil_y_del_estado"> Especialización en Responsabilidad Civil y del Estado</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_gerencia_de_instituciones_educativas"> Especialización en Gerencia de Instituciones Educativas</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_probatorio_procesal_y_oralidad_judicial"> Especialización en Derecho Probatorio, Procesal y Oralidad Judicial</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_la_responsabilidad_penal_del_servidor_publico_y_los_delitos_contra_la_administracion_publica"> Especialización en la Responsabilidad Penal del Servidor Público y los Delitos Contra la Administración Pública</a>
                  </li>
                   </div>
                              </ul>
                      <ul id="prom_Diplomado" class="programas ocultar">
                                <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_en_desarrollo_de_software_seguro"> Diplomado en Desarrollo de Software Seguro</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_en_docencia_universitaria_con_enfasis_en_tic"> Diplomado en Docencia Universitaria con Énfasis en TIC</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/Diplomado_de_insolvencia_de_persona_natural_no_comerciante"> Diplomado de Insolvencia de Persona Natural No Comerciante</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/Diplomado_en_gestion_educativa_en_el_contexto_de_la_participacion"> Diplomado en Gestión Educativa en el Contexto de la Participación</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_de_formacion_y_capacitacion_de_conciliadores_en_derecho"> Diplomado de Formación y Capacitación de Conciliadores en Derecho</a>
                  </li>
                   </div>
                              </ul>
                    <!-- 
          <ul id="prom_edcontinua" class="programas ocultar" >
            <li><a target="_blank" href="http://urepublicana.edu.co/contratacion-estatal/">Contratación Estatal</a></li>
            <li><a target="_blank" href="http://urepublicana.edu.co/educacion-continuada/derecho-disciplinario-colombiano/">Derecho Disciplinario Colombiano</a></li>
            <li><a target="_blank" href="http://urepublicana.edu.co/educacion-continuada/regimen-disciplinario-de-las-fuerzas-militares/">Regimen Disciplinario de las Fuerzas Militares</a></li>
            <li><a target="_blank" href="http://urepublicana.edu.co/educacion-continuada/diplomado-en-formacion-y-capacitacion-de-conciliadores/">Diplomado en Formación y Capacitación de Conciliadores</a></li>
          </ul>
        -->
      </div>
     <!-- <div class="col m2">
        <img src="//urepublicana.edu.co/images/web/menu/Programas.png" width="100%">
      </div>  -->
    </div>
  </div>


</div>
</div>
</div>
  <div class="breadcrumb"><a href="index.php"> Inicio </a> > <a href="publicaciones.php"> Publicaciones </a></div>
  <div class="container">
    <!--   Icon Section   -->
    <div class="row">
      <center>
        <h3> Conoce todas las Publicaciones </h3>
      </center>
      <div class="col s12 m4">
        <div class="card horizontal">
          <div class="card-image" style="height:200px;" >
            <a class="enlace" href="//urepublicana.edu.co/pages/gaceta/" >
              <img src="//urepublicana.edu.co/images/web/atajos/gaceta.png" name="//urepublicana.edu.co/images/web/atajos/gaceta_1.png" class="img_card atajo">
            </a>
          </div>
          <div class="card-stacked">
            <div class="card-content">
              <p class="titulo_card mayus">Gaceta</p>
            </div>
            <div class="card-action">
              <a class="enlace" href="//urepublicana.edu.co/pages/gaceta/" >Más información</a>
            </div>
          </div>
        </div>
      </div>
      <div class="col s12 m4">
        <div class="card horizontal" style="height:200px;" >
          <div class="card-image">
            <a class="enlace" target="_blank" href="http://ojs.urepublicana.edu.co/index.php/">
              <img src="//urepublicana.edu.co/images/web/atajos/revista.png" name="//urepublicana.edu.co/images/web/atajos/revista_1.png"  class="img_card atajo">
            </a>
          </div>
          <div class="card-stacked">
            <div class="card-content">
              <p class="titulo_card mayus">Revistas Republicana</p>
            </div>
            <div class="card-action">
              <a class="enlace" target="_blank" href="http://ojs.urepublicana.edu.co/index.php/">Más información</a>
            </div>
          </div>
        </div>
      </div>
      <div class="col s12 m4">
        <div class="card horizontal">
          <div class="card-image" style="height:200px;">
            <a class="enlace" href="//urepublicana.edu.co/pages/libros.php" >
              <img src="//urepublicana.edu.co/images/web/atajos/libro.png" name="//urepublicana.edu.co/images/web/atajos/libro_1.png"  class="img_card atajo">
            </a>
          </div>
          <div class="card-stacked">
            <div class="card-content">
              <p class="titulo_card mayus">Libros Electrónicos</p>
            </div>
            <div class="card-action">
              <a class="enlace" href="//urepublicana.edu.co/pages/libros.php" >Más información</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <br><br>
  </div>
  <div class="footer-copyright">
  <div class="container">
   <div class="row">
    <div class="col s12 m3 l3 center-align">
      <img src="//urepublicana.edu.co/images/web/footer/1521576084.png" class="logo_footer"><br>
      <i class="contacto" style="background-color: transparent;">
        Iesus Christus hanc dat fructum. Gloria in sancta Trinitate. Et providere nos, misericordem gloriam Dei vivi       </i>
    </div>
    <div class="col s12 m9 l9">
      <div class="row center-align">
        
<a target="_blank" href="https://www.facebook.com/CorporacionUniversitariaRepublicana/" ><img src="//urepublicana.edu.co/images/web/footer/facebook.png" class="social_urep"></a>

<a target="_blank" href="https://twitter.com/URepublicana_?lang=en" ><img src="//urepublicana.edu.co/images/web/footer/twitter.png" class="social_urep"></a>

<a target="_blank" href="https://www.instagram.com/urepublicana/" ><img src="//urepublicana.edu.co/images/web/footer/instagram.png" class="social_urep"></a>

<a target="_blank" href="https://www.youtube.com/channel/UC38BS2DLRSwXvnS_6QnS5Zg" ><img src="//urepublicana.edu.co/images/web/footer/youtube.png" class="social_urep"></a>

<a target="_blank" href="https://www.linkedin.com/in/corporaci%C3%B3n-universitaria-republicana-6bb35110b" ><img src="//urepublicana.edu.co/images/web/footer/linkedin.png" class="social_urep"></a>


<!-- <a target="_blank" href="https://api.whatsapp.com/send?phone=573057498050"><img src="//urepublicana.edu.co/images/web/footer/whatsapp.png" class="social_urep"></a> -->
      </div>
      <div class="left-align row enlaces_urep">
       <div class="col s12 m6 l4">
        <ul>
                        <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/1649868637.pdf">Ley de Protección de datos</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="http://urepublicana.edu.co/trabaje_con_nosotros/">Trabaje con Nosotros</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/codigos_para_consignacion">Listado Códigos de Consignaciones</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/iberoamericana/pages/publicaciones/Institucion/0/nosotros">Convenio Corporación Iberoamericana de Estudios Jurídicos</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/1674235905.pdf">Protocolo para la prevención y atención de casos de violencia y equidad de género</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/footer/directorio_institucional.pdf">Directorio Institucional</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/pages/ccaac/">Centro de Conciliación, Arbitraje y Amigable Composición</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                        </ul>
      </div>
    </div>
  </div>
</div>
</div>
<div class="row center-align contacto">
 Institución de Educación Superior Sujeta a Inspección y Vigilancia por el Ministerio de Educación Nacional, con Personería jurídica reconocida mediante resolución No 3061 del 02 de diciembre de 1999, expedida por el Ministerio de Educación Nacional.<br>  Sede Administrativa: Cr 7 No 19-38 | Horario de atención. lunes a viernes de 8:00 a.m a 8:00 p.m, Sábados:9:00 a.m a 1:00 p.m <br>  PBX: 286 23 84 | Información Admisiones: ext. 143 | www.urepublicana.edu.co <br>  Bogotá, Colombia</div>
<div class="center-align legal">
 &copy; Corporación Universitaria Republicana 2017
</div>
<!-- <script src="http://code.jquery.com/jquery-2.1.4.min.js"></script> -->
<!-- <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script> -->
<script src="//urepublicana.edu.co/assets/js/bootstrap-colorpicker.js"></script>
<script src="//urepublicana.edu.co/assets/js/docs.js"></script>
<!-- VALIDACION -->
<!-- <script src="//urepublicana.edu.co/assets/js/jquery.validate.min.js"></script> -->

<!-- JQUERY VALIDATE -->
<script type="text/javascript" src="//urepublicana.edu.co/assets/js/validation/dist/jquery.validate.min.js"></script>
<script src="//urepublicana.edu.co/assets/js/materialize.min.js"></script>
<script src="//urepublicana.edu.co/assets/js/init.js"></script>
<script type="text/javascript">
  function downloadJSAtOnload() {
    var element = document.createElement("script");
    element.src = "https://www.google.com/recaptcha/api.js";
    document.body.appendChild(element);
  }
  if (window.addEventListener)
    window.addEventListener("load", downloadJSAtOnload, false);
  else if (window.attachEvent)
    window.attachEvent("onload", downloadJSAtOnload);
  else window.onload = downloadJSAtOnload;
</script>




<script type="text/javascript" charset="utf-8">

	function correctCaptcha(){
     	$('button.btn_captcha').removeAttr("disabled");
    }
    
	$(document).ready(function(){
		$('button.btn_captcha').attr("disabled","disabled");
		
	// parametros( ids - separados por comas )
	var mostrar = function(ids) {
		var id = ids.split(',');
		jQuery.each( id, function( i, val ) {
			$("#cont_"+val).addClass("mostrar").removeClass("ocultar");
			$("#"+val).addClass("mostrar").removeClass("ocultar");
		});
	};


	// parametros(destino, consulta, valor);
	var cargar_valores = function(clase, metodo, valores) {
		var formData = {clase:clase,metodo:metodo,valores:valores};
		var url = "//urepublicana.edu.co/admin/class/class_metodos_form.php"; // El script a dónde se realizará la petición.
		$.ajax({
		type: "POST",
		url: url,
		async: false,
		data: formData,
			success: function(data){
			valores = jQuery.parseJSON(data);
			}
		});
		return valores;
	};

	// CARGAR VALIDACION INICIAL
	$( "#").validate( {
		rules: {
		//fin de la prueba de validación
		},
		errorElement : 'div',
		errorPlacement: function(error, element) {
			var placement = $(element).data('error');
			if (placement) {
				$(placement).append(error)
			} else {
				error.insertAfter(element);
			}
		}
	});
});
</script>
</body>
</html>

<!doctype html>
<html>
<head>
	

<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '135599650420182');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=135599650420182&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->

 <!-- Global site tag (gtag.js) - Google Analytics -->



   <script async src="https://www.googletagmanager.com/gtag/js?id=UA-107902131-1"></script>




 <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-107902131-1');
  </script>

    <meta charset="UTF-8">
  <title>Corporación Universitaria Republicana - Página Principal</title>
 
<meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />
 <meta name="description" content=" Formar más colombianos sociales, ética y científicamente"  lang="es-ES">


<meta name="keywords"  content="pregrado, postgrado, derecho, ingenierías, trabajo social, contaduría pública, finanzas y comercio internacional, Matemáticas, Posgrados bogota, Pregrados bogotá"  lang="es-ES">


  <meta name="viewport" content="initial-scale=1, maximum-scale=1">
  <link rel="shortcut icon" href="//urepublicana.edu.co/images/web/logo.png">


  <link href="//urepublicana.edu.co/assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="//urepublicana.edu.co/assets/css/bootstrap-colorpicker.min.css" rel="stylesheet">
  
  <!-- Styles of this template -->


  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet"> 
  <link rel="stylesheet" href="//urepublicana.edu.co/assets/css/slider.min.css" type="text/css">
  <!-- LayerSlider styles -->

  <link rel="stylesheet" href="//urepublicana.edu.co/assets/slider/css/layerslider.css" type="text/css">
  <!-- External libraries: jQuery & GreenSock -->
  <script src="//urepublicana.edu.co/assets/slider/js/jquery.min.js" type="text/javascript"></script>
  <script src="//urepublicana.edu.co/assets/slider/js/greensock.min.js"></script>
  <!-- LayerSlider script files -->
  <script src="//urepublicana.edu.co/assets/slider/js/layerslider.transitions.min.js" type="text/javascript"></script>
  <script src="//urepublicana.edu.co/assets/slider/js/layerslider.kreaturamedia.jquery.min.js" type="text/javascript"></script>
  <!-- LayerSlider Popup plugin files -->
  <link rel="stylesheet" href="//urepublicana.edu.co/assets/slider/plugins/origami/layerslider.origami.css" type="text/css">
  <script src="//urepublicana.edu.co/assets/slider/plugins/origami/layerslider.origami.js" type="text/javascript"></script>


  <!-- MATERIALIZE -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="//urepublicana.edu.co/assets/css/materialize.min.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <!-- STYLE -->
  <link href="//urepublicana.edu.co/assets/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  
<style>

body{
	background: #ffffff;
}

h3{
	color: black;
}

h4{
	color: black;
}

.resumen_noticia{
	color: black;
}

.noticia > p{
	color: black;
}

.legal{
	color: black;
	background: #ffffff;
}

.contenido_noticia{
	color: black;
}

.titulo_menu{
	color: #000000 !important; 	
}

.card{
	background: #ffffff;
}

.card-reveal{
	background: #ffffff !important;
}

.tipo_urep{
	color: #a2121c;
	font-family: ;
}

.breadcrumb::before {
    content: '' !important;
}

	/*====================== HEADER */

.tipo_urep{
	font-family: Pinyon Script, cursive;
}

.menu_admin {
	background: linear-gradient(#ffffff87, #fffffff7) !important;	
}

.menu_admin a{
	color: #000000 !important; 	
}

#main_menu{
	background: linear-gradient(#ffffff87, #fffffff7);
}

#menu_mobile{
background: linear-gradient(#ffffff87, #fffffff7);
}

.side-nav li > a {
	color: #000000; 
}

.nav_main a{
	color: #000000; 
}

.nav_aux > li >a{
	color: #000000;
}

.nav_main a:hover{
	color: #a2121c;
}

.menu_all a:hover {
	color: #a2121c;
}

.nav_urep li {
	float: right;
}

.logo_urep{
	float: right !important;
}

.menu_nav{
  padding: 10px 5px !important;
}


/*====================== DESCRIPCION */

.legal_urep{
	color: ;
}



/*====================== ENLACES - BOTONES */

/*====================== NOTICIAS */

.noticia > a{
	color: #a2121c;
	border: 1px solid #a2121c;
}

.noticia > a:hover{
	background-color:#a2121c;
}

.urep_divide {
	border-bottom: solid 15px #a2121c;
}

#btn_menu i{
color: #000000;
}

.noticia > h5 > a{
	color: #a2121c;
}

.more_info{
	color: #a2121c;
}

#solicita_info{
border: 1px solid #a2121c;
}

#btn_informacion{
background-color: #a2121c;
}

#btn_informacion a{
background-color: #a2121c;
}

#btn_informacion a > i{
background-color: #a2121c;
}

.boton_urep{
	background-color: #a2121c;
}

.boton_urep:hover{
	background-color: white;
	color: #a2121c;
	border: 1px solid #a2121c;
}

.noticias_all > div > div > h5 > a{
	color: #a2121c;
}

.leer_mas{
	border: 1px solid #a2121c;
}

.enlace_inter{
	background: #a2121c;
}

.tab > a {
	color: #a2121c !important;
}

.content_inter li b{
	color: #a2121c;
}

.card-action a{
	color: #a2121c !important;
}

.enlace{
	color: #a2121c !important;   
}

.owl-theme .owl-dots .owl-dot.active span, .owl-theme .owl-dots .owl-dot:hover span {
	background: #a2121c;
}

.owl-theme .owl-nav [class*='owl-'] {
	background: #a2121c;
}

.owl-theme .owl-nav [class*='owl-']:hover {
	background:  #a2121c;
}

.footer-copyright{
	background-color: #A2121C;
}

.footer-copyright a{
	color: white;
}

.enlaces_urep{
	color: white;
}

.contacto{
	color: white;
	background-color: #262626;
}


</style>

  <!-- CARRUSEL -->
  <link rel="stylesheet" href="//urepublicana.edu.co/assets/owlcarousel/owl.carousel.css">
  <script src="//urepublicana.edu.co/assets/owlcarousel/owl.carousel.min.js"></script>

  <!-- ANIMATE -->
  <!-- <link rel="stylesheet" href="//urepublicana.edu.co/assets/css/animate.min.css"> -->

  <!-- TEXT -->
  <script src="//urepublicana.edu.co/assets/nic_edit/nicEdit.min.js" type="text/javascript"></script>
  <script type="text/javascript">
  	bkLib.onDomLoaded(function() {
  		new nicEditor({
  			buttonList : ['fontSize','fontFormat','indent','outdent','bold','italic','underline','underline','left','center','right','justify','html','ol','ul','link','unlink','xhtml']
  		}).panelInstance('noticia');
  	});
  </script>




</head>
<body id="body_urep">
<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/es_ES/sdk.js#xfbml=1&version=v17.0" nonce="lq2KzOUM"></script>

	<div class="row" id="main_menu" style="width: 100%;">
      <!-- LOGO - DESCRIPCION -->
    <div class="col s4 m2 l2 right-align menu_nav">
      <a href="//urepublicana.edu.co/pages/"> <img src="//urepublicana.edu.co/images/web/logo.png" class="logo_urep"> </a>
    </div>
    <div class="col s6 m9 l4 left-align menu_nav">
      <div style="display:inline-block;">
        <h1 class="tipo_urep" style="width: 100%; " >Corporación Universitaria Republicana</h1>
        <center><p class="legal_urep"><b>Resolución No. 3061 del 02 de Diciembre de 1999 Min. Educación.<br>
Formamos más Colombianos ética, social y cientificamente
</b>
<br>Iesus Christus hanc dat fructum. Gloria in sancta Trinitate.<br> Et providere nos, misericordem gloriam Dei vivi</p></center>
      </div>
    </div>
    <!-- FIN - LOGO DESCRIPCION -->
      <!-- MENU -->
  <div class="col s2 m1 l6">
    <div class="nav-wrapper">
      <a href="#" id="btn_menu" data-activates="menu_mobile" class="button-collapse"><i class="material-icons">menu</i></a>
      <!-- MOBILE MENU -->
      <ul id="menu_mobile" class="side-nav center-align">
        <a href="//urepublicana.edu.co/pages/"><img src="//urepublicana.edu.co/images/web/logo.png" width="30%"></a>
                    <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Nuestra Institución</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="//urepublicana.edu.co/pages/nosotros/" target="_self">Nosotros</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Estructura_Organizacional.pdf" target="_blank">Organigrama</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/PEI_.pdf" target="_blank">PEI</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/plan_de_desarrollo_2020_2026.pdf" target="_blank">Plan de Desarrollo Institucional</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Estatutos.pdf" target="">Estatutos Generales</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Estudiantil-Ag-30-de-2018.pdf" target="_blank">Reglamento Estudiantil</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Docente.pdf" target="_blank">Reglamento Docente</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/autoevaluacion_y_acreditacion.pdf" target="_blank">Auto Evaluación y Acreditación</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/eae/" target="_blank">Escuela de Altos Estudios</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/Politicas_financieras.pdf" target="_blank">Políticas Financieras</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/1654804160.pdf" target="_blank">Protocolo de Bioseguridad</a></li>
                                                <li><a href=" https://urepublicana.edu.co/images/documentos/derechos_pecuniaros_2024.pdf" target="_blank">Valores y Servicios Académicos 2024 (Acuerdo 226 Derechos Pecuniarios 2024)</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/matricula_financiera_valores_de_matricula_2024.pdf" target="_blank">Resolución Rectoral 2 2024 (Matrícula Financiera)</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/resolucion_030025_dic_2023.pdf" target="_blank">Resolución Educación Para el Trabajo y Desarrollo humano</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Estudiantes</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="//urepublicana.edu.co/images/documentos/estudiantes/requisitos_trabajo_profundizacion_2020_actualizado.pdf" target="_blank">Lineamientos Trabajo de Profundización</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/codigos_para_consignacion" target="_blank">Números de Cuenta y Códigos de Consignación</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/biblioteca.php" target="_blank">Biblioteca</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/centro_idiomas/" target="_self">Centro de Idiomas</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/publicaciones_urepublicana/" target="_blank">Publicaciones</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/calendario_académico_2024.pdf" target="_blank">Calendario académico 2024</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/eae/" target="_self">Escuela de Altos Estudios</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/1726771276.pdf" target="_blank">Resolución Rectoral 5</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect">Programas</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li class="no-padding">
                          <ul class="collapsible collapsible-accordion">
                            <li>
                              <a class="collapsible-header waves-effect">Pregrado</a>
                              <div class="collapsible-body nivel_3">
                                <ul>
                                                                        <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/derecho"> Derecho</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/matematicas"> Matemáticas</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/trabajo_social"> Trabajo Social</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/contaduria_publica"> Contaduría Pública</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/ingenieria_industrial"> Ingeniería Industrial</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/ingenieria_de_sistemas"> Ingeniería de Sistemas</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/finanzas_y_comercio_internacional"> Finanzas y Comercio Internacional</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/administracion_de_mercadeo_virtual"> Administración de Mercadeo Virtual</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/finanzas_y_comercio_internacional_virtual"> Finanzas y Comercio Internacional Virtual</a>
                                      </li>
                                                                      </ul>
                              </div>
                            </li>
                          </ul>
                        </li>
                                                <li class="no-padding">
                          <ul class="collapsible collapsible-accordion">
                            <li>
                              <a class="collapsible-header waves-effect">Posgrado</a>
                              <div class="collapsible-body nivel_3">
                                <ul>
                                                                        <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_publico"> Especialización en Derecho Público</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_comercial"> Especialización en Derecho Comercial</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_revisoria_fiscal"> Especialización en Revisoría Fiscal</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_de_familia"> Especialización en Derecho de Familia</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_tributario"> Especialización en Derecho Tributario</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializcion_en_gerencia_financiera"> Especialización en Gerencia Financiera</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_urbanistico"> Especialización en Derecho Urbanístico</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_contratacion_estatal"> Especialización en Contratación Estatal</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_notarial_y_de_registro"> Especialización en Derecho Notarial y de Registro</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_financiero_y_bursatil"> Especialización en Derecho Financiero y Bursátil</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_administrativo"> Especialización en Derecho Administrativo Virtual</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_procesal_constitucional"> Especialización en Derecho Procesal Constitucional</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_intervencion_y_gerencia_social"> Especialización en Intervención y Gerencia Social</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_laboral_y_seguridad_social"> Especialización en Derecho Laboral y Seguridad Social</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_ciencias_criminologicas_y_penales"> Especialización en Ciencias Criminológicas y Penales</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_responsabilidad_civil_y_del_estado"> Especialización en Responsabilidad Civil y del Estado</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_gerencia_de_instituciones_educativas"> Especialización en Gerencia de Instituciones Educativas</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_probatorio_procesal_y_oralidad_judicial"> Especialización en Derecho Probatorio, Procesal y Oralidad Judicial</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_la_responsabilidad_penal_del_servidor_publico_y_los_delitos_contra_la_administracion_publica"> Especialización en la Responsabilidad Penal del Servidor Público y los Delitos Contra la Administración Pública</a>
                                      </li>
                                                                      </ul>
                              </div>
                            </li>
                          </ul>
                        </li>
                                                <li class="no-padding">
                          <ul class="collapsible collapsible-accordion">
                            <li>
                              <a class="collapsible-header waves-effect">Educación Continua</a>
                              <div class="collapsible-body nivel_3">
                                <ul>
                                                                        <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_en_desarrollo_de_software_seguro"> Diplomado en Desarrollo de Software Seguro</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_en_docencia_universitaria_con_enfasis_en_tic"> Diplomado en Docencia Universitaria con Énfasis en TIC</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/Diplomado_de_insolvencia_de_persona_natural_no_comerciante"> Diplomado de Insolvencia de Persona Natural No Comerciante</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/Diplomado_en_gestion_educativa_en_el_contexto_de_la_participacion"> Diplomado en Gestión Educativa en el Contexto de la Participación</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_de_formacion_y_capacitacion_de_conciliadores_en_derecho"> Diplomado de Formación y Capacitación de Conciliadores en Derecho</a>
                                      </li>
                                                                      </ul>
                              </div>
                            </li>
                          </ul>
                        </li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="//urepublicana.edu.co/pages/bienestar/">Bienestar</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Docentes</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Docente.pdf" target="_blank">Reglamento Docente</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/eae/" target="_blank">Escuela de Altos Estudios</a></li>
                                                <li><a href="https://virtualrepublicana.com/" target="_blank">Campus Virtual</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Servicios</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="http://outlook.com/urepublicana.edu.co" target="_blank">Correo Electrónico</a></li>
                                                <li><a href="http://academiaurepublicana.org/ArKa/test/new_login.php" target="_blank">Consulta de Notas</a></li>
                                                <li><a href="https://academiaurepublicana.org/cur5/reporte1.php" target="_blank">Registro de Notas (Docente)</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/pagos_en_linea" target="_blank">Pagos en Línea</a></li>
                                                <li><a href="https://www.pagosvirtualesavvillas.com.co/personal/pagos/1620" target="_self">Pago en línea AV VILLAS</a></li>
                                                <li><a href=" https://urepublicana.edu.co/images/documentos/1683941661.pdf" target="_blank">Instructivo pagos en línea AV-VILLAS</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="https://republicanaradio.com/">Radio</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="//urepublicana.edu.co/pages/investigacion/">Investigación</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="//urepublicana.edu.co/pages/internacionalizacion/">Internacionalización</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="//urepublicana.edu.co/pages/egresados/">Egresados</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Autoevaluación</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="https://urepublicana.edu.co/images/documentos/autoevaluacion_y_acreditacion.pdf" target="_blank">Acreditación y Autoevaluación</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/autoevaluacion.pdf" target="_blank"> Modelo de Aseguramiento de la Calidad</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="https://urepublicana.edu.co/pages/ccaac/">Centro Conciliación</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                    <li><a href="#"><br></a></li>
        <li><a href="#"><br></a></li> 
      </ul>
      <!-- FIN MENU MOBILE -->
      <div class="row">
        <ul class="right nav_urep">
                        <li class="nav_main"><a class="enlace_menu" target="" href="#!" name="#70">Docentes</a></li>
                            <li class="nav_main"><a class="enlace_menu" target="" href="//urepublicana.edu.co/pages/bienestar/" name="URL_MASTER/pages/bienestar/">Bienestar</a></li>
                            <li class="nav_main"><a class="enlace_menu" target="" href="#programas" name="#programas">Programas</a></li>
                            <li class="nav_main"><a class="enlace_menu" target="" href="#!" name="#20">Estudiantes</a></li>
                            <li class="nav_main"><a class="enlace_menu" target="" href="#!" name="#10">Nuestra Institución</a></li>
                      </ul>
        <ul class="right nav_urep nav_aux">
                        <li><a class="enlace_menu" target="_self" href="https://urepublicana.edu.co/pages/ccaac/" name="https://urepublicana.edu.co/pages/ccaac/">Centro Conciliación</a></li>
                            <li><a class="enlace_menu" target="" href="#60" name="#60">Autoevaluación</a></li>
                            <li><a class="enlace_menu" target="" href="//urepublicana.edu.co/pages/egresados/" name="//urepublicana.edu.co/pages/egresados/">Egresados</a></li>
                            <li><a class="enlace_menu" target="" href="//urepublicana.edu.co/pages/internacionalizacion/" name="//urepublicana.edu.co/pages/internacionalizacion/">Internacionalización</a></li>
                            <li><a class="enlace_menu" target="" href="//urepublicana.edu.co/pages/investigacion/" name="//urepublicana.edu.co/pages/investigacion/">Investigación</a></li>
                            <li><a class="enlace_menu" target="_blank" href="https://republicanaradio.com/" name="https://republicanaradio.com/">Radio</a></li>
                            <li><a class="enlace_menu" target="" href="#50" name="#50">Servicios</a></li>
                      </ul>
      </div>
    </div>
  </div>
  <!-- FIN MENU -->

  
        <div id="70" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Docentes</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Docente.pdf">Reglamento Docente</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/eae/">Escuela de Altos Estudios</a></li>
                                                <li><a target="_blank" href="https://virtualrepublicana.com/">Campus Virtual</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Docentes.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
            <div id="60" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Autoevaluación</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/autoevaluacion_y_acreditacion.pdf">Acreditación y Autoevaluación</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/autoevaluacion.pdf"> Modelo de Aseguramiento de la Calidad</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Autoevaluación.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
            <div id="20" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Estudiantes</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/estudiantes/requisitos_trabajo_profundizacion_2020_actualizado.pdf">Lineamientos Trabajo de Profundización</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/codigos_para_consignacion">Números de Cuenta y Códigos de Consignación</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/biblioteca.php">Biblioteca</a></li>
                                                <li><a target="_self" href="https://urepublicana.edu.co/pages/centro_idiomas/">Centro de Idiomas</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/publicaciones_urepublicana/">Publicaciones</a></li>
                                                  </ul></div><div class="col m4"><ul>                        <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/calendario_académico_2024.pdf">Calendario académico 2024</a></li>
                                                <li><a target="_self" href="https://urepublicana.edu.co/pages/eae/">Escuela de Altos Estudios</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/1726771276.pdf">Resolución Rectoral 5</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Estudiantes.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
            <div id="10" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Nuestra Institución</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_self" href="//urepublicana.edu.co/pages/nosotros/">Nosotros</a></li>
                                                <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Estructura_Organizacional.pdf">Organigrama</a></li>
                                                <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/PEI_.pdf">PEI</a></li>
                                                <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/plan_de_desarrollo_2020_2026.pdf">Plan de Desarrollo Institucional</a></li>
                                                <li><a target="" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Estatutos.pdf">Estatutos Generales</a></li>
                                                  </ul></div><div class="col m4"><ul>                        <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Estudiantil-Ag-30-de-2018.pdf">Reglamento Estudiantil</a></li>
                                                <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Docente.pdf">Reglamento Docente</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/autoevaluacion_y_acreditacion.pdf">Auto Evaluación y Acreditación</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/eae/">Escuela de Altos Estudios</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/Politicas_financieras.pdf">Políticas Financieras</a></li>
                                                  </ul></div><div class="col m4"><ul>                        <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/1654804160.pdf">Protocolo de Bioseguridad</a></li>
                                                <li><a target="_blank" href=" https://urepublicana.edu.co/images/documentos/derechos_pecuniaros_2024.pdf">Valores y Servicios Académicos 2024 (Acuerdo 226 Derechos Pecuniarios 2024)</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/matricula_financiera_valores_de_matricula_2024.pdf">Resolución Rectoral 2 2024 (Matrícula Financiera)</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/resolucion_030025_dic_2023.pdf">Resolución Educación Para el Trabajo y Desarrollo humano</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Nuestra Institución.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
            <div id="50" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Servicios</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_blank" href="http://outlook.com/urepublicana.edu.co">Correo Electrónico</a></li>
                                                <li><a target="_blank" href="http://academiaurepublicana.org/ArKa/test/new_login.php">Consulta de Notas</a></li>
                                                <li><a target="_blank" href="https://academiaurepublicana.org/cur5/reporte1.php">Registro de Notas (Docente)</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/pagos_en_linea">Pagos en Línea</a></li>
                                                <li><a target="_self" href="https://www.pagosvirtualesavvillas.com.co/personal/pagos/1620">Pago en línea AV VILLAS</a></li>
                                                  </ul></div><div class="col m4"><ul>                        <li><a target="_blank" href=" https://urepublicana.edu.co/images/documentos/1683941661.pdf">Instructivo pagos en línea AV-VILLAS</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Servicios.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
      

  <!-- Programas -->
  <div id="programas" class="menu_det ocultar">
    <div class="menu_all">
      <div class="container"  >
        <div class="row">
          <h4 class="center-align" style="color:white !important;">Programas</h4>
          <div class="col m3">
            <ul>
                              <li><a class="enlace_menu_2" name="#prom_Profesional" href="#">Pregrado</a></li>
                              <li><a class="enlace_menu_2" name="#prom_Posgrado" href="#">Posgrado</a></li>
                              <li><a class="enlace_menu_2" name="#prom_Diplomado" href="#">Educación Continua</a></li>
                            <!-- <li><a class="enlace_menu_2" name="#prom_edcontinua" href="#">Educación Continuada</a></li> -->
            </ul>
          </div>
          <div class="col m9" >
                       <ul id="prom_Profesional" class="programas ocultar">
                                <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/derecho"> Derecho</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/matematicas"> Matemáticas</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/trabajo_social"> Trabajo Social</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/contaduria_publica"> Contaduría Pública</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/ingenieria_industrial"> Ingeniería Industrial</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/ingenieria_de_sistemas"> Ingeniería de Sistemas</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/finanzas_y_comercio_internacional"> Finanzas y Comercio Internacional</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/administracion_de_mercadeo_virtual"> Administración de Mercadeo Virtual</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/finanzas_y_comercio_internacional_virtual"> Finanzas y Comercio Internacional Virtual</a>
                  </li>
                   </div>
                              </ul>
                      <ul id="prom_Posgrado" class="programas ocultar">
                                <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_publico"> Especialización en Derecho Público</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_comercial"> Especialización en Derecho Comercial</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_revisoria_fiscal"> Especialización en Revisoría Fiscal</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_de_familia"> Especialización en Derecho de Familia</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_tributario"> Especialización en Derecho Tributario</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializcion_en_gerencia_financiera"> Especialización en Gerencia Financiera</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_urbanistico"> Especialización en Derecho Urbanístico</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_contratacion_estatal"> Especialización en Contratación Estatal</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_notarial_y_de_registro"> Especialización en Derecho Notarial y de Registro</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_financiero_y_bursatil"> Especialización en Derecho Financiero y Bursátil</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_administrativo"> Especialización en Derecho Administrativo Virtual</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_procesal_constitucional"> Especialización en Derecho Procesal Constitucional</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_intervencion_y_gerencia_social"> Especialización en Intervención y Gerencia Social</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_laboral_y_seguridad_social"> Especialización en Derecho Laboral y Seguridad Social</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_ciencias_criminologicas_y_penales"> Especialización en Ciencias Criminológicas y Penales</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_responsabilidad_civil_y_del_estado"> Especialización en Responsabilidad Civil y del Estado</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_gerencia_de_instituciones_educativas"> Especialización en Gerencia de Instituciones Educativas</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_probatorio_procesal_y_oralidad_judicial"> Especialización en Derecho Probatorio, Procesal y Oralidad Judicial</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_la_responsabilidad_penal_del_servidor_publico_y_los_delitos_contra_la_administracion_publica"> Especialización en la Responsabilidad Penal del Servidor Público y los Delitos Contra la Administración Pública</a>
                  </li>
                   </div>
                              </ul>
                      <ul id="prom_Diplomado" class="programas ocultar">
                                <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_en_desarrollo_de_software_seguro"> Diplomado en Desarrollo de Software Seguro</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_en_docencia_universitaria_con_enfasis_en_tic"> Diplomado en Docencia Universitaria con Énfasis en TIC</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/Diplomado_de_insolvencia_de_persona_natural_no_comerciante"> Diplomado de Insolvencia de Persona Natural No Comerciante</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/Diplomado_en_gestion_educativa_en_el_contexto_de_la_participacion"> Diplomado en Gestión Educativa en el Contexto de la Participación</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_de_formacion_y_capacitacion_de_conciliadores_en_derecho"> Diplomado de Formación y Capacitación de Conciliadores en Derecho</a>
                  </li>
                   </div>
                              </ul>
                    <!-- 
          <ul id="prom_edcontinua" class="programas ocultar" >
            <li><a target="_blank" href="http://urepublicana.edu.co/contratacion-estatal/">Contratación Estatal</a></li>
            <li><a target="_blank" href="http://urepublicana.edu.co/educacion-continuada/derecho-disciplinario-colombiano/">Derecho Disciplinario Colombiano</a></li>
            <li><a target="_blank" href="http://urepublicana.edu.co/educacion-continuada/regimen-disciplinario-de-las-fuerzas-militares/">Regimen Disciplinario de las Fuerzas Militares</a></li>
            <li><a target="_blank" href="http://urepublicana.edu.co/educacion-continuada/diplomado-en-formacion-y-capacitacion-de-conciliadores/">Diplomado en Formación y Capacitación de Conciliadores</a></li>
          </ul>
        -->
      </div>
     <!-- <div class="col m2">
        <img src="//urepublicana.edu.co/images/web/menu/Programas.png" width="100%">
      </div>  -->
    </div>
  </div>


</div>
</div>
</div>
				<div id="banner_intro" class="modal" style="background: rgba(162,18,28,0.5); !important; width:85% ">
				<a href="#" class="modal-action modal-close btn_cerrar_modal"  " ><i class="material-icons">highlight_off</i></a>
				<div class="modal-content center"  >
				<!--	<h3>INFORMACIÓN ACERCA DE REFERIDOS 2025-I</h3> -->
										<a href="https://urepublicana.edu.co/pages/publicaciones/principal/popup/informacion_acerca_de_referidos_2025i"><img src="//urepublicana.edu.co/images/noticias_eventos/1726875778.jpg" width="100%"></a>				</div>
			</div>
				<!-- 
	<div id="banner_intro" class="modal">
		<a href="#" class="modal-action modal-close btn_cerrar_modal"><i class="material-icons">highlight_off</i></a>
		<div class="modal-content center">
			<h3>TEST</h3>
			<iframe class="video" src="https://www.youtube.com/embed/V5OOfWAbdNk" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
		</div>
	</div>
-->
<!-- Modal Structure -->
<!-- FINAL MODAL -->
<!-- CONTENIDO -->
<div>
	<!-- SLIDER PRINCIPAL -->
	<div class="row">
		<div id="slider_main" class="largemargin" style="top:33px; width: 1350px !important; height: 450px !important;position:fixed"  >
									<div class="ls-slide"  data-ls="duration:5000;timeshift:-3000;transition2d:23;">
							<img style="border-radius:10px !important;"  src="//urepublicana.edu.co/images/noticias_eventos/1729781386.jpg" class="ls-bg">
							<a href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/matriculas_estudiantes_antiguos_2025i">
								<div class="ls-l div_info"></div>
							</a>
						</div>
												<div class="ls-slide"  data-ls="duration:5000;timeshift:-3000;transition2d:23;">
							<img style="border-radius:10px !important;"  src="//urepublicana.edu.co/images/noticias_eventos/1726875778.jpg" class="ls-bg">
							<a href="https://urepublicana.edu.co/pages/publicaciones/principal/popup/informacion_acerca_de_referidos_2025i">
								<div class="ls-l div_info"></div>
							</a>
						</div>
												<div class="ls-slide"  data-ls="duration:5000;timeshift:-3000;transition2d:23;">
							<img style="border-radius:10px !important;"  src="//urepublicana.edu.co/images/noticias_eventos/1726620534.jpg" class="ls-bg">
							<a href="https://urepublicana.edu.co/pages/admisiones/">
								<div class="ls-l div_info"></div>
							</a>
						</div>
												<div class="ls-slide"  data-ls="duration:5000;timeshift:-3000;transition2d:23;">
							<img style="border-radius:10px !important;"  src="//urepublicana.edu.co/images/noticias_eventos/1726620819.jpg" class="ls-bg">
							<a href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/inscripciones_abiertas_modalidad_acelerada_posgrados_2025i">
								<div class="ls-l div_info"></div>
							</a>
						</div>
												<div class="ls-slide"  data-ls="duration:5000;timeshift:-3000;transition2d:23;">
							<img style="border-radius:10px !important;"  src="//urepublicana.edu.co/images/noticias_eventos/1726621204.jpg" class="ls-bg">
							<a href="https://urepublicana.edu.co/pages/admisiones/?mod=pre">
								<div class="ls-l div_info"></div>
							</a>
						</div>
												<div class="ls-slide"  data-ls="duration:5000;timeshift:-3000;transition2d:23;">
							<img style="border-radius:10px !important;"  src="//urepublicana.edu.co/images/noticias_eventos/1726621452.jpg" class="ls-bg">
							<a href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/inscripciones_abiertas_para_la_modalidad_intensiva_35_de_la_facultad_de_derecho_2025i">
								<div class="ls-l div_info"></div>
							</a>
						</div>
												<div class="ls-slide"  data-ls="duration:5000;timeshift:-3000;transition2d:23;">
							<img style="border-radius:10px !important;"  src="//urepublicana.edu.co/images/noticias_eventos/1726621910.jpg" class="ls-bg">
							<a href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/inscripciones_abiertas_modalidad_especial_posgrados_2025i">
								<div class="ls-l div_info"></div>
							</a>
						</div>
												<div class="ls-slide"  data-ls="duration:5000;timeshift:-3000;transition2d:23;">
							<img style="border-radius:10px !important;"  src="//urepublicana.edu.co/images/noticias_eventos/1726622448.jpg" class="ls-bg">
							<a href="https://urepublicana.edu.co/pages/admisiones/?mod=con">
								<div class="ls-l div_info"></div>
							</a>
						</div>
								</div>
	</div>
<br><br>

	<!-- ENLACES RAPIDOS - ATAJOS -->
	<div class="row lnk_first"  >
					<div class="col m2 atajos_espacio"><br></div>
							<div class="col s3 m1">
					<a href="https://urepublicana.edu.co/pages/admisiones/">
						<img class="atajo" src="//urepublicana.edu.co/images/web/atajos/1712687049.png" name="//urepublicana.edu.co/images/web/atajos/1712687051.png">
						<p>Admisiones y Financiación</p>
					</a>
				</div>
								<div class="col s3 m1">
					<a href="https://urepublicana.edu.co/pages/centro_idiomas/">
						<img class="atajo" src="//urepublicana.edu.co/images/web/atajos/1717702607.png" name="//urepublicana.edu.co/images/web/atajos/1717702609.png">
						<p>Centro de Idiomas</p>
					</a>
				</div>
								<div class="col s3 m1">
					<a href="https://urepublicana.edu.co/convenio_de_descuentos_financieros/">
						<img class="atajo" src="//urepublicana.edu.co/images/web/atajos/1717702519.png" name="//urepublicana.edu.co/images/web/atajos/1717702521.png">
						<p>Convenios de Descuentos Financieros</p>
					</a>
				</div>
								<div class="col s3 m1">
					<a href="https://urepublicana.edu.co/convenio_sena/">
						<img class="atajo" src="//urepublicana.edu.co/images/web/atajos/1712687246.png" name="//urepublicana.edu.co/images/web/atajos/1712687248.png">
						<p>Convenio CADENA DE FORMACIÓN</p>
					</a>
				</div>
								<div class="col s3 m1">
					<a href="https://urepublicana.edu.co/alianza_urepublicana_fuerzas_armadas/">
						<img class="atajo" src="//urepublicana.edu.co/images/web/atajos/1712687295.png" name="//urepublicana.edu.co/images/web/atajos/1712687297.png">
						<p>Convenio fuerzas Armadas</p>
					</a>
				</div>
								<div class="col s3 m1">
					<a href="https://urepublicana.edu.co/convenio_policia_nacional/">
						<img class="atajo" src="//urepublicana.edu.co/images/web/atajos/1712687330.png" name="//urepublicana.edu.co/images/web/atajos/1712687332.png">
						<p>CONVENIO POLICIA NACIONAL</p>
					</a>
				</div>
								<div class="col s3 m1">
					<a href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/inscripciones_abiertas_para_la_modalidad_intensiva_35_de_la_facultad_de_derecho_2025i">
						<img class="atajo" src="//urepublicana.edu.co/images/web/atajos/1712687378.png" name="//urepublicana.edu.co/images/web/atajos/1712687380.png">
						<p>Modalidad Intensiva derecho</p>
					</a>
				</div>
								<div class="col s3 m1">
					<a href="https://urepublicana.edu.co/modalidad_intensiva_especializaciones/">
						<img class="atajo" src="//urepublicana.edu.co/images/web/atajos/1712687530.png" name="//urepublicana.edu.co/images/web/atajos/1712687532.png">
						<p>Posgrados Acelerados y especiales</p>
					</a>
				</div>
				         
	</div>

<div class="container">
<div class="row">
<div class="col s12 m12">
 ﻿		<form id="form_new_general" action="https://hooks.zapier.com/hooks/catch/18595865/3jhfb2z/" method="POST" class="col s12" enctype="multipart/form-data">
			<center><h4><div class=' z-depth-2' style='color: #002849; padding-top: 1px;padding-bottom:4px;background-image: linear-gradient(to left,rgb(250,202,0),rgb(255,248,211),rgb(200,149,26));'>    
<h4 style='color: #002849 !important;'>¡QUIERO MÁS INFORMACIÓN!
</h4>
    <h6 >Déjanos tus datos, un asesor se pondrá en contacto</h6>
    
    </div></h4></center>
			<div id="cont_nombres" class="input-field col s12 m12 validate">
<input type="text" id="nombres" name="nombres" class="validate" data-error=".error_nombres">
			<label for="nombres">Nombres </label>
			<div class="error_form error_nombres"></div>
		</div>
		<div id="cont_ema" class="input-field col s12 m6 validate">
<input type="email" id="ema" name="ema" class="validate" data-error=".error_ema">
			<label for="ema">Correo Electrónico </label>
			<div class="error_form error_ema"></div>
		</div>
		<div id="cont_cel" class="input-field col s12 m6 validate">
<input type="number" id="cel" name="cel" class="validate" data-error=".error_cel">
			<label for="cel">Número Celular </label>
			<div class="error_form error_cel"></div>
		</div>
				<div id="cont_pro" class="input-field col s12 m12 validate">
			<select required  id="pro" name="pro"   class="validate" data-error=".error_pro">
				<option  value="" >Seleccione una opción</option>
										<option value="DERECHO" >DERECHO</option>
												<option value="FINANZAS Y COMERCIO INTERNACIONAL VIRTUAL" >FINANZAS Y COMERCIO INTERNACIONAL VIRTUAL</option>
												<option value="ADMINISTRACIÓN DE MERCADEO VIRTUAL" >ADMINISTRACIÓN DE MERCADEO VIRTUAL</option>
												<option value="MATEMÁTICAS" >MATEMÁTICAS</option>
												<option value="INGENIERÍA DE SISTEMAS" >INGENIERÍA DE SISTEMAS</option>
												<option value="FINANZAS Y COMERCIO INTERNACIONAL" >FINANZAS Y COMERCIO INTERNACIONAL</option>
												<option value="TRABAJO SOCIAL" >TRABAJO SOCIAL</option>
												<option value="CONTADURÍA PÚBLICA" >CONTADURÍA PÚBLICA</option>
												<option value="INGENIERÍA INDUSTRIAL" >INGENIERÍA INDUSTRIAL</option>
												<option value="DIPLOMADO EN DESARROLLO DE SOFTWARE SEGURO" >DIPLOMADO EN DESARROLLO DE SOFTWARE SEGURO</option>
												<option value="DIPLOMADO DE FORMACIÓN Y CAPACITACIÓN DE CONCILIADORES EN DERECHO" >DIPLOMADO DE FORMACIÓN Y CAPACITACIÓN DE CONCILIADORES EN DERECHO</option>
												<option value="DIPLOMADO DE INSOLVENCIA DE PERSONA NATURAL NO COMERCIANTE" >DIPLOMADO DE INSOLVENCIA DE PERSONA NATURAL NO COMERCIANTE</option>
												<option value="DIPLOMADO EN DOCENCIA UNIVERSITARIA CON ÉNFASIS EN TIC" >DIPLOMADO EN DOCENCIA UNIVERSITARIA CON ÉNFASIS EN TIC</option>
												<option value="DIPLOMADO EN GESTIÓN EDUCATIVA EN EL CONTEXTO DE LA PARTICIPACIÓN" >DIPLOMADO EN GESTIÓN EDUCATIVA EN EL CONTEXTO DE LA PARTICIPACIÓN</option>
												<option value="ESP. EN REVISORIA FISCAL" >ESP. EN REVISORIA FISCAL</option>
												<option value="ESP. EN RESPONSABILIDAD CIVIL Y DEL ESTADO" >ESP. EN RESPONSABILIDAD CIVIL Y DEL ESTADO</option>
												<option value="ESP. EN CONTRATACIÓN ESTATAL" >ESP. EN CONTRATACIÓN ESTATAL</option>
												<option value="ESP. EN DERECHO URBANÍSTICO" >ESP. EN DERECHO URBANÍSTICO</option>
												<option value="ESP. EN GERENCIA DE INSTITUCIONES EDUCATIVAS" >ESP. EN GERENCIA DE INSTITUCIONES EDUCATIVAS</option>
												<option value="ESP. EN GERENCIA FINANCIERA" >ESP. EN GERENCIA FINANCIERA</option>
												<option value="ESP. DERECHO FINANCIERO Y BURSÁTIL" >ESP. DERECHO FINANCIERO Y BURSÁTIL</option>
												<option value="ESP. DERECHO TRIBUTARIO" >ESP. DERECHO TRIBUTARIO</option>
												<option value="ESP.  EN DERECHO PROBATORIO, PROCESAL Y ORALIDAD JUDICIAL" >ESP.  EN DERECHO PROBATORIO, PROCESAL Y ORALIDAD JUDICIAL</option>
												<option value="ESP. EN CIENCIAS CRIMINOLÓGICAS Y PENALES" >ESP. EN CIENCIAS CRIMINOLÓGICAS Y PENALES</option>
												<option value="ESP. EN DERECHO PÚBLICO" >ESP. EN DERECHO PÚBLICO</option>
												<option value="ESP. EN DERECHO NOTARIAL Y DE REGISTRO" >ESP. EN DERECHO NOTARIAL Y DE REGISTRO</option>
												<option value="ESP. EN DERECHO PROCESAL CONSTITUCIONAL" >ESP. EN DERECHO PROCESAL CONSTITUCIONAL</option>
												<option value="ESP. EN DERECHO LABORAL Y SEGURIDAD SOCIAL" >ESP. EN DERECHO LABORAL Y SEGURIDAD SOCIAL</option>
												<option value="ESP. EN LA RESPONSABILIDAD PENAL DEL SERVIDOR PÚBLICO Y LOS DELITOS CONTRA LA ADMINISTRACIÓN PÚBLICA" >ESP. EN LA RESPONSABILIDAD PENAL DEL SERVIDOR PÚBLICO Y LOS DELITOS CONTRA LA ADMINISTRACIÓN PÚBLICA</option>
												<option value="ESP. EN DERECHO DE FAMILIA" >ESP. EN DERECHO DE FAMILIA</option>
												<option value="ESP. EN DERECHO COMERCIAL" >ESP. EN DERECHO COMERCIAL</option>
												<option value="ESP. EN INTERVENCIÓN Y GERENCIA SOCIAL" >ESP. EN INTERVENCIÓN Y GERENCIA SOCIAL</option>
												<option value="ESP. EN DERECHO ADMINISTRATIVO VIRTUAL" >ESP. EN DERECHO ADMINISTRATIVO VIRTUAL</option>
									</select>
			<label  for="pro"> Programa al que aspira </label>
			<div class="error_form error_pro"></div>
			<br>
		</div>
		<div id="cont_terminos" class="input-field col s12 m12 validate">
<input type="checkbox" id="terminos" name="terminos" class="validate" data-error=".error_terminos">
			<label for="terminos">Autorizo el tratamiento de mis datos personales a la Corporación Universitaria Republicana conforme a sus<a href='https://urepublicana.edu.co/images/documentos/1649868637.pdf' target='_blank'> Políticas de Protección de Datos Personales</a> </label>
			<div class="error_form error_terminos"></div>
		</div>
		                <div id="terminos" class="input-field col s12 m12 validate">
                      <!--   <p>Autorizo el tratamiento de mis datos personales a la Corporación Universitaria Republicana conforme a sus<a href='https://urepublicana.edu.co/images/documentos/1649868637.pdf' target='_blank'> Políticas de Protección de Datos Personales</a></p> -->
                        
                </div>
                		<div class="input-field col s12 m">
		  <div class="g-recaptcha" data-sitekey="6LdpHhMTAAAAAEdufQp1hh8N02SrSedKBS5ZRqul" data-callback="correctCaptcha"></div>
		<br>
		</div>
				<div class="input-field col m12 center">
		<button name="submit" class="btn-large waves-effect waves-light amber btn_captcha" type="submit" onclick='return validacion()'>
				Enviar			</button>
		</div>
		<div id="cont_origen" class="input-field col s12 m6 ">
<input type="hidden" id="origen" name="origen" value="web"  class="" data-error=".error_origen">
                        <label for="origen"> </label>
                        <div class="error_form error_origen"></div>
                </div>

<div id="cont_periodo" class="input-field col s12 m6 ">
<input type="hidden" id="periodo" name="periodo" value="20251"  class="" data-error=".error_periodo">
                        <label for="periodo"> </label>
                        <div class="error_form error_periodo"></div>
                </div>

<div id="cont_rutapdf" class="input-field col s12 m6 ">
<input type="hidden" id="rutapdf" name="rutapdf" value=""  class="" data-error=".error_rutapdf">
                        <label for="rutapdf"> </label>
                        <div class="error_form error_rutapdf"></div>
                </div>

<div id="cont_valormat" class="input-field col s12 m6 ">
<input type="hidden" id="valormat" name="valormat" value=""  class="" data-error=".error_valormat">
                        <label for="valormat"> </label>
                        <div class="error_form error_valormat"></div>
                </div>

			
		</form>
		</div>
</div>
</div>




<!-- widgets y podcast -->

<h4 class="center-align" >Nuestras Redes</h4>

<div class="container">
<div class="row">
<div class="col s12 m5 center">


<div class="fb-page" data-href="https://www.facebook.com/CorporacionUniversitariaRepublicana" data-tabs="timeline" data-width="" data-height="" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/CorporacionUniversitariaRepublicana" class="fb-xfbml-parse-ignore"><a target='_blank' href="https://www.facebook.com/CorporacionUniversitariaRepublicana">Corporación Universitaria Republicana</a></blockquote></div>

</div>
<div class="col s12 m2 center">
</div>

<div class="col s12 m5 center">

<iframe   src="https://republicanaradio.com/sin-categoria/categorias-podcast-urepublicanaradio/" style="width: 100%; border: 0; margin: 0;height:450px"  ></iframe>



</div>



</div>
</div>



<!-- fin de widgets y podcast


<!-- publicaciones       -->


<div class="container">
<div class="row">
<center>
        <h4> Publicaciones </h4>
      </center>
<br>
 <div class="col s12 m4">
        <div class="card horizontal">
          <div class="card-image" style="height:100px;" >
            <a class="enlace" href="//urepublicana.edu.co/pages/gaceta/" >
              <img style="width:40% !important " src="//urepublicana.edu.co/images/web/atajos/gaceta.png" name="//urepublicana.edu.co/images/web/atajos/gaceta_1.png" class="img_card atajo">
            </a>

          </div>
            <div class="card-content">
              <p class="titulo_card mayus">Gaceta</p>
            </div>
        </div>
      </div>

<div class="col s12 m4">
        <div class="card horizontal" style="height:100px;" >
          <div class="card-image">
            <a class="enlace" target="_blank" href="http://ojs.urepublicana.edu.co/index.php/">
              <img style="width:40% !important " src="//urepublicana.edu.co/images/web/atajos/revista.png" name="//urepublicana.edu.co/images/web/atajos/revista_1.png"  class="img_card atajo">
            </a>
          </div>
            <div class="card-content">
              <p class="titulo_card mayus">Revistas Republicana</p>
            </div>
        </div>
      </div>

 <div class="col s12 m4">
        <div class="card horizontal">
          <div class="card-image" style="height:100px;">
            <a class="enlace" href="//urepublicana.edu.co/pages/libros.php" >
              <img style="width:40% !important " src="//urepublicana.edu.co/images/web/atajos/libro.png" name="//urepublicana.edu.co/images/web/atajos/libro_1.png"  class="img_card atajo">
            </a>
          </div>
            <div class="card-content">
              <p class="titulo_card mayus">Libros Electrónicos</p>
            </div>
        </div>
      </div>
    </div>
    <br><br>
  </div>





<!-- fin publicaciones -->











	<!-- CONTENIDO -->
		<div class="completa">
		<!-- NOTICIAS -->
					<div class="row urep_divide">
				<h4 class="center-align" >Noticias</h4>
				<div id="cont_noticias" class="owl-carousel owl-theme">
												<div class="item noticia">
								<img src="//urepublicana.edu.co/images/noticias_eventos/1729781386.jpg">


								<h5>

<a href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/matriculas_estudiantes_antiguos_2025i">MATRÍCULAS ESTUDIANTES ANTIGUOS 2025-I</a>

								</h5>
							<p>
 									La Corporación Universitaria Republicana invita a su comunidad estudiantil a que descarguen su orden de matrícula para el periodo 2025-I 								</p>
								<a class="btn_leer" href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/matriculas_estudiantes_antiguos_2025i">Leer más...</a>
							</div>
														<div class="item noticia">
								<img src="//urepublicana.edu.co/images/noticias_eventos/1726620819.jpg">


								<h5>

<a href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/inscripciones_abiertas_modalidad_acelerada_posgrados_2025i">INSCRIPCIONES ABIERTAS MODALIDAD ACELERADA POSGRADOS 2025-I</a>

								</h5>
							<p>
 									Entérate de los beneficios de estudiar en una modalidad acelerada para los programas de posgrado de la Corporación Universitaria Republicana para el periodo académico 2025-I 								</p>
								<a class="btn_leer" href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/inscripciones_abiertas_modalidad_acelerada_posgrados_2025i">Leer más...</a>
							</div>
														<div class="item noticia">
								<img src="//urepublicana.edu.co/images/noticias_eventos/1726621452.jpg">


								<h5>

<a href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/inscripciones_abiertas_para_la_modalidad_intensiva_35_de_la_facultad_de_derecho_2025i">INSCRIPCIONES ABIERTAS PARA LA MODALIDAD INTENSIVA 3.5 DE LA FACULTAD DE DERECHO 2025-I</a>

								</h5>
							<p>
 									Inscripciones abiertas para la modalidad Intensiva 3.5 para el programa de Derecho 								</p>
								<a class="btn_leer" href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/inscripciones_abiertas_para_la_modalidad_intensiva_35_de_la_facultad_de_derecho_2025i">Leer más...</a>
							</div>
														<div class="item noticia">
								<img src="//urepublicana.edu.co/images/noticias_eventos/1726621910.jpg">


								<h5>

<a href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/inscripciones_abiertas_modalidad_especial_posgrados_2025i">INSCRIPCIONES ABIERTAS MODALIDAD ESPECIAL POSGRADOS  2025-I</a>

								</h5>
							<p>
 									Termina tu posgrado de una manera rápida y empieza el 13 de febrero de 2025 								</p>
								<a class="btn_leer" href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/inscripciones_abiertas_modalidad_especial_posgrados_2025i">Leer más...</a>
							</div>
														<div class="item noticia">
								<img src="//urepublicana.edu.co/images/noticias_eventos/1731527565.jpeg">


								<h5>

<a href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/entrega_de_informes_tercer_corte_consultorio_juridico_2024_2">ENTREGA DE INFORMES - TERCER CORTE CONSULTORIO JURÍDICO 2024 – 2</a>

								</h5>
							<p>
 									La información suministrada está dirigida a los estudiantes de la Facultad de Derecho que cursan Consultorio Jurídico. 								</p>
								<a class="btn_leer" href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/entrega_de_informes_tercer_corte_consultorio_juridico_2024_2">Leer más...</a>
							</div>
														<div class="item noticia">
								<img src="//urepublicana.edu.co/images/noticias_eventos/1730930049.jpg">


								<h5>

<a href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/convocatoria_examen_de_clasificacion_de_ingles_noviembre_2024">CONVOCATORIA EXAMEN DE CLASIFICACIÓN DE INGLÉS NOVIEMBRE 2024</a>

								</h5>
							<p>
 									Inscripciones abiertas para el Examen de Clasificación de Inglés del 9 al 13 de noviembre, el examen será presencial el día 23 de noviembre de 2024 								</p>
								<a class="btn_leer" href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/convocatoria_examen_de_clasificacion_de_ingles_noviembre_2024">Leer más...</a>
							</div>
														<div class="item noticia">
								<img src="//urepublicana.edu.co/images/noticias_eventos/1730406149.jpg">


								<h5>

<a href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/clases_remotas_2_de_noviembre_de_2024_dia_por_el_uso_responsable_del_agua_">CLASES REMOTAS 2 DE NOVIEMBRE DE 2024, DÍA POR EL USO RESPONSABLE DEL AGUA </a>

								</h5>
							<p>
 									La Corporación Universitaria Republicana informa a la comunidad acerca de las clases remotas para este 02 de noviembre de 2024.  								</p>
								<a class="btn_leer" href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/clases_remotas_2_de_noviembre_de_2024_dia_por_el_uso_responsable_del_agua_">Leer más...</a>
							</div>
														<div class="item noticia">
								<img src="//urepublicana.edu.co/images/noticias_eventos/1729896531.jpg">


								<h5>

<a href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/jornada_cultural_republicana_2024ii">JORNADA CULTURAL REPUBLICANA 2024-II</a>

								</h5>
							<p>
 									La Jornada Cultural será un espacio de arte y actividades interactivas que nos unen y enriquecen como comunidad republicana. 								</p>
								<a class="btn_leer" href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/jornada_cultural_republicana_2024ii">Leer más...</a>
							</div>
														<div class="item noticia">
								<img src="//urepublicana.edu.co/images/noticias_eventos/1729627044.jpg">


								<h5>

<a href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/entrega_de_informes_consultorio_juridico_segundo_corte_2024ii">ENTREGA DE INFORMES CONSULTORIO JURÍDICO SEGUNDO CORTE 2024-II</a>

								</h5>
							<p>
 									Conoce el cronograma para la entrega de informes correspondientes al Segundo Corte  de Consultorio Jurídico. 								</p>
								<a class="btn_leer" href="//urepublicana.edu.co/pages/publicaciones/principal/noticia/entrega_de_informes_consultorio_juridico_segundo_corte_2024ii">Leer más...</a>
							</div>
											</div>
				<center><a href="//urepublicana.edu.co/pages/publicaciones/principal/noticia" ><h5 class="more_info"> <i class="material-icons">add_circle_outline</i> Ver todas las Noticias</h5></a></center>
			</div>
					<!-- EVENTOS -->

					<div class="row urep_divide">
				<h4 class="center-align" >Eventos</h4>
				<div id="cont_eventos" class="owl-carousel owl-theme">
												<div class="item noticia">
								<img src="//urepublicana.edu.co/images/noticias_eventos/1730827694.jpg">
								<h5>
									<a href="//urepublicana.edu.co/pages/publicaciones/principal/evento/ix_encuentro_de_semilleros_de_investigacion">IX ENCUENTRO DE SEMILLEROS DE INVESTIGACIÓN</a>
								</h5>
								<p>
									Participa en el IX Encuentro de Semilleros de Investigación, el cual estará centrado en el Papel de la Inteligencia Artificial en la Transformación Industrial de las Empresas en Colombia.								</p>
								<a class="btn_leer" href="//urepublicana.edu.co/pages/publicaciones/principal/evento/ix_encuentro_de_semilleros_de_investigacion">Leer más...</a>
							</div>
														<div class="item noticia">
								<img src="//urepublicana.edu.co/images/noticias_eventos/1729556627.jpg">
								<h5>
									<a href="//urepublicana.edu.co/pages/publicaciones/principal/evento/conmemoracion_del_dia_del_trabajo_social_del_21_al_30_de_octubre_de_2024">CONMEMORACIÓN DEL DÍA DEL TRABAJO SOCIAL: DEL 21 AL 30 DE OCTUBRE DE 2024</a>
								</h5>
								<p>
									¡Agéndate y participa en las actividades realizadas para conmemorar el Día del Trabajo Social								</p>
								<a class="btn_leer" href="//urepublicana.edu.co/pages/publicaciones/principal/evento/conmemoracion_del_dia_del_trabajo_social_del_21_al_30_de_octubre_de_2024">Leer más...</a>
							</div>
														<div class="item noticia">
								<img src="//urepublicana.edu.co/images/noticias_eventos/1714844347.jpeg">
								<h5>
									<a href="//urepublicana.edu.co/pages/publicaciones/principal/evento/conferencia_relaciones_vinculares_en_el_ambito_educativo_retos_y_desafios_desde_el_quehacer_del_trabajo_social">CONFERENCIA RELACIONES VINCULARES EN EL ÁMBITO EDUCATIVO. RETOS Y DESAFÍOS DESDE EL QUEHACER DEL TRABAJO SOCIAL</a>
								</h5>
								<p>
									Te esperamos en el Auditorio de la Corporación Universitaria Republicana en la conferencia de la Facultad de Trabajo Social								</p>
								<a class="btn_leer" href="//urepublicana.edu.co/pages/publicaciones/principal/evento/conferencia_relaciones_vinculares_en_el_ambito_educativo_retos_y_desafios_desde_el_quehacer_del_trabajo_social">Leer más...</a>
							</div>
														<div class="item noticia">
								<img src="//urepublicana.edu.co/images/noticias_eventos/1713813743.jpg">
								<h5>
									<a href="//urepublicana.edu.co/pages/publicaciones/principal/evento/seminario_nuevas_tendencias_jurisprudenciales_del_derecho_de_familia">SEMINARIO NUEVAS TENDENCIAS JURISPRUDENCIALES DEL DERECHO DE FAMILIA</a>
								</h5>
								<p>
									Los invitamos a participar en este evento académico organizado por la Facultad de Derecho. 								</p>
								<a class="btn_leer" href="//urepublicana.edu.co/pages/publicaciones/principal/evento/seminario_nuevas_tendencias_jurisprudenciales_del_derecho_de_familia">Leer más...</a>
							</div>
														<div class="item noticia">
								<img src="//urepublicana.edu.co/images/noticias_eventos/1712354286.jpg">
								<h5>
									<a href="//urepublicana.edu.co/pages/publicaciones/principal/evento/jornada_de_la_salud_2024_mente_sana_vida_plena">JORNADA DE LA SALUD 2024 ¡MENTE SANA, VIDA PLENA!</a>
								</h5>
								<p>
									¡La Jornada de la Salud ha Llegado! Mente Sana, Vida Plena. Descubre el poder del autocuidado  y prepárate para participar del 9 al 11 de abril de 2024								</p>
								<a class="btn_leer" href="//urepublicana.edu.co/pages/publicaciones/principal/evento/jornada_de_la_salud_2024_mente_sana_vida_plena">Leer más...</a>
							</div>
														<div class="item noticia">
								<img src="//urepublicana.edu.co/images/noticias_eventos/1712359439.jpg">
								<h5>
									<a href="//urepublicana.edu.co/pages/publicaciones/principal/evento/conferencia_el_impuesto_de_renta_de_las_personas_juridicas">CONFERENCIA EL IMPUESTO DE RENTA DE LAS PERSONAS JURÍDICAS</a>
								</h5>
								<p>
									Agéndate a la conferencia para ampliar tus conocimientos en el campo tributario								</p>
								<a class="btn_leer" href="//urepublicana.edu.co/pages/publicaciones/principal/evento/conferencia_el_impuesto_de_renta_de_las_personas_juridicas">Leer más...</a>
							</div>
											</div>
				<center><a href="//urepublicana.edu.co/pages/publicaciones/principal/evento" ><h5 class="more_info"> <i class="material-icons">add_circle_outline</i> Ver todos los Eventos </h5></a></center>
			</div>
				</div>
</div>
<script>

function validacion()
{


var pro1 = document.getElementById("pro").value;
indice = document.getElementById("pro").selectedIndex;if( indice == null || indice == 0  || indice == ""  ) { alert('recuerde seleccionar el programa');

 return false;}
}
</script>

<div class="footer-copyright">
  <div class="container">
   <div class="row">
    <div class="col s12 m3 l3 center-align">
      <img src="//urepublicana.edu.co/images/web/footer/1521576084.png" class="logo_footer"><br>
      <i class="contacto" style="background-color: transparent;">
        Iesus Christus hanc dat fructum. Gloria in sancta Trinitate. Et providere nos, misericordem gloriam Dei vivi       </i>
    </div>
    <div class="col s12 m9 l9">
      <div class="row center-align">
        
<a target="_blank" href="https://www.facebook.com/CorporacionUniversitariaRepublicana/" ><img src="//urepublicana.edu.co/images/web/footer/facebook.png" class="social_urep"></a>

<a target="_blank" href="https://twitter.com/URepublicana_?lang=en" ><img src="//urepublicana.edu.co/images/web/footer/twitter.png" class="social_urep"></a>

<a target="_blank" href="https://www.instagram.com/urepublicana/" ><img src="//urepublicana.edu.co/images/web/footer/instagram.png" class="social_urep"></a>

<a target="_blank" href="https://www.youtube.com/channel/UC38BS2DLRSwXvnS_6QnS5Zg" ><img src="//urepublicana.edu.co/images/web/footer/youtube.png" class="social_urep"></a>

<a target="_blank" href="https://www.linkedin.com/in/corporaci%C3%B3n-universitaria-republicana-6bb35110b" ><img src="//urepublicana.edu.co/images/web/footer/linkedin.png" class="social_urep"></a>


<!-- <a target="_blank" href="https://api.whatsapp.com/send?phone=573057498050"><img src="//urepublicana.edu.co/images/web/footer/whatsapp.png" class="social_urep"></a> -->
      </div>
      <div class="left-align row enlaces_urep">
       <div class="col s12 m6 l4">
        <ul>
                        <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/1649868637.pdf">Ley de Protección de datos</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="http://urepublicana.edu.co/trabaje_con_nosotros/">Trabaje con Nosotros</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/codigos_para_consignacion">Listado Códigos de Consignaciones</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/iberoamericana/pages/publicaciones/Institucion/0/nosotros">Convenio Corporación Iberoamericana de Estudios Jurídicos</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/1674235905.pdf">Protocolo para la prevención y atención de casos de violencia y equidad de género</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/footer/directorio_institucional.pdf">Directorio Institucional</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/pages/ccaac/">Centro de Conciliación, Arbitraje y Amigable Composición</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                        </ul>
      </div>
    </div>
  </div>
</div>
</div>
<div class="row center-align contacto">
 Institución de Educación Superior Sujeta a Inspección y Vigilancia por el Ministerio de Educación Nacional, con Personería jurídica reconocida mediante resolución No 3061 del 02 de diciembre de 1999, expedida por el Ministerio de Educación Nacional.<br>  Sede Administrativa: Cr 7 No 19-38 | Horario de atención. lunes a viernes de 8:00 a.m a 8:00 p.m, Sábados:9:00 a.m a 1:00 p.m <br>  PBX: 286 23 84 | Información Admisiones: ext. 143 | www.urepublicana.edu.co <br>  Bogotá, Colombia</div>
<div class="center-align legal">
 &copy; Corporación Universitaria Republicana 2017
</div>
<!-- <script src="http://code.jquery.com/jquery-2.1.4.min.js"></script> -->
<!-- <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script> -->
<script src="//urepublicana.edu.co/assets/js/bootstrap-colorpicker.js"></script>
<script src="//urepublicana.edu.co/assets/js/docs.js"></script>
<!-- VALIDACION -->
<!-- <script src="//urepublicana.edu.co/assets/js/jquery.validate.min.js"></script> -->

<!-- JQUERY VALIDATE -->
<script type="text/javascript" src="//urepublicana.edu.co/assets/js/validation/dist/jquery.validate.min.js"></script>
<script src="//urepublicana.edu.co/assets/js/materialize.min.js"></script>
<script src="//urepublicana.edu.co/assets/js/init.js"></script>
<script type="text/javascript">
  function downloadJSAtOnload() {
    var element = document.createElement("script");
    element.src = "https://www.google.com/recaptcha/api.js";
    document.body.appendChild(element);
  }
  if (window.addEventListener)
    window.addEventListener("load", downloadJSAtOnload, false);
  else if (window.attachEvent)
    window.attachEvent("onload", downloadJSAtOnload);
  else window.onload = downloadJSAtOnload;
</script>




<script type="text/javascript" charset="utf-8">

	function correctCaptcha(){
     	$('button.btn_captcha').removeAttr("disabled");
    }
    
	$(document).ready(function(){
		$('button.btn_captcha').attr("disabled","disabled");
						var objs = [onclick='return validacion()',];
				jQuery.each( objs, function( i, obj ) {
					
					$(obj['origen']).on( obj['accion'] ,function() {
						
						var valores = "{";
							origenes = obj['origen'].split(",");
							jQuery.each( origenes, function( i, origen ) {
								var var_origen = $(origen).val();
								valores+= "'"+origen+"':'"+var_origen+"',"; 		
							});
						valores+="}"; 

						var event = obj['funcion'] +'('+ obj['parametros'] +', '+ valores +' );';
						var rta = eval(event);

						var tipo_tag = $(obj['destino']).prop("tagName");
						
						// SELECT
					

						if (tipo_tag == "SELECT") {
							$(obj['destino']).empty();
							$(obj['destino']).append('<option selected value="">Seleccione una opcion</option>');
							jQuery.each( rta, function( i, val ) {
								$(obj['destino']).append('<option value="'+ val.valor +'">'+ val.texto +'</option>');
							});	
						}
						if (tipo_tag == "DIV") {
							var name = obj['destino'].replace('#','');
							$("."+name).remove();
							jQuery.each( rta, function( i, val ) {
								$(obj['destino']).append('<p><input name="'+name+'" class="'+name+'" id="'+i+'" type="radio" value="'+ val.valor +'"><label class="'+name+'" for="'+i+'">'+ val.texto +'</label></p>');
							});	
						}


					});
				});
		
	// parametros( ids - separados por comas )
	var mostrar = function(ids) {
		var id = ids.split(',');
		jQuery.each( id, function( i, val ) {
			$("#cont_"+val).addClass("mostrar").removeClass("ocultar");
			$("#"+val).addClass("mostrar").removeClass("ocultar");
		});
	};


	// parametros(destino, consulta, valor);
	var cargar_valores = function(clase, metodo, valores) {
		var formData = {clase:clase,metodo:metodo,valores:valores};
		var url = "//urepublicana.edu.co/admin/class/class_metodos_form.php"; // El script a dónde se realizará la petición.
		$.ajax({
		type: "POST",
		url: url,
		async: false,
		data: formData,
			success: function(data){
			valores = jQuery.parseJSON(data);
			}
		});
		return valores;
	};

	// CARGAR VALIDACION INICIAL
	$( "#form_new_general").validate( {
		rules: {
					nombres: {required:true}, 
						ema: {required:true}, 
						cel: {required:true}, 
						pro: {required:true}, 
						terminos: {required:true}, 
						captcha: {}, 
						submit: {}, 
						origen: {required:true}, 
						periodo: {required:true}, 
						rutapdf: {required:true}, 
						valormat: {required:true} 
			//fin de la prueba de validación
		},
		errorElement : 'div',
		errorPlacement: function(error, element) {
			var placement = $(element).data('error');
			if (placement) {
				$(placement).append(error)
			} else {
				error.insertAfter(element);
			}
		}
	});
});
</script>
<script>
	$(document).ready(function() {
		$("#banner_intro").modal('open');
		var owl = $('.owl-carousel');
		owl.owlCarousel({
			autoplayHoverPause: true,
			autoplay:true,
			autoplayTimeout:5000,
			autoplaySpeed: 2000,
			navSpeed: 2000,
			margin: 15,
			nav: true,
			loop: true,
			responsive: {
				0: {
					items: 1
				},
				600: {
					items: 2
				},
				1000: {
					items: 3
				}
			}
		})
	})
</script>


<script type='module' src='https://interfaces.zapier.com/assets/web-components/zapier-interfaces/zapier-interfaces.esm.js'></script>
<zapier-interfaces-chatbot-embed is-popup='true' chatbot-id='clv6t7obo001xwbg49pk7uti8' height='600px' width='400px'></zapier-interfaces-chatbot-embed>


</body>



<!-- Aquí está el script para redirigir después del envío con webhook -->
<script>

const programas = {
  "INGENIERÍA DE SISTEMAS": { rutaPDF: 'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/plan_estudios_ingenieria_de_sistemas.pdf', valorMatricula: '$2.250.000.00',nivel: 'pregrado',usuario_mercadeo:'Usu 2' },
"INGENIERÍA INDUSTRIAL": { rutaPDF: 'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/plan_estudios_ingenieria_industrial.pdf', valorMatricula: '$2.250.000.00',nivel: 'pregrado',usuario_mercadeo:'Usu 2' },

"TRABAJO SOCIAL": { rutaPDF: 'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/plan_estudios_trabajo_social.pdf', valorMatricula: '$2.250.000.00',nivel: 'pregrado',usuario_mercadeo:'Usu 2' },
"MATEMÁTICAS": { rutaPDF: 'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/plan_estudios_matematicas.pdf', valorMatricula: '$2.250.000.00',nivel: 'pregrado',usuario_mercadeo:'Usu 2' },
"DERECHO": { rutaPDF: 'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/plan_estudios_derecho.pdf', valorMatricula: '$2.250.000.00',nivel: 'pregrado',usuario_mercadeo:'Usu 2' },
"FINANZAS Y COMERCIO INTERNACIONAL": { rutaPDF: 'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/plan_estudios_finanzas_comercio_internacional.pdf', valorMatricula: '$2.250.000.00',nivel: 'pregrado',usuario_mercadeo:'Usu 2' },

"FINANZAS Y COMERCIO INTERNACIONAL VIRTUAL": { rutaPDF: 'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/plan_estudios_finanzas_comercio_internacional_virtual.pdf', valorMatricula: '$1.450.000.00',nivel: 'pregrado',usuario_mercadeo:'Usu 2' },

"ADMINISTRACIÓN DE MERCADEO VIRTUAL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/plan_estudios_administracion_de_mercadeo.pdf', valorMatricula: '$1.450.000.00',nivel: 'pregrado',usuario_mercadeo:'Usu 2' },

"CONTADURÍA PÚBLICA": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/plan_estudios_contaduria_publica.pdf', valorMatricula: '$2.250.000.00',nivel: 'pregrado',usuario_mercadeo:'Usu 2' },

"DIPLOMADO EN DESARROLLO DE SOFTWARE SEGURO": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/diplomado_en_desarrollo_software_seguro.pdf', valorMatricula: '$1.400.000.00',nivel: 'diplomado',usuario_mercadeo:'Usu 3' },

"DIPLOMADO DE FORMACIÓN Y CAPACITACIÓN DE CONCILIADORES EN DERECHO": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/diplomado_en_formacion_capacitacion_de_conciliadores.pdf', valorMatricula: '$1.650.000.00',nivel: 'diplomado',usuario_mercadeo:'Usu 3'  },
"DIPLOMADO DE INSOLVENCIA DE PERSONA NATURAL NO COMERCIANTE": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/diplomado_en_insolvencia_de_persona_natural.pdf', valorMatricula: '$1.400.000.00',nivel: 'diplomado',usuario_mercadeo:'Usu 3'  },

"DIPLOMADO EN DOCENCIA UNIVERSITARIA CON ÉNFASIS EN TIC": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/diplomado_en_docencia_universitaria.pdf', valorMatricula: '$1.400.000.00',nivel: 'diplomado',usuario_mercadeo:'Usu 3'  },

"DIPLOMADO EN GESTIÓN EDUCATIVA EN EL CONTEXTO DE LA PARTICIPACIÓN": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/diplomado_en_gestion_educativa.pdf', valorMatricula: '$1.400.000.00',nivel: 'diplomado',usuario_mercadeo:'Usu 3'  },
"ESP. EN DERECHO PÚBLICO": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN DERECHO NOTARIAL Y DE REGISTRO": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3'  },
"ESP. EN DERECHO PROCESAL CONSTITUCIONAL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN DERECHO LABORAL Y SEGURIDAD SOCIAL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN LA RESPONSABILIDAD PENAL DEL SERVIDOR PÚBLICO Y LOS DELITOS CONTRA LA ADMINISTRACIÓN PÚBLICA": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.650.000.00',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN DERECHO DE FAMILIA": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN DERECHO COMERCIAL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN REVISORIA FISCAL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN INTERVENCIÓN Y GERENCIA SOCIAL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN CIENCIAS CRIMINOLÓGICAS Y PENALES": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP.  EN DERECHO PROBATORIO, PROCESAL Y ORALIDAD JUDICIAL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. DERECHO TRIBUTARIO": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. DERECHO FINANCIERO Y BURSÁTIL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.650.000.00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN GERENCIA FINANCIERA": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN GERENCIA DE INSTITUCIONES EDUCATIVAS": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.650.000.00',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN DERECHO URBANÍSTICO": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN CONTRATACIÓN ESTATAL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN RESPONSABILIDAD CIVIL Y DEL ESTADO": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN DERECHO ADMINISTRATIVO VIRTUAL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$2.500.000.00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' }
,
"INGLÉS A1": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/ingles_A1.pdf', valorMatricula: '$1.290.000.00',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"INGLÉS A2": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/ingles_A2.pdf', valorMatricula: '$1.370.000.00',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"INGLÉS B1": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/ingles_B1.pdf', valorMatricula: '$1.880.000.00',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"INGLÉS B2": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/ingles_B2.pdf', valorMatricula: '$2.280.000.00',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"FRANCÉS A1": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/frances_A1.pdf', valorMatricula: '$1.290.000.00',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"FRANCÉS A2": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/frances_A2.pdf', valorMatricula: '$1.370.000.00',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"FRANCÉS B1": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/frances_B1.pdf', valorMatricula: '$1.880.000.00',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"FRANCÉS B2": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/frances_B2.pdf', valorMatricula: '$2.280.000.00',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"Intercambio Internacional (Pregrado, Posgrado)": { rutaPDF:'NO APLICA', valorMatricula: 'NO APLICA',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"Intercambio Internacional (Maestría, Doctorado)": { rutaPDF:'NO APLICA', valorMatricula: 'NO APLICA',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"Intercambio Internacional Cultural (Au Pair, Camp Counselor, etc)": { rutaPDF:'NO APLICA', valorMatricula: 'NO APLICA',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"Intercambio Internacional (Inmersión Inglés)": { rutaPDF:'NO APLICA', valorMatricula: 'NO APLICA',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"Intercambio Internacional (Inmersión Inglés 40 Horas)": { rutaPDF:'NO APLICA', valorMatricula: 'NO APLICA',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"Oferta Laboral Internacional (Remoto)": { rutaPDF:'NO APLICA', valorMatricula: 'NO APLICA',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"Oferta Internacional (Presencial)": { rutaPDF:'NO APLICA', valorMatricula: 'NO APLICA',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }


};

document.getElementById('form_new_general').addEventListener('submit', function(event) {
    event.preventDefault();  // Detiene el envío predeterminado para realizar la validación manual

var form = this;
    var valid = form.checkValidity();  // Verifica la validez de todos los campos

var checkbox = document.getElementById('terminos');
    if (checkbox.checked) {
       // alert("El valor del checkbox es: " + checkbox.value);
    } else {
       // alert("Por favor acepte los términos para poder continuar");
        return;
    }
  

if ($("#form_new_general").valid()) {

var programaSeleccionado = $('#pro').val();
// Asignar los valores correspondientes a los campos de texto
    $('#rutapdf').val(programas[programaSeleccionado].rutaPDF);
    $('#valormat').val(programas[programaSeleccionado].valorMatricula);

//alert("Ruta PDF: " + $('#rutapdf').val() + "\nValor Matrícula: " + $('#valormat').val());

// Crear el campo de entrada "nivel"
        var nivelField = '<input id="nivel" type="hidden" name="nivel" >';
        
        // Crear el campo de entrada "usu_mercadeo"
        var usuMercadeoField = '<input id="usu_mercadeo" type="hidden" name="usu_mercadeo" >';
        
        // Agregar los campos de entrada al formulario
        $("#form_new_general").append(nivelField);
        $("#form_new_general").append(usuMercadeoField);
// Asignar los valores correspondientes a los campos de texto
    $('#nivel').val(programas[programaSeleccionado].nivel);
    $('#usu_mercadeo').val(programas[programaSeleccionado].usuario_mercadeo);





        // Si el formulario es válido, realiza la petición AJAX
        $('button[name="submit"]').prop('disabled', true);
        $('#btn_form_info').prop('disabled', true);
        $.ajax({
            url: form.action,
            type: form.method,
            data: $(form).serialize(),
            success: function(response) {
                // Redirección a la página de confirmación
             alert("¡Tus datos han sido registrados!");

  window.location.href = "https://urepublicana.edu.co/pages/publicaciones/privado/noticia/gracias_por_compartir_tus_datos_con_nosotros";
            },
            error: function() {
                alert("Hubo un error al procesar el formulario. Por favor, inténtalo de nuevo.");
            }
        });
    }
});

</script>


 

</html>

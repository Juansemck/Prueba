<!doctype html>
<html manifest="urepublicana.appcache">
<head>
	

<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '135599650420182');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=135599650420182&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->

 <!-- Global site tag (gtag.js) - Google Analytics -->



   <script async src="https://www.googletagmanager.com/gtag/js?id=UA-107902131-1"></script>




 <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-107902131-1');
  </script>

    <meta charset="UTF-8">
  <title>Corporación Universitaria Republicana - centro_idiomas.php</title>
 
<meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />
 <meta name="description" content=" Formar más colombianos sociales, ética y científicamente"  lang="es-ES">


<meta name="keywords"  content="pregrado, postgrado, derecho, ingenierías, trabajo social, contaduría pública, finanzas y comercio internacional, Matemáticas, Posgrados bogota, Pregrados bogotá"  lang="es-ES">


  <meta name="viewport" content="initial-scale=1, maximum-scale=1">
  <link rel="shortcut icon" href="//urepublicana.edu.co/images/web/logo.png">


  <link href="//urepublicana.edu.co/assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="//urepublicana.edu.co/assets/css/bootstrap-colorpicker.min.css" rel="stylesheet">
  
  <!-- Styles of this template -->


  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet"> 
  <link rel="stylesheet" href="//urepublicana.edu.co/assets/css/slider.min.css" type="text/css">
  <!-- LayerSlider styles -->

  <link rel="stylesheet" href="//urepublicana.edu.co/assets/slider/css/layerslider.css" type="text/css">
  <!-- External libraries: jQuery & GreenSock -->
  <script src="//urepublicana.edu.co/assets/slider/js/jquery.min.js" type="text/javascript"></script>
  <script src="//urepublicana.edu.co/assets/slider/js/greensock.min.js"></script>
  <!-- LayerSlider script files -->
  <script src="//urepublicana.edu.co/assets/slider/js/layerslider.transitions.min.js" type="text/javascript"></script>
  <script src="//urepublicana.edu.co/assets/slider/js/layerslider.kreaturamedia.jquery.min.js" type="text/javascript"></script>
  <!-- LayerSlider Popup plugin files -->
  <link rel="stylesheet" href="//urepublicana.edu.co/assets/slider/plugins/origami/layerslider.origami.css" type="text/css">
  <script src="//urepublicana.edu.co/assets/slider/plugins/origami/layerslider.origami.js" type="text/javascript"></script>


  <!-- MATERIALIZE -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="//urepublicana.edu.co/assets/css/materialize.min.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <!-- STYLE -->
  <link href="//urepublicana.edu.co/assets/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  
<style>

body{
	background: #ffffff;
}

h3{
	color: black;
}

h4{
	color: black;
}

.resumen_noticia{
	color: black;
}

.noticia > p{
	color: black;
}

.legal{
	color: black;
	background: #ffffff;
}

.contenido_noticia{
	color: black;
}

.titulo_menu{
	color: #000000 !important; 	
}

.card{
	background: #ffffff;
}

.card-reveal{
	background: #ffffff !important;
}

.tipo_urep{
	color: #a2121c;
	font-family: ;
}

.breadcrumb::before {
    content: '' !important;
}

	/*====================== HEADER */

.tipo_urep{
	font-family: Pinyon Script, cursive;
}

.menu_admin {
	background: linear-gradient(#ffffff87, #fffffff7) !important;	
}

.menu_admin a{
	color: #000000 !important; 	
}

#main_menu{
	background: linear-gradient(#ffffff87, #fffffff7);
}

#menu_mobile{
background: linear-gradient(#ffffff87, #fffffff7);
}

.side-nav li > a {
	color: #000000; 
}

.nav_main a{
	color: #000000; 
}

.nav_aux > li >a{
	color: #000000;
}

.nav_main a:hover{
	color: #a2121c;
}

.menu_all a:hover {
	color: #a2121c;
}

.nav_urep li {
	float: right;
}

.logo_urep{
	float: right !important;
}

.menu_nav{
  padding: 10px 5px !important;
}


/*====================== DESCRIPCION */

.legal_urep{
	color: ;
}



/*====================== ENLACES - BOTONES */

/*====================== NOTICIAS */

.noticia > a{
	color: #a2121c;
	border: 1px solid #a2121c;
}

.noticia > a:hover{
	background-color:#a2121c;
}

.urep_divide {
	border-bottom: solid 15px #a2121c;
}

#btn_menu i{
color: #000000;
}

.noticia > h5 > a{
	color: #a2121c;
}

.more_info{
	color: #a2121c;
}

#solicita_info{
border: 1px solid #a2121c;
}

#btn_informacion{
background-color: #a2121c;
}

#btn_informacion a{
background-color: #a2121c;
}

#btn_informacion a > i{
background-color: #a2121c;
}

.boton_urep{
	background-color: #a2121c;
}

.boton_urep:hover{
	background-color: white;
	color: #a2121c;
	border: 1px solid #a2121c;
}

.noticias_all > div > div > h5 > a{
	color: #a2121c;
}

.leer_mas{
	border: 1px solid #a2121c;
}

.enlace_inter{
	background: #a2121c;
}

.tab > a {
	color: #a2121c !important;
}

.content_inter li b{
	color: #a2121c;
}

.card-action a{
	color: #a2121c !important;
}

.enlace{
	color: #a2121c !important;   
}

.owl-theme .owl-dots .owl-dot.active span, .owl-theme .owl-dots .owl-dot:hover span {
	background: #a2121c;
}

.owl-theme .owl-nav [class*='owl-'] {
	background: #a2121c;
}

.owl-theme .owl-nav [class*='owl-']:hover {
	background:  #a2121c;
}

.footer-copyright{
	background-color: #A2121C;
}

.footer-copyright a{
	color: white;
}

.enlaces_urep{
	color: white;
}

.contacto{
	color: white;
	background-color: #262626;
}


</style>

  <!-- CARRUSEL -->
  <link rel="stylesheet" href="//urepublicana.edu.co/assets/owlcarousel/owl.carousel.css">
  <script src="//urepublicana.edu.co/assets/owlcarousel/owl.carousel.min.js"></script>

  <!-- ANIMATE -->
  <!-- <link rel="stylesheet" href="//urepublicana.edu.co/assets/css/animate.min.css"> -->

  <!-- TEXT -->
  <script src="//urepublicana.edu.co/assets/nic_edit/nicEdit.min.js" type="text/javascript"></script>
  <script type="text/javascript">
  	bkLib.onDomLoaded(function() {
  		new nicEditor({
  			buttonList : ['fontSize','fontFormat','indent','outdent','bold','italic','underline','underline','left','center','right','justify','html','ol','ul','link','unlink','xhtml']
  		}).panelInstance('noticia');
  	});
  </script>
</head>
<body id="body_urep">
	<div class="row" id="main_menu" style="width: 100%;">
      <!-- LOGO - DESCRIPCION -->
    <div class="col s4 m2 l2 right-align menu_nav">
      <a href="//urepublicana.edu.co/pages/"> <img src="//urepublicana.edu.co/images/web/logo.png" class="logo_urep"> </a>
    </div>
    <div class="col s6 m9 l4 left-align menu_nav">
      <div style="display:inline-block;">
        <h1 class="tipo_urep" style="width: 100%; " >Corporación Universitaria Republicana</h1>
        <center><p class="legal_urep"><b>Resolución No. 3061 del 02 de Diciembre de 1999 Min. Educación.<br>
Formamos más Colombianos ética, social y cientificamente
</b>
<br>Iesus Christus hanc dat fructum. Gloria in sancta Trinitate.<br> Et providere nos, misericordem gloriam Dei vivi</p></center>
      </div>
    </div>
    <!-- FIN - LOGO DESCRIPCION -->
      <!-- MENU -->
  <div class="col s2 m1 l6">
    <div class="nav-wrapper">
      <a href="#" id="btn_menu" data-activates="menu_mobile" class="button-collapse"><i class="material-icons">menu</i></a>
      <!-- MOBILE MENU -->
      <ul id="menu_mobile" class="side-nav center-align">
        <a href="//urepublicana.edu.co/pages/"><img src="//urepublicana.edu.co/images/web/logo.png" width="30%"></a>
                    <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Nuestra Institución</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="//urepublicana.edu.co/pages/nosotros/" target="_self">Nosotros</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Estructura_Organizacional.pdf" target="_blank">Organigrama</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/PEI_.pdf" target="_blank">PEI</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/plan_de_desarrollo_2020_2026.pdf" target="_blank">Plan de Desarrollo Institucional</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Estatutos.pdf" target="">Estatutos Generales</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Estudiantil-Ag-30-de-2018.pdf" target="_blank">Reglamento Estudiantil</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Docente.pdf" target="_blank">Reglamento Docente</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/autoevaluacion_y_acreditacion.pdf" target="_blank">Auto Evaluación y Acreditación</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/eae/" target="_blank">Escuela de Altos Estudios</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/Politicas_financieras.pdf" target="_blank">Políticas Financieras</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/1654804160.pdf" target="_blank">Protocolo de Bioseguridad</a></li>
                                                <li><a href=" https://urepublicana.edu.co/images/documentos/derechos_pecuniaros_2024.pdf" target="_blank">Valores y Servicios Académicos 2024 (Acuerdo 226 Derechos Pecuniarios 2024)</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/matricula_financiera_valores_de_matricula_2024.pdf" target="_blank">Resolución Rectoral 2 2024 (Matrícula Financiera)</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/resolucion_030025_dic_2023.pdf" target="_blank">Resolución Educación Para el Trabajo y Desarrollo humano</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Estudiantes</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="//urepublicana.edu.co/images/documentos/estudiantes/requisitos_trabajo_profundizacion_2020_actualizado.pdf" target="_blank">Lineamientos Trabajo de Profundización</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/codigos_para_consignacion" target="_blank">Números de Cuenta y Códigos de Consignación</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/biblioteca.php" target="_blank">Biblioteca</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/centro_idiomas/" target="_self">Centro de Idiomas</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/publicaciones_urepublicana/" target="_blank">Publicaciones</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/calendario_académico_2024.pdf" target="_blank">Calendario académico 2024</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/eae/" target="_self">Escuela de Altos Estudios</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/1726771276.pdf" target="_blank">Resolución Rectoral 5</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect">Programas</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li class="no-padding">
                          <ul class="collapsible collapsible-accordion">
                            <li>
                              <a class="collapsible-header waves-effect">Pregrado</a>
                              <div class="collapsible-body nivel_3">
                                <ul>
                                                                        <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/derecho"> Derecho</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/matematicas"> Matemáticas</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/trabajo_social"> Trabajo Social</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/contaduria_publica"> Contaduría Pública</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/ingenieria_industrial"> Ingeniería Industrial</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/ingenieria_de_sistemas"> Ingeniería de Sistemas</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/finanzas_y_comercio_internacional"> Finanzas y Comercio Internacional</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/administracion_de_mercadeo_virtual"> Administración de Mercadeo Virtual</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/finanzas_y_comercio_internacional_virtual"> Finanzas y Comercio Internacional Virtual</a>
                                      </li>
                                                                      </ul>
                              </div>
                            </li>
                          </ul>
                        </li>
                                                <li class="no-padding">
                          <ul class="collapsible collapsible-accordion">
                            <li>
                              <a class="collapsible-header waves-effect">Posgrado</a>
                              <div class="collapsible-body nivel_3">
                                <ul>
                                                                        <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_publico"> Especialización en Derecho Público</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_comercial"> Especialización en Derecho Comercial</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_revisoria_fiscal"> Especialización en Revisoría Fiscal</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_de_familia"> Especialización en Derecho de Familia</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_tributario"> Especialización en Derecho Tributario</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializcion_en_gerencia_financiera"> Especialización en Gerencia Financiera</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_urbanistico"> Especialización en Derecho Urbanístico</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_contratacion_estatal"> Especialización en Contratación Estatal</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_notarial_y_de_registro"> Especialización en Derecho Notarial y de Registro</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_financiero_y_bursatil"> Especialización en Derecho Financiero y Bursátil</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_administrativo"> Especialización en Derecho Administrativo Virtual</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_procesal_constitucional"> Especialización en Derecho Procesal Constitucional</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_intervencion_y_gerencia_social"> Especialización en Intervención y Gerencia Social</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_laboral_y_seguridad_social"> Especialización en Derecho Laboral y Seguridad Social</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_ciencias_criminologicas_y_penales"> Especialización en Ciencias Criminológicas y Penales</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_responsabilidad_civil_y_del_estado"> Especialización en Responsabilidad Civil y del Estado</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_gerencia_de_instituciones_educativas"> Especialización en Gerencia de Instituciones Educativas</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_probatorio_procesal_y_oralidad_judicial"> Especialización en Derecho Probatorio, Procesal y Oralidad Judicial</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_la_responsabilidad_penal_del_servidor_publico_y_los_delitos_contra_la_administracion_publica"> Especialización en la Responsabilidad Penal del Servidor Público y los Delitos Contra la Administración Pública</a>
                                      </li>
                                                                      </ul>
                              </div>
                            </li>
                          </ul>
                        </li>
                                                <li class="no-padding">
                          <ul class="collapsible collapsible-accordion">
                            <li>
                              <a class="collapsible-header waves-effect">Educación Continua</a>
                              <div class="collapsible-body nivel_3">
                                <ul>
                                                                        <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_en_desarrollo_de_software_seguro"> Diplomado en Desarrollo de Software Seguro</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_en_docencia_universitaria_con_enfasis_en_tic"> Diplomado en Docencia Universitaria con Énfasis en TIC</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/Diplomado_de_insolvencia_de_persona_natural_no_comerciante"> Diplomado de Insolvencia de Persona Natural No Comerciante</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/Diplomado_en_gestion_educativa_en_el_contexto_de_la_participacion"> Diplomado en Gestión Educativa en el Contexto de la Participación</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_de_formacion_y_capacitacion_de_conciliadores_en_derecho"> Diplomado de Formación y Capacitación de Conciliadores en Derecho</a>
                                      </li>
                                                                      </ul>
                              </div>
                            </li>
                          </ul>
                        </li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="//urepublicana.edu.co/pages/bienestar/">Bienestar</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Docentes</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Docente.pdf" target="_blank">Reglamento Docente</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/eae/" target="_blank">Escuela de Altos Estudios</a></li>
                                                <li><a href="https://virtualrepublicana.com/" target="_blank">Campus Virtual</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Servicios</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="http://outlook.com/urepublicana.edu.co" target="_blank">Correo Electrónico</a></li>
                                                <li><a href="http://academiaurepublicana.org/ArKa/test/new_login.php" target="_blank">Consulta de Notas</a></li>
                                                <li><a href="https://academiaurepublicana.org/cur5/reporte1.php" target="_blank">Registro de Notas (Docente)</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/pagos_en_linea" target="_blank">Pagos en Línea</a></li>
                                                <li><a href="https://www.pagosvirtualesavvillas.com.co/personal/pagos/1620" target="_self">Pago en línea AV VILLAS</a></li>
                                                <li><a href=" https://urepublicana.edu.co/images/documentos/1683941661.pdf" target="_blank">Instructivo pagos en línea AV-VILLAS</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="https://republicanaradio.com/">Radio</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="//urepublicana.edu.co/pages/investigacion/">Investigación</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="//urepublicana.edu.co/pages/internacionalizacion/">Internacionalización</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="//urepublicana.edu.co/pages/egresados/">Egresados</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Autoevaluación</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="https://urepublicana.edu.co/images/documentos/autoevaluacion_y_acreditacion.pdf" target="_blank">Acreditación y Autoevaluación</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/autoevaluacion.pdf" target="_blank"> Modelo de Aseguramiento de la Calidad</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="https://urepublicana.edu.co/pages/ccaac/">Centro Conciliación</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                    <li><a href="#"><br></a></li>
        <li><a href="#"><br></a></li> 
      </ul>
      <!-- FIN MENU MOBILE -->
      <div class="row">
        <ul class="right nav_urep">
                        <li class="nav_main"><a class="enlace_menu" target="" href="#!" name="#70">Docentes</a></li>
                            <li class="nav_main"><a class="enlace_menu" target="" href="//urepublicana.edu.co/pages/bienestar/" name="URL_MASTER/pages/bienestar/">Bienestar</a></li>
                            <li class="nav_main"><a class="enlace_menu" target="" href="#programas" name="#programas">Programas</a></li>
                            <li class="nav_main"><a class="enlace_menu" target="" href="#!" name="#20">Estudiantes</a></li>
                            <li class="nav_main"><a class="enlace_menu" target="" href="#!" name="#10">Nuestra Institución</a></li>
                      </ul>
        <ul class="right nav_urep nav_aux">
                        <li><a class="enlace_menu" target="_self" href="https://urepublicana.edu.co/pages/ccaac/" name="https://urepublicana.edu.co/pages/ccaac/">Centro Conciliación</a></li>
                            <li><a class="enlace_menu" target="" href="#60" name="#60">Autoevaluación</a></li>
                            <li><a class="enlace_menu" target="" href="//urepublicana.edu.co/pages/egresados/" name="//urepublicana.edu.co/pages/egresados/">Egresados</a></li>
                            <li><a class="enlace_menu" target="" href="//urepublicana.edu.co/pages/internacionalizacion/" name="//urepublicana.edu.co/pages/internacionalizacion/">Internacionalización</a></li>
                            <li><a class="enlace_menu" target="" href="//urepublicana.edu.co/pages/investigacion/" name="//urepublicana.edu.co/pages/investigacion/">Investigación</a></li>
                            <li><a class="enlace_menu" target="_blank" href="https://republicanaradio.com/" name="https://republicanaradio.com/">Radio</a></li>
                            <li><a class="enlace_menu" target="" href="#50" name="#50">Servicios</a></li>
                      </ul>
      </div>
    </div>
  </div>
  <!-- FIN MENU -->

  
        <div id="70" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Docentes</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Docente.pdf">Reglamento Docente</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/eae/">Escuela de Altos Estudios</a></li>
                                                <li><a target="_blank" href="https://virtualrepublicana.com/">Campus Virtual</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Docentes.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
            <div id="60" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Autoevaluación</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/autoevaluacion_y_acreditacion.pdf">Acreditación y Autoevaluación</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/autoevaluacion.pdf"> Modelo de Aseguramiento de la Calidad</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Autoevaluación.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
            <div id="20" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Estudiantes</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/estudiantes/requisitos_trabajo_profundizacion_2020_actualizado.pdf">Lineamientos Trabajo de Profundización</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/codigos_para_consignacion">Números de Cuenta y Códigos de Consignación</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/biblioteca.php">Biblioteca</a></li>
                                                <li><a target="_self" href="https://urepublicana.edu.co/pages/centro_idiomas/">Centro de Idiomas</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/publicaciones_urepublicana/">Publicaciones</a></li>
                                                  </ul></div><div class="col m4"><ul>                        <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/calendario_académico_2024.pdf">Calendario académico 2024</a></li>
                                                <li><a target="_self" href="https://urepublicana.edu.co/pages/eae/">Escuela de Altos Estudios</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/1726771276.pdf">Resolución Rectoral 5</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Estudiantes.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
            <div id="10" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Nuestra Institución</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_self" href="//urepublicana.edu.co/pages/nosotros/">Nosotros</a></li>
                                                <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Estructura_Organizacional.pdf">Organigrama</a></li>
                                                <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/PEI_.pdf">PEI</a></li>
                                                <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/plan_de_desarrollo_2020_2026.pdf">Plan de Desarrollo Institucional</a></li>
                                                <li><a target="" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Estatutos.pdf">Estatutos Generales</a></li>
                                                  </ul></div><div class="col m4"><ul>                        <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Estudiantil-Ag-30-de-2018.pdf">Reglamento Estudiantil</a></li>
                                                <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Docente.pdf">Reglamento Docente</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/autoevaluacion_y_acreditacion.pdf">Auto Evaluación y Acreditación</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/eae/">Escuela de Altos Estudios</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/Politicas_financieras.pdf">Políticas Financieras</a></li>
                                                  </ul></div><div class="col m4"><ul>                        <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/1654804160.pdf">Protocolo de Bioseguridad</a></li>
                                                <li><a target="_blank" href=" https://urepublicana.edu.co/images/documentos/derechos_pecuniaros_2024.pdf">Valores y Servicios Académicos 2024 (Acuerdo 226 Derechos Pecuniarios 2024)</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/matricula_financiera_valores_de_matricula_2024.pdf">Resolución Rectoral 2 2024 (Matrícula Financiera)</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/resolucion_030025_dic_2023.pdf">Resolución Educación Para el Trabajo y Desarrollo humano</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Nuestra Institución.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
            <div id="50" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Servicios</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_blank" href="http://outlook.com/urepublicana.edu.co">Correo Electrónico</a></li>
                                                <li><a target="_blank" href="http://academiaurepublicana.org/ArKa/test/new_login.php">Consulta de Notas</a></li>
                                                <li><a target="_blank" href="https://academiaurepublicana.org/cur5/reporte1.php">Registro de Notas (Docente)</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/pagos_en_linea">Pagos en Línea</a></li>
                                                <li><a target="_self" href="https://www.pagosvirtualesavvillas.com.co/personal/pagos/1620">Pago en línea AV VILLAS</a></li>
                                                  </ul></div><div class="col m4"><ul>                        <li><a target="_blank" href=" https://urepublicana.edu.co/images/documentos/1683941661.pdf">Instructivo pagos en línea AV-VILLAS</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Servicios.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
      

  <!-- Programas -->
  <div id="programas" class="menu_det ocultar">
    <div class="menu_all">
      <div class="container"  >
        <div class="row">
          <h4 class="center-align" style="color:white !important;">Programas</h4>
          <div class="col m3">
            <ul>
                              <li><a class="enlace_menu_2" name="#prom_Profesional" href="#">Pregrado</a></li>
                              <li><a class="enlace_menu_2" name="#prom_Posgrado" href="#">Posgrado</a></li>
                              <li><a class="enlace_menu_2" name="#prom_Diplomado" href="#">Educación Continua</a></li>
                            <!-- <li><a class="enlace_menu_2" name="#prom_edcontinua" href="#">Educación Continuada</a></li> -->
            </ul>
          </div>
          <div class="col m9" >
                       <ul id="prom_Profesional" class="programas ocultar">
                                <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/derecho"> Derecho</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/matematicas"> Matemáticas</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/trabajo_social"> Trabajo Social</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/contaduria_publica"> Contaduría Pública</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/ingenieria_industrial"> Ingeniería Industrial</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/ingenieria_de_sistemas"> Ingeniería de Sistemas</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/finanzas_y_comercio_internacional"> Finanzas y Comercio Internacional</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/administracion_de_mercadeo_virtual"> Administración de Mercadeo Virtual</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/finanzas_y_comercio_internacional_virtual"> Finanzas y Comercio Internacional Virtual</a>
                  </li>
                   </div>
                              </ul>
                      <ul id="prom_Posgrado" class="programas ocultar">
                                <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_publico"> Especialización en Derecho Público</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_comercial"> Especialización en Derecho Comercial</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_revisoria_fiscal"> Especialización en Revisoría Fiscal</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_de_familia"> Especialización en Derecho de Familia</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_tributario"> Especialización en Derecho Tributario</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializcion_en_gerencia_financiera"> Especialización en Gerencia Financiera</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_urbanistico"> Especialización en Derecho Urbanístico</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_contratacion_estatal"> Especialización en Contratación Estatal</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_notarial_y_de_registro"> Especialización en Derecho Notarial y de Registro</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_financiero_y_bursatil"> Especialización en Derecho Financiero y Bursátil</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_administrativo"> Especialización en Derecho Administrativo Virtual</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_procesal_constitucional"> Especialización en Derecho Procesal Constitucional</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_intervencion_y_gerencia_social"> Especialización en Intervención y Gerencia Social</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_laboral_y_seguridad_social"> Especialización en Derecho Laboral y Seguridad Social</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_ciencias_criminologicas_y_penales"> Especialización en Ciencias Criminológicas y Penales</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_responsabilidad_civil_y_del_estado"> Especialización en Responsabilidad Civil y del Estado</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_gerencia_de_instituciones_educativas"> Especialización en Gerencia de Instituciones Educativas</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_probatorio_procesal_y_oralidad_judicial"> Especialización en Derecho Probatorio, Procesal y Oralidad Judicial</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_la_responsabilidad_penal_del_servidor_publico_y_los_delitos_contra_la_administracion_publica"> Especialización en la Responsabilidad Penal del Servidor Público y los Delitos Contra la Administración Pública</a>
                  </li>
                   </div>
                              </ul>
                      <ul id="prom_Diplomado" class="programas ocultar">
                                <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_en_desarrollo_de_software_seguro"> Diplomado en Desarrollo de Software Seguro</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_en_docencia_universitaria_con_enfasis_en_tic"> Diplomado en Docencia Universitaria con Énfasis en TIC</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/Diplomado_de_insolvencia_de_persona_natural_no_comerciante"> Diplomado de Insolvencia de Persona Natural No Comerciante</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/Diplomado_en_gestion_educativa_en_el_contexto_de_la_participacion"> Diplomado en Gestión Educativa en el Contexto de la Participación</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_de_formacion_y_capacitacion_de_conciliadores_en_derecho"> Diplomado de Formación y Capacitación de Conciliadores en Derecho</a>
                  </li>
                   </div>
                              </ul>
                    <!-- 
          <ul id="prom_edcontinua" class="programas ocultar" >
            <li><a target="_blank" href="http://urepublicana.edu.co/contratacion-estatal/">Contratación Estatal</a></li>
            <li><a target="_blank" href="http://urepublicana.edu.co/educacion-continuada/derecho-disciplinario-colombiano/">Derecho Disciplinario Colombiano</a></li>
            <li><a target="_blank" href="http://urepublicana.edu.co/educacion-continuada/regimen-disciplinario-de-las-fuerzas-militares/">Regimen Disciplinario de las Fuerzas Militares</a></li>
            <li><a target="_blank" href="http://urepublicana.edu.co/educacion-continuada/diplomado-en-formacion-y-capacitacion-de-conciliadores/">Diplomado en Formación y Capacitación de Conciliadores</a></li>
          </ul>
        -->
      </div>
     <!-- <div class="col m2">
        <img src="//urepublicana.edu.co/images/web/menu/Programas.png" width="100%">
      </div>  -->
    </div>
  </div>


</div>
</div>
</div>
	<div class="breadcrumb"><a href="//urepublicana.edu.co/pages/index.php"> Inicio </a> > <a href="//urepublicana.edu.co/pages/centro_idiomas.php"> Centro de Idiomas </a></div>
	<div class="container">
		<div class="row center">
			<div class="col s12">
				<h2>Centro de Idiomas</h2>
				<img src="//urepublicana.edu.co/images/web/centro_idiomas/centro_de_idiomas_urepublicana.jpg" width="100%">
			</div>
		</div>
		<div class="row lnk_first">
			<div class="col s12 m2"><br></div>
			<div class="col s3 m2">
				<span class="enlace_urep" name="#idiomas_general">
					<img class="atajo" name="//urepublicana.edu.co/images/web/centro_idiomas/idiomas_general_1.png" src="//urepublicana.edu.co/images/web/centro_idiomas/idiomas_general.png">
					<p>Información General</p>
				</span>
			</div>
			<div class="col s3 m2">
				<span class="enlace_urep" name="#idiomas_acreditacion">
					<img class="atajo" name="//urepublicana.edu.co/images/web/centro_idiomas/idiomas_acredita_1.png" src="//urepublicana.edu.co/images/web/centro_idiomas/idiomas_acredita.png">
					<p>Acreditación del Segundo Idioma</p>
				</span>
			</div>
		<!--	<div class="col s3 m2">
				<span class="enlace_urep" name="#idiomas_curso">
					<img class="atajo" name="//urepublicana.edu.co/images/web/centro_idiomas/idiomas_cursos_1.png" src="//urepublicana.edu.co/images/web/centro_idiomas/idiomas_cursos.png">
					<p>Cursos de Inglés o Francés</p>
				</span>
			</div> -->
			<div class="col s3 m2">
				<span class="enlace_urep" name="#idiomas_resumen">
					<img class="atajo" name="//urepublicana.edu.co/images/web/centro_idiomas/idiomas_resumen_1.png" src="//urepublicana.edu.co/images/web/centro_idiomas/idiomas_resumen.png">
					<p>Opciones de Cumplimiento</p>
				</span>
			</div>
                       <div class="col s3 m2">
                                <span class="enlace_urep" name="#idiomas_curso">
                                        <img class="atajo" name="//urepublicana.edu.co/images/web/centro_idiomas/idiomas_cursos_1.png" src="//urepublicana.edu.co/images/web/centro_idiomas/idiomas_cursos.png">
                                        <p>Asesoría Movilidad Internacional Académica y Laboral</p>
                                </span>
                        </div> 
                        


		</div>
		<div class="row">
			<!-- GENERAL -->
			<div id="idiomas_general" class="col s12 content_urep ocultar">
				<p>
					<h4>Información General</h4>
					<h5>Departamento de Idiomas</h5>
<p align='justify'>El Departamento de Idiomas de la Corporación Universitaria Republicana coordina la participación de los miembros de nuestra comunidad académica en los diferentes procesos de aprendizaje de lenguas extrajeras, así como la coordinación de la internacionalización de nuestros programas académicos a través de la inclusión del estudio y evaluación de lenguas extranjeras en los programas de pregrado y posgrado ofrecidos por la Institución.   </p>
<p>El Departamento de Idiomas ofrece los siguientes servicios a la comunidad académica Republicana:  </p>
					<ul>
						<li><b> * </b>Programas para Educación para el Trabajo y el Desarrollo Humano en Conocimiento Académicos en Inglés y Francés  </li>
						<li><b> * </b>Exámenes de Suficiencia para Clasificación de Competencias</li>
						<li><b> * </b>Soporte académico a través de actualización bibliográfica y substantiva de los currículos de los programas académicos</li>
						<li><b> * </b>Traducción de material de refencia físico y virtual</li>
					</ul>
					<h5>Curso de Inglés y Francés </h5>
<p align='justify'> La Corporación Universitaria Republicana ofrece programas académicos de Educación para el Trabajo y el Desarrollo Humano en Conocimientos Académicos en Inglés y Francés.   </p>			
<p align='justify'> Estos programas académicos tienen las siguientes características: </p>

<h6><b><u>Niveles Disponibles </u></b> </h6>
<br>
    <table style="width: 100%; border-collapse: collapse;">
        <tr>
            <th style="border: 1px solid #dddddd; text-align: left; padding: 8px; background-color: #f2f2f2;">Inglés</th>
            <th style="border: 1px solid #dddddd; text-align: left; padding: 8px; background-color: #f2f2f2;">Francés</th>

        </tr>
        <tr>
            <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Nivel A1</td>
            <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Nivel A1</td>
        </tr>
        <tr>
            <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Nivel A2</td>
            <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Nivel A2</td>
        </tr>
	<tr>
            <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Nivel B1</td>
            <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Nivel B1</td>
        </tr>
	<tr>
            <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Nivel B2</td>
            <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Nivel B2</td>
        </tr>
</table>

<br>

<p align='justify'>Estos niveles están homogenizados de conformidad con el Marco Común Europeo de Referencia para el Estudio de Lenguas Extranjeras. </p>

<p align='justify'>Estos niveles son certificables de conformidad con la Resolución No 030025 de Diciembre 27 de 2023 de la Secretaria de Educación de Bogotá, D.C. </p>
<p align='justify'>La Corporación Universitaria Republicana se reserva el derecho de abrir un nivel respectivo hasta que el cupo mínimo de estudiantes haya cancelado el valor a pagar de forma total por cada uno de los interesados.</p>





			</div>
			<!-- ACREDITACION -->
			<div id="idiomas_acreditacion" class="col s12 content_urep ocultar">
				<div class="row">
					<div class="col s12 m3">
						<ul>
							<li name="#acredita_lineamientos" class="enlace_inter"> Lineamientos Generales</li>
							<li name="#acredita_opciones" class="enlace_inter"> Opciones de Cumplimiento</li>
							<li name="#acredita_procedimiento" class="enlace_inter"> Procedimiento para Acreditar un Segundo Idioma</li>
						<!--	<li name="#acredita_cursos" class="enlace_inter"> Curso de Inglés o Francés</li> -->
						</ul>
					</div>
					<div class="col s12 m9">
						<!-- LINEAMIENTOS -->
						<div id="acredita_lineamientos" class="content_inter ocultar">
							
 						<h5>Lineamientos Generales</h5>
<p align='justify'>De conformidad con el Artículo 39 del Reglamento Estudiantil de la Corporación Universitaria Republicana, se constituye como requisito para optar el título de pregrado, contar con suficiencia en una  lengua extranjera, sin perjuicio de otros requisitos de grado, de conformidad con los siguientes lineamientos:</p>
<ul>
<li><b>*</b>La Institución por intermedio del Departamento de Idiomas realizará al estudiante que lo solicite un examen de inglés a través del cual se definirá su nivel de suficiencia en el idioma.</li>

<li><b>*</b>Si el estudiante no acredita un nivel B1 en las 4 competencias (Reading, Speaking, Writing, y Listening) de acuerdo con los resultados del examen, el estudiante deberá optar por una de las opciones de cumplimiento del requisito de segunda lengua para optar por el título de pregrado. </li>

<li><b>*</b>Después de aprobados los niveles de inglés ofrecidos en los planes de estudios de los programas pregrado, el estudiante deberá costearse los demás cursos necesarios para lograr las competencias requeridas, bien sea en la Institución o fuera de ella. </li>

<li><b>*</b>Si es fuera de ella, deberá presentar el certificado de una entidad reconocida oficialmente y se realizará examen de suficiencia a discreción del Departamento de Idiomas en caso de ser necesario para verificar la suficiencia en B1 de las 4 competencias (Reading, Speaking, Writing, y Listening). </li>

<li><b>*</b>El estudiante que no acredite las competencias exigidas (B1 en las 4 competencias (Reading, Speaking, Writing, y Listening)  no podrá optar por el título hasta tanto no cumpla con las mismas.</li>

<li><b>*</b>La Corporación Universitaria Republicana establece el inglés como segunda lengua extranjera. Sin embargo, este requisito será satisfecho por estudiantes que acrediten suficiencia en otro idioma diferente al inglés cuando se trate de un nivel de conocimiento en dicho idioma que sea comparable al nivel de conocimiento de inglés aquí requerido.</li>

<li><b>*</b>La acreditación de la suficiencia en una lengua extranjera, inglés o de otra lengua extranjera diferente al mismo, es obligatoria para los estudiantes de pregrado que ingresaron o reingresaron bajo el sistema de créditos académicos.</li>

<li><b>*</b>Cada estudiante debe cubrir el valor de los cursos de capacitación o formación y exámenes internacionales de acreditación que escoja para satisfacer el requisito de segunda lengua como requisito de grado.</li>
</ul>				
		
						</div>
						<!-- OPCIONES -->
						<div id="acredita_opciones" class="content_inter ocultar">
								<h5> Opciones de Cumplimiento </h5>
<p align='justify'>
La Corporación Universitaria Republicana tiene disponible las siguientes opciones para el cumplimiento del requisito de la competencia en una segunda lengua para optar para el título de pregrado en modalidad presencial o virtual: 
</p>
<ul>
<li><b>1.</b> Examen de Acreditación Internacional. </li>

<li><b>2.</b> Intercambio Académico y/o Cultural validado por el Departamento de Idiomas y la Oficina de Relaciones Internacionales de la Corporación Universitaria Republicana.</li>

<li><b>3.</b> Certificación expedida por la Corporación Universitaria Republicana del cumplimiento del Nivel B1 en los Programas de Educación para el Trabajo y el Desarrollo Humano en Conocimientos Académicos de Inglés o Francés.</li>
<li><b>4.</b>Verificación interna de cumplimiento del requisito de suficiencia en una segunda lengua con los cursos de inglés realizados en el Centro de idiomas de la Corporación Universitaria Republicana, que no son Programas para el Trabajo y el Desarrollo Humano en Conocimientos Académicos de inglés o francés. 
</li>
</ul>
<p align='justify'>
Cada estudiante debe cubrir el valor de los cursos de capacitación, exámenes, o intercambios que escoja para satisfacer el requisito de la segunda lengua extranjera como requisito de grado.
</p>
<p align='justify'>
Los estudiantes que presenten resultados de exámenes que no son exámenes de acreditación internacional o que no hayan evaluado simultáneamente las cuatro (4) competencias dentro del Marco Común Europeo de Referencia (Reading, Listening, Speaking, Writing) deberán acreditar un Nivel B2 en el examen respectivo para el cumplimiento del requisito de segunda lengua.

</p>

<p align='justify'>La validez en el tiempo de las Opciones de Cumplimiento son:</p>


<ol>

<li>El Examen de Acreditación Internacional presentado por un estudiante debe tener una  vigencia no superior a 12 meses.</li>



<li>El certificado del Intercambio Académico y/o Cultural validado por el Departamento de Idiomas y la Oficina de Relaciones Internacionales de la Corporación Universitaria Republicana presentado por un estudiante debe tener una  vigencia no superior a 18 meses.</li>



<li>Los Exámenes que no son exámenes de acreditación internacional o que no hayan evaluado simultáneamente las cuatro (4) competencias dentro del Marco Común Europeo de Referencia (Reading, Listening, Speaking, Writing) presentado por un estudiante debe tener una  vigencia no superior a 12 meses. </li>

</ol>

<p align='justify'>El estudiante podrá optar libremente entre los Cursos de Inglés Internos (Niveles 4,5, y 6) ofrecidos por la Corporación Universitaria Republicana que no son certificables, y los Niveles A1, A2, B1, y B2 que son certificables bajo la Resolución No 030025 de Diciembre 27 de 2023 de la Secretaria de Educación de Bogotá, D.C.”  </p>




						</div>
						<!-- PROCEDIMIENTO -->
						<div id="acredita_procedimiento" class="content_inter ocultar">
								<h5> Procedimiento para Acreditar un Segundo Idioma </h5>
<p align='justify'>
Los estudiantes de pregrado de la Corporación Universitaria Republicana pueden escoger cualquiera de las opciones de acreditación  mencionadas anteriormente
Una vez el estudiante ha obtenido los respectivos certificados de los exámenes de acreditación internacional o de los intercambios académicos y/o culturales deberá surtir el siguiente procedimiento:
</p>
<ul>

<li><b>•</b> Presentar y radicar el certificado de acreditación o realización de intercambios respectivos en original ante el Departamento de Idiomas para la verificación del cumplimiento de la competencia en segunda lengua.</li>

<li><b>•</b> Una vez realizada la verificación, el Departamento de Idiomas lo remitirá para la aprobación a la Oficina de Registro y Control.</li>

<li><b>•</b> Para acreditar la suficiencia en idiomas distintos al inglés, el estudiante deberá presentar ante el Departamento de Idiomas de la Corporación Universitaria Republicana un certificado expedido por una institución debidamente reconocida y habilitada para estos efectos, avalada por Entidades Oficiales, o presentando el certificado del examen internacional en el cual se acrediten competencias razonablemente equivalentes a las establecidas en el presente comunicado para la lengua extranjera Inglés.</li>

<li><b>•</b> Cada estudiante deberá consultar ante el Departamento de Idiomas previo a la realización de un examen particular, la suficiencia de dicho examen, para satisfacer los requisitos de segundo idioma.</li>

<li><b>•</b> Es responsabilidad de cada estudiante cubrir los costos de capacitación dela segunda lengua extranjera así como los costos asociados con los exámenes de acreditación internacional e intercambios internacionales.</li>

<li><b>•</b> La Oficina de Registro y Control expedirá el respectivo certificado a los estudiantes que terminen el Nivel B1 a través de los programas académicos de Educación para el Trabajo y el Desarrollo Humano en Inglés o Francés ofrecidos por la Institución. </li>

</ul>


						</div>
						<!-- CURSO INGLES FRANCES -->
						<div id="acredita_cursos" class="content_inter ocultar">
							<p>
								<h5>Curso de Inglés o Francés</h5>
								El Curso de Inglés o Francés ofrecido por el Departamento de Idiomas de la Corporación Universitaria Republicana tiene las siguientes características:
								<ul>
									<li><b>*</b> Los estudiantes pueden Optar por los Niveles/Módulos de Inglés o Francés Dentro de Convenio o Fuera de Convenio con la Corporación Iberoamericana De Estudios Jurídicos, Económicos Políticos Y Sociales</li>
									<li><b>*</b> El estudiante puede escoger solamente una vez si toma o no el Curso de Inglés o Francés a través del Convenio con la Corporación Iberoamericana De Estudios Jurídicos, Económicos Políticos Y Sociales para el cumplimiento del Requisito de Inglés. Una vez opte por el convenio no podrá cambiar esta alternativa, independientemente del resultado del puntaje de su examen de clasificación, y deberá cursos los Niveles/Módulos que correspondan para alcanzar el Nivel 7/Modulo B1</li>
									<li><b>*</b> El Costo de Cada Nivel (Modulo) será definido en el Acuerdo del Consejo Superior que defina los Derechos Pecuniarios del Semestre Académico respectivo</li>
									<li><b>*</b> El Departamento de Idiomas de la Corporación Universitaria Republicana se reserva el derecho de abrir un curso respectivo hasta que el cupo mínimo de 20 estudiantes haya cancelado el valor a pagar</li>
									<li><b>*</b> Los estudiantes de pregrado que escojan el Curso de Ingles Fuera de Convenio con la Corporación Iberoamericana De Estudios Jurídicos, Económicos Políticos Y Sociales pueden solicitar la Homologación de los tres primeros niveles de inglés aprobados ante la respectiva Facultad anexando el recibo de homologación y un certificado de notas. El estudiante que no opte por el Convenio deberá siempre completar los Niveles 4, 5, 6 de la respectiva segunda lengua, salvo que acredite el cumplimiento del requisito de grado a través de un examen de acreditación internacional o un intercambio académico o cultural</li>
								</ul>
							</p>
						</div>
					</div>
				</div>
			</div>
			<!-- CURSOS INGLES - FRANCES -->
			<div id="idiomas_curso" class="col s12 content_urep ocultar">
					<h4>Asesoría para Movilidad Internacional Académica y Laboral </h4>
<p align='justify'>La Oficina de Relaciones Internacionales publicara semestralmente los proveedores de servicios reconocidos por la Corporación Universitaria Republicana para presentar ofertas de movilidad académica y laboral a los estudiantes activos y egresados de los programas de pregrado y posgrado presenciales y virtuales. </p>


<p align='justify'>
<a href='https://urepublicana.edu.co/images/documentos/resolucion_030025_dic_2023.pdf' target='_blank'>Resolución 030025 de Diciembre 27 de 2023 de la Secretaria de Educación de Bogotá, D.C.</a>
 </p>
<p align='justify'>
<a href='https://urepublicana.edu.co/images/documentos/resolucion_5_de_2024.pdf' target='_blank'>Resolución Rectoral 5 de 2024 D.C.</a>
</p>


<h5>Oferta Académica</h5>
 
<p align='justify'>Los proveedores de servicios reconocidos por la Corporación Universitaria Republicana deberán informar a los estudiantes activos y egresados de los programas de pregrado y posgrado presenciales y virtuales de: </p>
<ol>

<p align='justify'>
<li>
Oportunidades Académicas en el extranjero para continuar estudios de pregrado, maestría, y doctorado.</li> 
<li>
Oportunidades Académicas para la trasferencia de créditos académicos cursados y aprobados en la Corporación Universitaria Republicana a un programa de pregrado, maestría, o doctorado en el extranjero.</li>
<li>
Oportunidades Académicas en el extranjero para realizar prácticas profesionales de carácter semestral o anual.</li>
<li>
Oportunidades Académicas en el extranjero para realizar prácticas profesionales de menor duración cuyo objetivo es la inmersión académica y profesional en un área determina y cuya terminación conlleva la adquision de una o más competencias específicas aplicables a los  programas de pregrado y posgrado presenciales y virtuales ofrecidos por la Corporación Universitaria Republicana. </li>
</p>
</ol>


<h5>Ofertas Laborales </h5>
 
<p align='justify'>Los proveedores de servicios reconocidos por la Corporación Universitaria Republicana deberán informar a los estudiantes activos y egresados de los programas de pregrado y posgrado presenciales y virtuales de:  </p>
<ol>

<p align='justify'>
<li>
Oportunidades de trabajo remoto con empresas extranjeras en base a la cualificación académica y experiencia profesional de los estudiantes activos y egresados de los programas de pregrado y posgrado presenciales y virtuales ofrecidos por la Corporación Universitaria Republicana.</li> 
<li>
Oportunidades de trabajo en el extranjero en base a la cualificación académica y experiencia profesional de los estudiantes activos y egresados de los programas de pregrado y posgrado presenciales y virtuales ofrecidos por la Corporación Universitaria Republicana.</li>
<li>
Oportunidades de Capacitación Académica que resulten en Certificaciones Laborales que expandan el perfil profesional de los estudiantes activos y egresados de los programas de pregrado y posgrado presenciales y virtuales ofrecidos por la Corporación Universitaria Republicana con empleadores en el extranjero.</li>
<li>
Programas de Inmigración individual o familiar en base a la cualificación académica y experiencia profesional de los estudiantes activos y egresados de los programas de pregrado y posgrado presenciales y virtuales ofrecidos por la Corporación Universitaria Republicana. </li>
</p>
</ol>





			

			</div>
			<div id="idiomas_resumen" class="col s12 content_urep content_inter ocultar">
				<p>	
					<h5 class="center">
						Requisito de Grado de Segunda Lengua para los Programas de Pregrado de la Corporación Universitaria Republicana
					</h5>
					<h5 class="admision_proceso"><span>1</span> Opciones de Cumplimiento </h5>
					<ul>
						<li><b>1.</b> Examen de Acreditación Internacional.</li>
						<li><b>2.</b>Intercambio Académico y/o Cultural validado por el Departamento de Idiomas y la Oficina de Relaciones Internacionales de la Corporación Universitaria Republicana.</li>
						<li><b>3.</b>Certificación expedida por la Corporación Universitaria Republicana del cumplimiento del Nivel B1 en los Programas de Educación para el Trabajo y el Desarrollo Humano en Conocimientos Académicos de Inglés o Francés.  </li>
                                                <li><b>4.</b>Verificación interna de cumplimiento del requisito de suficiencia en una segunda lengua con los cursos de inglés realizados en el Centro de idiomas de la Corporación Universitaria Republicana, que no son Programas para el Trabajo y el Desarrollo Humano en Conocimientos Académicos de inglés o francés. </li>


					</ul>
					<h5 class="admision_proceso"><span>2</span> Examen de Acreditación Internacional</h5>
					
<p align='justify'>La Corporación Universitaria Republicana reconoce los siguientes exámenes de acreditación internacional del idioma Ingles para el cumplimiento del requisito de la competencia en una segunda lengua para optar para el título de pregrado en modalidad presencial o virtual:</p>

					<ul>
						<li><b>*</b> TOEFL iBT </li>
						<li><b>*</b> IELTS </li>
						<li><b>*</b> MICHIGAN ECCE o MICHIGAN MET  </li>
					</ul>

<p align='justify'>Los puntajes mínimos requeridos en los exámenes de acreditación internacional son:  </p>

<p align='justify'>1. Equivalencias del nivel B1 en el TOEFL iBT, desglosada por cada una de las secciones del examen: Reading, Listening, Speaking y Writing:  </p>

    <img width="100%" class="responsive-img" src=" https://urepublicana.edu.co/images/documentos/1724524574.jpg">

<p align='justify'>2. Equivalencias del nivel B1 en el IELTS, desglosada por cada una de las secciones del examen: Reading, Listening, Speaking y Writing: </p>

    <img width="100%" class="responsive-img" src=" https://urepublicana.edu.co/images/documentos/1724524728.jpg">

<p align='justify'>3. Equivalencias del nivel B1 en el MICHIGAN, desglosada por cada una de las secciones del examen: Reading, Listening, Speaking y Writing:</p>


    <img width="100%" class="responsive-img" src=" https://urepublicana.edu.co/images/documentos/1724524807.jpg">



					<h5 class="admision_proceso"><span>3</span> Intercambio Internacional</h5>
<p align='justify'>La Corporación Universitaria Republicana permite acreditar el equivalente a un Nivel  B1 en Inglés del Marco Común Europeo a través de la realización de uno (1) o más Intercambio(s) Académico(s) y/o Cultural(es) durante el transcurso de los estudios de pregrado a partir del tercer (3) Semestre de un programa de pregrado presencial o virtual. </p>

<p align='justify'>La Corporación Universitaria Republicana reconoce los siguientes tipos de intercambios académicos: </p>
<ul>

<li><b>1.</b> Programa de Inmersión en Segunda Lengua en el extranjero con un mínimo de 900 horas presenciales de clase certificadas en una Institución de Enseñanza con Acreditación vigente.</li>

<li><b>2.</b> Programas de Inmersión Cultural en Segunda Lengua en el extranjero con un mínimo de 14 meses de presencia física continua en el extranjero que requiera la utilización adecuada y constante del Segundo Idioma y el aprendizaje de la cultura del país extranjero.</li> 

<li><b>3.</b> Programa combinado de estudio intensivo de una segunda lengua de forma virtual con una Institución de Enseñanza Internacional con un mínimo de horas de estudio equivalentes al Nivel B1 del Marco Común Europeo y la realización de un Intercambio Cultural en el extranjero con un mínimo de 40 horas de practica en el extranjero del Segundo Idioma y el aprendizaje de la cultura del país extranjero.</li>
</ul>		


<p align='justify'>La Oficina de Relaciones Internacionales publicara semestralmente las ofertas de intercambios académicos y/o culturales seleccionadas por la Corporación Universitaria Republicana para la participación de los estudiantes de pregrado presencial o virtual.  </p>

	<h5 class="admision_proceso"><span>4</span>Programas de Educación para el Trabajo y el Desarrollo Humano </h5>
			
<p align='justify'>De conformidad con la Resolución 030025 del 27 de Diciembre de 2023 de la Secretaria de Educación de Bogotá (Dirección Local de Educación de Santa Fe y la Candelaria) la Corporación Universitaria Republicana se encuentra facultada para ofrecer los Programas Académicos de Educación para el Trabajo y el Desarrollo Humano en Conocimientos Académicos de Inglés y Francés en los niveles A1, A2, B1, y B2. </p>
<p align='justify'>La aprobación del Nivel B1 de los Programas Académicos de Educación para el Trabajo y el Desarrollo Humano en Conocimientos Académicos de Inglés y Francés de la Corporación Universitaria Republicana satisface el cumplimiento del requisito de la Competencia en un Segundo idioma para optar para el título de pregrado en modalidad presencial o virtual. </p>

<p align='justify'>A partir de Agosto 1 de 2024, los estudiantes activos de los programas de pregrado presenciales y virtuales recibirán la siguiente homologación académica cuando opten por los Programas Académicos de Educación para el Trabajo y el Desarrollo Humano en Conocimientos Académicos de Inglés y Francés para el cumplimiento del requisito de la Competencia en un Segundo idioma para optar para el título de pregrado en modalidad presencial o virtual: </p>

    <img  width='100%' class="responsive-img" src="https://urepublicana.edu.co/images/documentos/1717634328.jpg">

    <img  width='100%' class="responsive-img" src="https://urepublicana.edu.co/images/documentos/1717634352.jpg">

<p align='justify'>La homologación académica establecida está sujeta a la aprobación de la totalidad de créditos académicos y asignaturas instruccionales del idioma Ingles de los Planes de Estudio de los programas de Pregrado Presenciales y Virtuales. </p>
          </div>
		</div>
	</div>

<div class="container">
<div class="row">
<div class="col s12 m12">
 ﻿		<form id="form_new_general" action="https://hooks.zapier.com/hooks/catch/18595865/3jhfb2z/" method="POST" class="col s12" enctype="multipart/form-data">
			<center><h4><div class=' z-depth-2' style='color: #002849; padding-top: 1px;padding-bottom:4px;background-image: linear-gradient(to left,rgb(250,202,0),rgb(255,248,211),rgb(200,149,26));'>    
<h4 style='color: #002849 !important;'>¡QUIERO MÁS INFORMACIÓN!
</h4>
    <h6 >Déjanos tus datos, un asesor se pondrá en contacto</h6>
    
    </div></h4></center>
			<div id="cont_nombres" class="input-field col s12 m12 validate">
<input type="text" id="nombres" name="nombres" class="validate" data-error=".error_nombres">
			<label for="nombres">Nombres </label>
			<div class="error_form error_nombres"></div>
		</div>
		<div id="cont_ema" class="input-field col s12 m6 validate">
<input type="email" id="ema" name="ema" class="validate" data-error=".error_ema">
			<label for="ema">Correo Electrónico </label>
			<div class="error_form error_ema"></div>
		</div>
		<div id="cont_cel" class="input-field col s12 m6 validate">
<input type="number" id="cel" name="cel" class="validate" data-error=".error_cel">
			<label for="cel">Número Celular </label>
			<div class="error_form error_cel"></div>
		</div>
				<div id="cont_pro" class="input-field col s12 m12 validate">
			<select required  id="pro" name="pro"   class="validate" data-error=".error_pro">
				<option  value="" >Seleccione una opción</option>
										<option value="INGLÉS A1" >INGLÉS A1</option>
												<option value="INGLÉS A2" >INGLÉS A2</option>
												<option value="INGLÉS B1" >INGLÉS B1</option>
												<option value="INGLÉS B2" >INGLÉS B2</option>
												<option value="FRANCÉS A1" >FRANCÉS A1</option>
												<option value="FRANCÉS A2" >FRANCÉS A2</option>
												<option value="FRANCÉS B1" >FRANCÉS B1</option>
												<option value="FRANCÉS B2" >INGLÉS B2</option>
												<option value="Intercambio Internacional (Pregrado, Posgrado)" >Intercambio Internacional (Pregrado, Posgrado)</option>
												<option value="Intercambio Internacional (Maestría, Doctorado)" >Intercambio Internacional (Maestría, Doctorado)</option>
												<option value="Intercambio Internacional Cultural (Au Pair, Camp Counselor, etc)" >Intercambio Internacional Cultural (Au Pair, Camp Counselor, etc)</option>
												<option value="Intercambio Internacional (Inmersión Inglés)" >Intercambio Internacional (Inmersión Inglés)</option>
												<option value="Intercambio Internacional (Inmersión Inglés 40 Horas)" >Intercambio Internacional (Inmersión Inglés 40 Horas)</option>
												<option value="Oferta Laboral Internacional (Remoto)" >Oferta Laboral Internacional (Remoto)</option>
												<option value="Oferta Internacional (Presencial)" >Oferta Internacional (Presencial)</option>
									</select>
			<label  for="pro"> Programa al que aspira </label>
			<div class="error_form error_pro"></div>
			<br>
		</div>
		<div id="cont_terminos" class="input-field col s12 m12 validate">
<input type="checkbox" id="terminos" name="terminos" class="validate" data-error=".error_terminos">
			<label for="terminos">Autorizo el tratamiento de mis datos personales a la Corporación Universitaria Republicana conforme a sus<a href='https://urepublicana.edu.co/images/documentos/1649868637.pdf' target='_blank'> Políticas de Protección de Datos Personales</a> </label>
			<div class="error_form error_terminos"></div>
		</div>
		                <div id="terminos" class="input-field col s12 m12 validate">
                      <!--   <p>Autorizo el tratamiento de mis datos personales a la Corporación Universitaria Republicana conforme a sus<a href='https://urepublicana.edu.co/images/documentos/1649868637.pdf' target='_blank'> Políticas de Protección de Datos Personales</a></p> -->
                        
                </div>
                		<div class="input-field col s12 m">
		  <div class="g-recaptcha" data-sitekey="6LdpHhMTAAAAAEdufQp1hh8N02SrSedKBS5ZRqul" data-callback="correctCaptcha"></div>
		<br>
		</div>
				<div class="input-field col m12 center">
		<button name="submit" class="btn-large waves-effect waves-light amber btn_captcha" type="submit" onclick='return validacion()'>
				Enviar			</button>
		</div>
		<div id="cont_origen" class="input-field col s12 m6 ">
<input type="hidden" id="origen" name="origen" value="web-idiomas"  class="" data-error=".error_origen">
                        <label for="origen"> </label>
                        <div class="error_form error_origen"></div>
                </div>

<div id="cont_periodo" class="input-field col s12 m6 ">
<input type="hidden" id="periodo" name="periodo" value="20251"  class="" data-error=".error_periodo">
                        <label for="periodo"> </label>
                        <div class="error_form error_periodo"></div>
                </div>

<div id="cont_rutapdf" class="input-field col s12 m6 ">
<input type="hidden" id="rutapdf" name="rutapdf" value=""  class="" data-error=".error_rutapdf">
                        <label for="rutapdf"> </label>
                        <div class="error_form error_rutapdf"></div>
                </div>

<div id="cont_valormat" class="input-field col s12 m6 ">
<input type="hidden" id="valormat" name="valormat" value=""  class="" data-error=".error_valormat">
                        <label for="valormat"> </label>
                        <div class="error_form error_valormat"></div>
                </div>

			
		</form>
		</div>
</div>
</div>


	<div class="footer-copyright">
  <div class="container">
   <div class="row">
    <div class="col s12 m3 l3 center-align">
      <img src="//urepublicana.edu.co/images/web/footer/1521576084.png" class="logo_footer"><br>
      <i class="contacto" style="background-color: transparent;">
        Iesus Christus hanc dat fructum. Gloria in sancta Trinitate. Et providere nos, misericordem gloriam Dei vivi       </i>
    </div>
    <div class="col s12 m9 l9">
      <div class="row center-align">
        
<a target="_blank" href="https://www.facebook.com/CorporacionUniversitariaRepublicana/" ><img src="//urepublicana.edu.co/images/web/footer/facebook.png" class="social_urep"></a>

<a target="_blank" href="https://twitter.com/URepublicana_?lang=en" ><img src="//urepublicana.edu.co/images/web/footer/twitter.png" class="social_urep"></a>

<a target="_blank" href="https://www.instagram.com/urepublicana/" ><img src="//urepublicana.edu.co/images/web/footer/instagram.png" class="social_urep"></a>

<a target="_blank" href="https://www.youtube.com/channel/UC38BS2DLRSwXvnS_6QnS5Zg" ><img src="//urepublicana.edu.co/images/web/footer/youtube.png" class="social_urep"></a>

<a target="_blank" href="https://www.linkedin.com/in/corporaci%C3%B3n-universitaria-republicana-6bb35110b" ><img src="//urepublicana.edu.co/images/web/footer/linkedin.png" class="social_urep"></a>


<!-- <a target="_blank" href="https://api.whatsapp.com/send?phone=573057498050"><img src="//urepublicana.edu.co/images/web/footer/whatsapp.png" class="social_urep"></a> -->
      </div>
      <div class="left-align row enlaces_urep">
       <div class="col s12 m6 l4">
        <ul>
                        <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/1649868637.pdf">Ley de Protección de datos</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="http://urepublicana.edu.co/trabaje_con_nosotros/">Trabaje con Nosotros</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/codigos_para_consignacion">Listado Códigos de Consignaciones</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/iberoamericana/pages/publicaciones/Institucion/0/nosotros">Convenio Corporación Iberoamericana de Estudios Jurídicos</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/1674235905.pdf">Protocolo para la prevención y atención de casos de violencia y equidad de género</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/footer/directorio_institucional.pdf">Directorio Institucional</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/pages/ccaac/">Centro de Conciliación, Arbitraje y Amigable Composición</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                        </ul>
      </div>
    </div>
  </div>
</div>
</div>
<div class="row center-align contacto">
 Institución de Educación Superior Sujeta a Inspección y Vigilancia por el Ministerio de Educación Nacional, con Personería jurídica reconocida mediante resolución No 3061 del 02 de diciembre de 1999, expedida por el Ministerio de Educación Nacional.<br>  Sede Administrativa: Cr 7 No 19-38 | Horario de atención. lunes a viernes de 8:00 a.m a 8:00 p.m, Sábados:9:00 a.m a 1:00 p.m <br>  PBX: 286 23 84 | Información Admisiones: ext. 143 | www.urepublicana.edu.co <br>  Bogotá, Colombia</div>
<div class="center-align legal">
 &copy; Corporación Universitaria Republicana 2017
</div>
<!-- <script src="http://code.jquery.com/jquery-2.1.4.min.js"></script> -->
<!-- <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script> -->
<script src="//urepublicana.edu.co/assets/js/bootstrap-colorpicker.js"></script>
<script src="//urepublicana.edu.co/assets/js/docs.js"></script>
<!-- VALIDACION -->
<!-- <script src="//urepublicana.edu.co/assets/js/jquery.validate.min.js"></script> -->

<!-- JQUERY VALIDATE -->
<script type="text/javascript" src="//urepublicana.edu.co/assets/js/validation/dist/jquery.validate.min.js"></script>
<script src="//urepublicana.edu.co/assets/js/materialize.min.js"></script>
<script src="//urepublicana.edu.co/assets/js/init.js"></script>
<script type="text/javascript">
  function downloadJSAtOnload() {
    var element = document.createElement("script");
    element.src = "https://www.google.com/recaptcha/api.js";
    document.body.appendChild(element);
  }
  if (window.addEventListener)
    window.addEventListener("load", downloadJSAtOnload, false);
  else if (window.attachEvent)
    window.attachEvent("onload", downloadJSAtOnload);
  else window.onload = downloadJSAtOnload;
</script>




<script type="text/javascript" charset="utf-8">

	function correctCaptcha(){
     	$('button.btn_captcha').removeAttr("disabled");
    }
    
	$(document).ready(function(){
		$('button.btn_captcha').attr("disabled","disabled");
						var objs = [onclick='return validacion()',];
				jQuery.each( objs, function( i, obj ) {
					
					$(obj['origen']).on( obj['accion'] ,function() {
						
						var valores = "{";
							origenes = obj['origen'].split(",");
							jQuery.each( origenes, function( i, origen ) {
								var var_origen = $(origen).val();
								valores+= "'"+origen+"':'"+var_origen+"',"; 		
							});
						valores+="}"; 

						var event = obj['funcion'] +'('+ obj['parametros'] +', '+ valores +' );';
						var rta = eval(event);

						var tipo_tag = $(obj['destino']).prop("tagName");
						
						// SELECT
					

						if (tipo_tag == "SELECT") {
							$(obj['destino']).empty();
							$(obj['destino']).append('<option selected value="">Seleccione una opcion</option>');
							jQuery.each( rta, function( i, val ) {
								$(obj['destino']).append('<option value="'+ val.valor +'">'+ val.texto +'</option>');
							});	
						}
						if (tipo_tag == "DIV") {
							var name = obj['destino'].replace('#','');
							$("."+name).remove();
							jQuery.each( rta, function( i, val ) {
								$(obj['destino']).append('<p><input name="'+name+'" class="'+name+'" id="'+i+'" type="radio" value="'+ val.valor +'"><label class="'+name+'" for="'+i+'">'+ val.texto +'</label></p>');
							});	
						}


					});
				});
		
	// parametros( ids - separados por comas )
	var mostrar = function(ids) {
		var id = ids.split(',');
		jQuery.each( id, function( i, val ) {
			$("#cont_"+val).addClass("mostrar").removeClass("ocultar");
			$("#"+val).addClass("mostrar").removeClass("ocultar");
		});
	};


	// parametros(destino, consulta, valor);
	var cargar_valores = function(clase, metodo, valores) {
		var formData = {clase:clase,metodo:metodo,valores:valores};
		var url = "//urepublicana.edu.co/admin/class/class_metodos_form.php"; // El script a dónde se realizará la petición.
		$.ajax({
		type: "POST",
		url: url,
		async: false,
		data: formData,
			success: function(data){
			valores = jQuery.parseJSON(data);
			}
		});
		return valores;
	};

	// CARGAR VALIDACION INICIAL
	$( "#form_new_general").validate( {
		rules: {
					nombres: {required:true}, 
						ema: {required:true}, 
						cel: {required:true}, 
						pro: {required:true}, 
						terminos: {required:true}, 
						captcha: {}, 
						submit: {}, 
						origen: {required:true}, 
						periodo: {required:true}, 
						rutapdf: {required:true}, 
						valormat: {required:true} 
			//fin de la prueba de validación
		},
		errorElement : 'div',
		errorPlacement: function(error, element) {
			var placement = $(element).data('error');
			if (placement) {
				$(placement).append(error)
			} else {
				error.insertAfter(element);
			}
		}
	});
});
</script>
</body>

<script>
function validacion()
{
indice = document.getElementById("pro").selectedIndex;if( indice == null || indice == 0  || indice == ""  ) { alert('recuerde seleccionar el programa');
return false;}
}
</script>






<!-- Aquí está el script para redirigir después del envío con webhook -->
<script>

const programas = {
  "INGENIERÍA DE SISTEMAS": { rutaPDF: 'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/plan_estudios_ingenieria_de_sistemas.pdf', valorMatricula: '$2.250.000.00',nivel: 'pregrado',usuario_mercadeo:'Usu 2' },
"INGENIERÍA INDUSTRIAL": { rutaPDF: 'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/plan_estudios_ingenieria_industrial.pdf', valorMatricula: '$2.250.000.00',nivel: 'pregrado',usuario_mercadeo:'Usu 2' },

"TRABAJO SOCIAL": { rutaPDF: 'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/plan_estudios_trabajo_social.pdf', valorMatricula: '$2.250.000.00',nivel: 'pregrado',usuario_mercadeo:'Usu 2' },
"MATEMÁTICAS": { rutaPDF: 'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/plan_estudios_matematicas.pdf', valorMatricula: '$2.250.000.00',nivel: 'pregrado',usuario_mercadeo:'Usu 2' },
"DERECHO": { rutaPDF: 'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/plan_estudios_derecho.pdf', valorMatricula: '$2.250.000.00',nivel: 'pregrado',usuario_mercadeo:'Usu 2' },
"FINANZAS Y COMERCIO INTERNACIONAL": { rutaPDF: 'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/plan_estudios_finanzas_comercio_internacional.pdf', valorMatricula: '$2.250.000.00',nivel: 'pregrado',usuario_mercadeo:'Usu 2' },

"FINANZAS Y COMERCIO INTERNACIONAL VIRTUAL": { rutaPDF: 'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/plan_estudios_finanzas_comercio_internacional_virtual.pdf', valorMatricula: '$1.450.000.00',nivel: 'pregrado',usuario_mercadeo:'Usu 2' },

"ADMINISTRACIÓN DE MERCADEO VIRTUAL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/plan_estudios_administracion_de_mercadeo.pdf', valorMatricula: '$1.450.000.00',nivel: 'pregrado',usuario_mercadeo:'Usu 2' },

"CONTADURÍA PÚBLICA": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/plan_estudios_contaduria_publica.pdf', valorMatricula: '$2.250.000.00',nivel: 'pregrado',usuario_mercadeo:'Usu 2' },

"DIPLOMADO EN DESARROLLO DE SOFTWARE SEGURO": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/diplomado_en_desarrollo_software_seguro.pdf', valorMatricula: '$1.400.000.00',nivel: 'diplomado',usuario_mercadeo:'Usu 3' },

"DIPLOMADO DE FORMACIÓN Y CAPACITACIÓN DE CONCILIADORES EN DERECHO": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/diplomado_en_formacion_capacitacion_de_conciliadores.pdf', valorMatricula: '$1.650.000.00',nivel: 'diplomado',usuario_mercadeo:'Usu 3'  },
"DIPLOMADO DE INSOLVENCIA DE PERSONA NATURAL NO COMERCIANTE": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/diplomado_en_insolvencia_de_persona_natural.pdf', valorMatricula: '$1.400.000.00',nivel: 'diplomado',usuario_mercadeo:'Usu 3'  },

"DIPLOMADO EN DOCENCIA UNIVERSITARIA CON ÉNFASIS EN TIC": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/diplomado_en_docencia_universitaria.pdf', valorMatricula: '$1.400.000.00',nivel: 'diplomado',usuario_mercadeo:'Usu 3'  },

"DIPLOMADO EN GESTIÓN EDUCATIVA EN EL CONTEXTO DE LA PARTICIPACIÓN": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/diplomado_en_gestion_educativa.pdf', valorMatricula: '$1.400.000.00',nivel: 'diplomado',usuario_mercadeo:'Usu 3'  },
"ESP. EN DERECHO PÚBLICO": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN DERECHO NOTARIAL Y DE REGISTRO": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3'  },
"ESP. EN DERECHO PROCESAL CONSTITUCIONAL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN DERECHO LABORAL Y SEGURIDAD SOCIAL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN LA RESPONSABILIDAD PENAL DEL SERVIDOR PÚBLICO Y LOS DELITOS CONTRA LA ADMINISTRACIÓN PÚBLICA": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.650.000.00',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN DERECHO DE FAMILIA": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN DERECHO COMERCIAL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN REVISORIA FISCAL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN INTERVENCIÓN Y GERENCIA SOCIAL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN CIENCIAS CRIMINOLÓGICAS Y PENALES": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP.  EN DERECHO PROBATORIO, PROCESAL Y ORALIDAD JUDICIAL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. DERECHO TRIBUTARIO": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. DERECHO FINANCIERO Y BURSÁTIL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.650.000.00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN GERENCIA FINANCIERA": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN GERENCIA DE INSTITUCIONES EDUCATIVAS": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.650.000.00',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN DERECHO URBANÍSTICO": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN CONTRATACIÓN ESTATAL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN RESPONSABILIDAD CIVIL Y DEL ESTADO": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$3.050.000,00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' },
"ESP. EN DERECHO ADMINISTRATIVO VIRTUAL": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/programas_posgrados.pdf', valorMatricula: '$2.500.000.00 ',nivel: 'posgrado',usuario_mercadeo:'Usu 3' }
,
"INGLÉS A1": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/ingles_A1.pdf', valorMatricula: '$1.290.000.00',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"INGLÉS A2": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/ingles_A2.pdf', valorMatricula: '$1.370.000.00',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"INGLÉS B1": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/ingles_B1.pdf', valorMatricula: '$1.880.000.00',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"INGLÉS B2": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/ingles_B2.pdf', valorMatricula: '$2.280.000.00',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"FRANCÉS A1": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/frances_A1.pdf', valorMatricula: '$1.290.000.00',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"FRANCÉS A2": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/frances_A2.pdf', valorMatricula: '$1.370.000.00',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"FRANCÉS B1": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/frances_B1.pdf', valorMatricula: '$1.880.000.00',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"FRANCÉS B2": { rutaPDF:'https://urepublicana.edu.co/images/documentos/documentos_planes_estudio/frances_B2.pdf', valorMatricula: '$2.280.000.00',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"Intercambio Internacional (Pregrado, Posgrado)": { rutaPDF:'NO APLICA', valorMatricula: 'NO APLICA',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"Intercambio Internacional (Maestría, Doctorado)": { rutaPDF:'NO APLICA', valorMatricula: 'NO APLICA',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"Intercambio Internacional Cultural (Au Pair, Camp Counselor, etc)": { rutaPDF:'NO APLICA', valorMatricula: 'NO APLICA',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"Intercambio Internacional (Inmersión Inglés)": { rutaPDF:'NO APLICA', valorMatricula: 'NO APLICA',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"Intercambio Internacional (Inmersión Inglés 40 Horas)": { rutaPDF:'NO APLICA', valorMatricula: 'NO APLICA',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"Oferta Laboral Internacional (Remoto)": { rutaPDF:'NO APLICA', valorMatricula: 'NO APLICA',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }
,
"Oferta Internacional (Presencial)": { rutaPDF:'NO APLICA', valorMatricula: 'NO APLICA',nivel: 'idiomas',usuario_mercadeo:'Usu 2' }


};

document.getElementById('form_new_general').addEventListener('submit', function(event) {
    event.preventDefault();  // Detiene el envío predeterminado para realizar la validación manual

var form = this;
    var valid = form.checkValidity();  // Verifica la validez de todos los campos

var checkbox = document.getElementById('terminos');
    if (checkbox.checked) {
       // alert("El valor del checkbox es: " + checkbox.value);
    } else {
       // alert("Por favor acepte los términos para poder continuar");
        return;
    }
  

if ($("#form_new_general").valid()) {

var programaSeleccionado = $('#pro').val();
// Asignar los valores correspondientes a los campos de texto
    $('#rutapdf').val(programas[programaSeleccionado].rutaPDF);
    $('#valormat').val(programas[programaSeleccionado].valorMatricula);

//alert("Ruta PDF: " + $('#rutapdf').val() + "\nValor Matrícula: " + $('#valormat').val());

// Crear el campo de entrada "nivel"
        var nivelField = '<input id="nivel" type="hidden" name="nivel" >';
        
        // Crear el campo de entrada "usu_mercadeo"
        var usuMercadeoField = '<input id="usu_mercadeo" type="hidden" name="usu_mercadeo" >';
        
        // Agregar los campos de entrada al formulario
        $("#form_new_general").append(nivelField);
        $("#form_new_general").append(usuMercadeoField);
// Asignar los valores correspondientes a los campos de texto
    $('#nivel').val(programas[programaSeleccionado].nivel);
    $('#usu_mercadeo').val(programas[programaSeleccionado].usuario_mercadeo);





        // Si el formulario es válido, realiza la petición AJAX
        $('button[name="submit"]').prop('disabled', true);
        $('#btn_form_info').prop('disabled', true);
        $.ajax({
            url: form.action,
            type: form.method,
            data: $(form).serialize(),
            success: function(response) {
                // Redirección a la página de confirmación
             alert("¡Tus datos han sido registrados!");

  window.location.href = "https://urepublicana.edu.co/pages/publicaciones/privado/noticia/gracias_por_compartir_tus_datos_con_nosotros";
            },
            error: function() {
                alert("Hubo un error al procesar el formulario. Por favor, inténtalo de nuevo.");
            }
        });
    }
});

</script>




</html>

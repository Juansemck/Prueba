﻿<!doctype html>
<html manifest="urepublicana.appcache">
<head>
	

<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '135599650420182');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=135599650420182&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->

 <!-- Global site tag (gtag.js) - Google Analytics -->



   <script async src="https://www.googletagmanager.com/gtag/js?id=UA-107902131-1"></script>




 <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-107902131-1');
  </script>

    <meta charset="UTF-8">
  <title>Corporación Universitaria Republicana - biblioteca.php</title>
 
<meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />
 <meta name="description" content=" Formar más colombianos sociales, ética y científicamente"  lang="es-ES">


<meta name="keywords"  content="pregrado, postgrado, derecho, ingenierías, trabajo social, contaduría pública, finanzas y comercio internacional, Matemáticas, Posgrados bogota, Pregrados bogotá"  lang="es-ES">


  <meta name="viewport" content="initial-scale=1, maximum-scale=1">
  <link rel="shortcut icon" href="//urepublicana.edu.co/images/web/logo.png">


  <link href="//urepublicana.edu.co/assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="//urepublicana.edu.co/assets/css/bootstrap-colorpicker.min.css" rel="stylesheet">
  
  <!-- Styles of this template -->


  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet"> 
  <link rel="stylesheet" href="//urepublicana.edu.co/assets/css/slider.min.css" type="text/css">
  <!-- LayerSlider styles -->

  <link rel="stylesheet" href="//urepublicana.edu.co/assets/slider/css/layerslider.css" type="text/css">
  <!-- External libraries: jQuery & GreenSock -->
  <script src="//urepublicana.edu.co/assets/slider/js/jquery.min.js" type="text/javascript"></script>
  <script src="//urepublicana.edu.co/assets/slider/js/greensock.min.js"></script>
  <!-- LayerSlider script files -->
  <script src="//urepublicana.edu.co/assets/slider/js/layerslider.transitions.min.js" type="text/javascript"></script>
  <script src="//urepublicana.edu.co/assets/slider/js/layerslider.kreaturamedia.jquery.min.js" type="text/javascript"></script>
  <!-- LayerSlider Popup plugin files -->
  <link rel="stylesheet" href="//urepublicana.edu.co/assets/slider/plugins/origami/layerslider.origami.css" type="text/css">
  <script src="//urepublicana.edu.co/assets/slider/plugins/origami/layerslider.origami.js" type="text/javascript"></script>


  <!-- MATERIALIZE -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="//urepublicana.edu.co/assets/css/materialize.min.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <!-- STYLE -->
  <link href="//urepublicana.edu.co/assets/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  
<style>

body{
	background: #ffffff;
}

h3{
	color: black;
}

h4{
	color: black;
}

.resumen_noticia{
	color: black;
}

.noticia > p{
	color: black;
}

.legal{
	color: black;
	background: #ffffff;
}

.contenido_noticia{
	color: black;
}

.titulo_menu{
	color: #000000 !important; 	
}

.card{
	background: #ffffff;
}

.card-reveal{
	background: #ffffff !important;
}

.tipo_urep{
	color: #a2121c;
	font-family: ;
}

.breadcrumb::before {
    content: '' !important;
}

	/*====================== HEADER */

.tipo_urep{
	font-family: Pinyon Script, cursive;
}

.menu_admin {
	background: linear-gradient(#ffffff87, #fffffff7) !important;	
}

.menu_admin a{
	color: #000000 !important; 	
}

#main_menu{
	background: linear-gradient(#ffffff87, #fffffff7);
}

#menu_mobile{
background: linear-gradient(#ffffff87, #fffffff7);
}

.side-nav li > a {
	color: #000000; 
}

.nav_main a{
	color: #000000; 
}

.nav_aux > li >a{
	color: #000000;
}

.nav_main a:hover{
	color: #a2121c;
}

.menu_all a:hover {
	color: #a2121c;
}

.nav_urep li {
	float: right;
}

.logo_urep{
	float: right !important;
}

.menu_nav{
  padding: 10px 5px !important;
}


/*====================== DESCRIPCION */

.legal_urep{
	color: ;
}



/*====================== ENLACES - BOTONES */

/*====================== NOTICIAS */

.noticia > a{
	color: #a2121c;
	border: 1px solid #a2121c;
}

.noticia > a:hover{
	background-color:#a2121c;
}

.urep_divide {
	border-bottom: solid 15px #a2121c;
}

#btn_menu i{
color: #000000;
}

.noticia > h5 > a{
	color: #a2121c;
}

.more_info{
	color: #a2121c;
}

#solicita_info{
border: 1px solid #a2121c;
}

#btn_informacion{
background-color: #a2121c;
}

#btn_informacion a{
background-color: #a2121c;
}

#btn_informacion a > i{
background-color: #a2121c;
}

.boton_urep{
	background-color: #a2121c;
}

.boton_urep:hover{
	background-color: white;
	color: #a2121c;
	border: 1px solid #a2121c;
}

.noticias_all > div > div > h5 > a{
	color: #a2121c;
}

.leer_mas{
	border: 1px solid #a2121c;
}

.enlace_inter{
	background: #a2121c;
}

.tab > a {
	color: #a2121c !important;
}

.content_inter li b{
	color: #a2121c;
}

.card-action a{
	color: #a2121c !important;
}

.enlace{
	color: #a2121c !important;   
}

.owl-theme .owl-dots .owl-dot.active span, .owl-theme .owl-dots .owl-dot:hover span {
	background: #a2121c;
}

.owl-theme .owl-nav [class*='owl-'] {
	background: #a2121c;
}

.owl-theme .owl-nav [class*='owl-']:hover {
	background:  #a2121c;
}

.footer-copyright{
	background-color: #A2121C;
}

.footer-copyright a{
	color: white;
}

.enlaces_urep{
	color: white;
}

.contacto{
	color: white;
	background-color: #262626;
}


</style>

  <!-- CARRUSEL -->
  <link rel="stylesheet" href="//urepublicana.edu.co/assets/owlcarousel/owl.carousel.css">
  <script src="//urepublicana.edu.co/assets/owlcarousel/owl.carousel.min.js"></script>

  <!-- ANIMATE -->
  <!-- <link rel="stylesheet" href="//urepublicana.edu.co/assets/css/animate.min.css"> -->

  <!-- TEXT -->
  <script src="//urepublicana.edu.co/assets/nic_edit/nicEdit.min.js" type="text/javascript"></script>
  <script type="text/javascript">
  	bkLib.onDomLoaded(function() {
  		new nicEditor({
  			buttonList : ['fontSize','fontFormat','indent','outdent','bold','italic','underline','underline','left','center','right','justify','html','ol','ul','link','unlink','xhtml']
  		}).panelInstance('noticia');
  	});
  </script>
</head>
<body id="body_urep">
	<div class="row" id="main_menu" style="width: 100%;">
      <!-- LOGO - DESCRIPCION -->
    <div class="col s4 m2 l2 right-align menu_nav">
      <a href="//urepublicana.edu.co/pages/"> <img src="//urepublicana.edu.co/images/web/logo.png" class="logo_urep"> </a>
    </div>
    <div class="col s6 m9 l4 left-align menu_nav">
      <div style="display:inline-block;">
        <h1 class="tipo_urep" style="width: 100%; " >Corporación Universitaria Republicana</h1>
        <center><p class="legal_urep"><b>Resolución No. 3061 del 02 de Diciembre de 1999 Min. Educación.<br>
Formamos más Colombianos ética, social y cientificamente
</b>
<br>Iesus Christus hanc dat fructum. Gloria in sancta Trinitate.<br> Et providere nos, misericordem gloriam Dei vivi</p></center>
      </div>
    </div>
    <!-- FIN - LOGO DESCRIPCION -->
      <!-- MENU -->
  <div class="col s2 m1 l6">
    <div class="nav-wrapper">
      <a href="#" id="btn_menu" data-activates="menu_mobile" class="button-collapse"><i class="material-icons">menu</i></a>
      <!-- MOBILE MENU -->
      <ul id="menu_mobile" class="side-nav center-align">
        <a href="//urepublicana.edu.co/pages/"><img src="//urepublicana.edu.co/images/web/logo.png" width="30%"></a>
                    <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Nuestra Institución</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="//urepublicana.edu.co/pages/nosotros/" target="_self">Nosotros</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Estructura_Organizacional.pdf" target="_blank">Organigrama</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/PEI_.pdf" target="_blank">PEI</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/plan_de_desarrollo_2020_2026.pdf" target="_blank">Plan de Desarrollo Institucional</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Estatutos.pdf" target="">Estatutos Generales</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Estudiantil-Ag-30-de-2018.pdf" target="_blank">Reglamento Estudiantil</a></li>
                                                <li><a href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Docente.pdf" target="_blank">Reglamento Docente</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/autoevaluacion_y_acreditacion.pdf" target="_blank">Auto Evaluación y Acreditación</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/eae/" target="_blank">Escuela de Altos Estudios</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/Politicas_financieras.pdf" target="_blank">Políticas Financieras</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/1654804160.pdf" target="_blank">Protocolo de Bioseguridad</a></li>
                                                <li><a href=" https://urepublicana.edu.co/images/documentos/derechos_pecuniaros_2024.pdf" target="_blank">Valores y Servicios Académicos 2024 (Acuerdo 226 Derechos Pecuniarios 2024)</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/matricula_financiera_valores_de_matricula_2024.pdf" target="_blank">Resolución Rectoral 2 2024 (Matrícula Financiera)</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/resolucion_030025_dic_2023.pdf" target="_blank">Resolución Educación Para el Trabajo y Desarrollo humano</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Estudiantes</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="//urepublicana.edu.co/images/documentos/estudiantes/requisitos_trabajo_profundizacion_2020_actualizado.pdf" target="_blank">Lineamientos Trabajo de Profundización</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/codigos_para_consignacion" target="_blank">Números de Cuenta y Códigos de Consignación</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/biblioteca.php" target="_blank">Biblioteca</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/centro_idiomas/" target="_self">Centro de Idiomas</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/publicaciones_urepublicana/" target="_blank">Publicaciones</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/calendario_académico_2024.pdf" target="_blank">Calendario académico 2024</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/eae/" target="_self">Escuela de Altos Estudios</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/1726771276.pdf" target="_blank">Resolución Rectoral 5</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect">Programas</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li class="no-padding">
                          <ul class="collapsible collapsible-accordion">
                            <li>
                              <a class="collapsible-header waves-effect">Pregrado</a>
                              <div class="collapsible-body nivel_3">
                                <ul>
                                                                        <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/derecho"> Derecho</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/matematicas"> Matemáticas</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/trabajo_social"> Trabajo Social</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/contaduria_publica"> Contaduría Pública</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/ingenieria_industrial"> Ingeniería Industrial</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/ingenieria_de_sistemas"> Ingeniería de Sistemas</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/finanzas_y_comercio_internacional"> Finanzas y Comercio Internacional</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/administracion_de_mercadeo_virtual"> Administración de Mercadeo Virtual</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Profesional/finanzas_y_comercio_internacional_virtual"> Finanzas y Comercio Internacional Virtual</a>
                                      </li>
                                                                      </ul>
                              </div>
                            </li>
                          </ul>
                        </li>
                                                <li class="no-padding">
                          <ul class="collapsible collapsible-accordion">
                            <li>
                              <a class="collapsible-header waves-effect">Posgrado</a>
                              <div class="collapsible-body nivel_3">
                                <ul>
                                                                        <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_publico"> Especialización en Derecho Público</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_comercial"> Especialización en Derecho Comercial</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_revisoria_fiscal"> Especialización en Revisoría Fiscal</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_de_familia"> Especialización en Derecho de Familia</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_tributario"> Especialización en Derecho Tributario</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializcion_en_gerencia_financiera"> Especialización en Gerencia Financiera</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_urbanistico"> Especialización en Derecho Urbanístico</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_contratacion_estatal"> Especialización en Contratación Estatal</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_notarial_y_de_registro"> Especialización en Derecho Notarial y de Registro</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_financiero_y_bursatil"> Especialización en Derecho Financiero y Bursátil</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_administrativo"> Especialización en Derecho Administrativo Virtual</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_procesal_constitucional"> Especialización en Derecho Procesal Constitucional</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_intervencion_y_gerencia_social"> Especialización en Intervención y Gerencia Social</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_laboral_y_seguridad_social"> Especialización en Derecho Laboral y Seguridad Social</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_ciencias_criminologicas_y_penales"> Especialización en Ciencias Criminológicas y Penales</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_responsabilidad_civil_y_del_estado"> Especialización en Responsabilidad Civil y del Estado</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_gerencia_de_instituciones_educativas"> Especialización en Gerencia de Instituciones Educativas</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_probatorio_procesal_y_oralidad_judicial"> Especialización en Derecho Probatorio, Procesal y Oralidad Judicial</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_la_responsabilidad_penal_del_servidor_publico_y_los_delitos_contra_la_administracion_publica"> Especialización en la Responsabilidad Penal del Servidor Público y los Delitos Contra la Administración Pública</a>
                                      </li>
                                                                      </ul>
                              </div>
                            </li>
                          </ul>
                        </li>
                                                <li class="no-padding">
                          <ul class="collapsible collapsible-accordion">
                            <li>
                              <a class="collapsible-header waves-effect">Educación Continua</a>
                              <div class="collapsible-body nivel_3">
                                <ul>
                                                                        <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_en_desarrollo_de_software_seguro"> Diplomado en Desarrollo de Software Seguro</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_en_docencia_universitaria_con_enfasis_en_tic"> Diplomado en Docencia Universitaria con Énfasis en TIC</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/Diplomado_de_insolvencia_de_persona_natural_no_comerciante"> Diplomado de Insolvencia de Persona Natural No Comerciante</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/Diplomado_en_gestion_educativa_en_el_contexto_de_la_participacion"> Diplomado en Gestión Educativa en el Contexto de la Participación</a>
                                      </li>
                                                                            <li>
                                        <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_de_formacion_y_capacitacion_de_conciliadores_en_derecho"> Diplomado de Formación y Capacitación de Conciliadores en Derecho</a>
                                      </li>
                                                                      </ul>
                              </div>
                            </li>
                          </ul>
                        </li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="//urepublicana.edu.co/pages/bienestar/">Bienestar</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Docentes</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Docente.pdf" target="_blank">Reglamento Docente</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/eae/" target="_blank">Escuela de Altos Estudios</a></li>
                                                <li><a href="https://virtualrepublicana.com/" target="_blank">Campus Virtual</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Servicios</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="http://outlook.com/urepublicana.edu.co" target="_blank">Correo Electrónico</a></li>
                                                <li><a href="http://academiaurepublicana.org/ArKa/test/new_login.php" target="_blank">Consulta de Notas</a></li>
                                                <li><a href="https://academiaurepublicana.org/cur5/reporte1.php" target="_blank">Registro de Notas (Docente)</a></li>
                                                <li><a href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/pagos_en_linea" target="_blank">Pagos en Línea</a></li>
                                                <li><a href="https://www.pagosvirtualesavvillas.com.co/personal/pagos/1620" target="_self">Pago en línea AV VILLAS</a></li>
                                                <li><a href=" https://urepublicana.edu.co/images/documentos/1683941661.pdf" target="_blank">Instructivo pagos en línea AV-VILLAS</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="https://republicanaradio.com/">Radio</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="//urepublicana.edu.co/pages/investigacion/">Investigación</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="//urepublicana.edu.co/pages/internacionalizacion/">Internacionalización</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="//urepublicana.edu.co/pages/egresados/">Egresados</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="#">Autoevaluación</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                              <li><a href="https://urepublicana.edu.co/images/documentos/autoevaluacion_y_acreditacion.pdf" target="_blank">Acreditación y Autoevaluación</a></li>
                                                <li><a href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/autoevaluacion.pdf" target="_blank"> Modelo de Aseguramiento de la Calidad</a></li>
                                            </ul>
                  </div>
                </li>
              </ul>
            </li>
                        <li class="no-padding">
              <ul class="collapsible collapsible-accordion">
                <li>
                  <a class="collapsible-header waves-effect" href="https://urepublicana.edu.co/pages/ccaac/">Centro Conciliación</a>
                  <div class="collapsible-body nivel_2">
                    <ul>
                                          </ul>
                  </div>
                </li>
              </ul>
            </li>
                    <li><a href="#"><br></a></li>
        <li><a href="#"><br></a></li> 
      </ul>
      <!-- FIN MENU MOBILE -->
      <div class="row">
        <ul class="right nav_urep">
                        <li class="nav_main"><a class="enlace_menu" target="" href="#!" name="#70">Docentes</a></li>
                            <li class="nav_main"><a class="enlace_menu" target="" href="//urepublicana.edu.co/pages/bienestar/" name="URL_MASTER/pages/bienestar/">Bienestar</a></li>
                            <li class="nav_main"><a class="enlace_menu" target="" href="#programas" name="#programas">Programas</a></li>
                            <li class="nav_main"><a class="enlace_menu" target="" href="#!" name="#20">Estudiantes</a></li>
                            <li class="nav_main"><a class="enlace_menu" target="" href="#!" name="#10">Nuestra Institución</a></li>
                      </ul>
        <ul class="right nav_urep nav_aux">
                        <li><a class="enlace_menu" target="_self" href="https://urepublicana.edu.co/pages/ccaac/" name="https://urepublicana.edu.co/pages/ccaac/">Centro Conciliación</a></li>
                            <li><a class="enlace_menu" target="" href="#60" name="#60">Autoevaluación</a></li>
                            <li><a class="enlace_menu" target="" href="//urepublicana.edu.co/pages/egresados/" name="//urepublicana.edu.co/pages/egresados/">Egresados</a></li>
                            <li><a class="enlace_menu" target="" href="//urepublicana.edu.co/pages/internacionalizacion/" name="//urepublicana.edu.co/pages/internacionalizacion/">Internacionalización</a></li>
                            <li><a class="enlace_menu" target="" href="//urepublicana.edu.co/pages/investigacion/" name="//urepublicana.edu.co/pages/investigacion/">Investigación</a></li>
                            <li><a class="enlace_menu" target="_blank" href="https://republicanaradio.com/" name="https://republicanaradio.com/">Radio</a></li>
                            <li><a class="enlace_menu" target="" href="#50" name="#50">Servicios</a></li>
                      </ul>
      </div>
    </div>
  </div>
  <!-- FIN MENU -->

  
        <div id="70" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Docentes</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Docente.pdf">Reglamento Docente</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/eae/">Escuela de Altos Estudios</a></li>
                                                <li><a target="_blank" href="https://virtualrepublicana.com/">Campus Virtual</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Docentes.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
            <div id="60" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Autoevaluación</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/autoevaluacion_y_acreditacion.pdf">Acreditación y Autoevaluación</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/autoevaluacion.pdf"> Modelo de Aseguramiento de la Calidad</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Autoevaluación.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
            <div id="20" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Estudiantes</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/estudiantes/requisitos_trabajo_profundizacion_2020_actualizado.pdf">Lineamientos Trabajo de Profundización</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/codigos_para_consignacion">Números de Cuenta y Códigos de Consignación</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/biblioteca.php">Biblioteca</a></li>
                                                <li><a target="_self" href="https://urepublicana.edu.co/pages/centro_idiomas/">Centro de Idiomas</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/publicaciones_urepublicana/">Publicaciones</a></li>
                                                  </ul></div><div class="col m4"><ul>                        <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/calendario_académico_2024.pdf">Calendario académico 2024</a></li>
                                                <li><a target="_self" href="https://urepublicana.edu.co/pages/eae/">Escuela de Altos Estudios</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/1726771276.pdf">Resolución Rectoral 5</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Estudiantes.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
            <div id="10" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Nuestra Institución</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_self" href="//urepublicana.edu.co/pages/nosotros/">Nosotros</a></li>
                                                <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Estructura_Organizacional.pdf">Organigrama</a></li>
                                                <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/PEI_.pdf">PEI</a></li>
                                                <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/plan_de_desarrollo_2020_2026.pdf">Plan de Desarrollo Institucional</a></li>
                                                <li><a target="" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Estatutos.pdf">Estatutos Generales</a></li>
                                                  </ul></div><div class="col m4"><ul>                        <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Estudiantil-Ag-30-de-2018.pdf">Reglamento Estudiantil</a></li>
                                                <li><a target="_blank" href="//urepublicana.edu.co/images/documentos/nuestra_institucion/Reglamento-Docente.pdf">Reglamento Docente</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/autoevaluacion_y_acreditacion.pdf">Auto Evaluación y Acreditación</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/eae/">Escuela de Altos Estudios</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/nuestra_institucion/Politicas_financieras.pdf">Políticas Financieras</a></li>
                                                  </ul></div><div class="col m4"><ul>                        <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/1654804160.pdf">Protocolo de Bioseguridad</a></li>
                                                <li><a target="_blank" href=" https://urepublicana.edu.co/images/documentos/derechos_pecuniaros_2024.pdf">Valores y Servicios Académicos 2024 (Acuerdo 226 Derechos Pecuniarios 2024)</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/matricula_financiera_valores_de_matricula_2024.pdf">Resolución Rectoral 2 2024 (Matrícula Financiera)</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/resolucion_030025_dic_2023.pdf">Resolución Educación Para el Trabajo y Desarrollo humano</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Nuestra Institución.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
            <div id="50" class="menu_det ocultar">
        <div class="menu_all">
          <div class="container">
            <div class="row">
              <h2 class="center-align" style="color white !important;">Servicios</h2>
              <div class="col m11">
                <div class="row">
                  <div class="col m4">
                    <ul>
                                              <li><a target="_blank" href="http://outlook.com/urepublicana.edu.co">Correo Electrónico</a></li>
                                                <li><a target="_blank" href="http://academiaurepublicana.org/ArKa/test/new_login.php">Consulta de Notas</a></li>
                                                <li><a target="_blank" href="https://academiaurepublicana.org/cur5/reporte1.php">Registro de Notas (Docente)</a></li>
                                                <li><a target="_blank" href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/pagos_en_linea">Pagos en Línea</a></li>
                                                <li><a target="_self" href="https://www.pagosvirtualesavvillas.com.co/personal/pagos/1620">Pago en línea AV VILLAS</a></li>
                                                  </ul></div><div class="col m4"><ul>                        <li><a target="_blank" href=" https://urepublicana.edu.co/images/documentos/1683941661.pdf">Instructivo pagos en línea AV-VILLAS</a></li>
                                            </ul>
                  </div>
                </div>
              </div>
              <div class="col m1">
                <img src="//urepublicana.edu.co/images/web/menu/Servicios.png" width="100%">
              </div>
            </div>
          </div>
        </div>
      </div>
      

  <!-- Programas -->
  <div id="programas" class="menu_det ocultar">
    <div class="menu_all">
      <div class="container"  >
        <div class="row">
          <h4 class="center-align" style="color:white !important;">Programas</h4>
          <div class="col m3">
            <ul>
                              <li><a class="enlace_menu_2" name="#prom_Profesional" href="#">Pregrado</a></li>
                              <li><a class="enlace_menu_2" name="#prom_Posgrado" href="#">Posgrado</a></li>
                              <li><a class="enlace_menu_2" name="#prom_Diplomado" href="#">Educación Continua</a></li>
                            <!-- <li><a class="enlace_menu_2" name="#prom_edcontinua" href="#">Educación Continuada</a></li> -->
            </ul>
          </div>
          <div class="col m9" >
                       <ul id="prom_Profesional" class="programas ocultar">
                                <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/derecho"> Derecho</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/matematicas"> Matemáticas</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/trabajo_social"> Trabajo Social</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/contaduria_publica"> Contaduría Pública</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/ingenieria_industrial"> Ingeniería Industrial</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/ingenieria_de_sistemas"> Ingeniería de Sistemas</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/finanzas_y_comercio_internacional"> Finanzas y Comercio Internacional</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/administracion_de_mercadeo_virtual"> Administración de Mercadeo Virtual</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Profesional/finanzas_y_comercio_internacional_virtual"> Finanzas y Comercio Internacional Virtual</a>
                  </li>
                   </div>
                              </ul>
                      <ul id="prom_Posgrado" class="programas ocultar">
                                <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_publico"> Especialización en Derecho Público</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_comercial"> Especialización en Derecho Comercial</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_revisoria_fiscal"> Especialización en Revisoría Fiscal</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_de_familia"> Especialización en Derecho de Familia</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_tributario"> Especialización en Derecho Tributario</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializcion_en_gerencia_financiera"> Especialización en Gerencia Financiera</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_urbanistico"> Especialización en Derecho Urbanístico</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_contratacion_estatal"> Especialización en Contratación Estatal</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_notarial_y_de_registro"> Especialización en Derecho Notarial y de Registro</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_financiero_y_bursatil"> Especialización en Derecho Financiero y Bursátil</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_administrativo"> Especialización en Derecho Administrativo Virtual</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_procesal_constitucional"> Especialización en Derecho Procesal Constitucional</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_intervencion_y_gerencia_social"> Especialización en Intervención y Gerencia Social</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_derecho_laboral_y_seguridad_social"> Especialización en Derecho Laboral y Seguridad Social</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_ciencias_criminologicas_y_penales"> Especialización en Ciencias Criminológicas y Penales</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_responsabilidad_civil_y_del_estado"> Especialización en Responsabilidad Civil y del Estado</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_gerencia_de_instituciones_educativas"> Especialización en Gerencia de Instituciones Educativas</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/Especializacion_en_derecho_probatorio_procesal_y_oralidad_judicial"> Especialización en Derecho Probatorio, Procesal y Oralidad Judicial</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Posgrado/especializacion_en_la_responsabilidad_penal_del_servidor_publico_y_los_delitos_contra_la_administracion_publica"> Especialización en la Responsabilidad Penal del Servidor Público y los Delitos Contra la Administración Pública</a>
                  </li>
                   </div>
                              </ul>
                      <ul id="prom_Diplomado" class="programas ocultar">
                                <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_en_desarrollo_de_software_seguro"> Diplomado en Desarrollo de Software Seguro</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_en_docencia_universitaria_con_enfasis_en_tic"> Diplomado en Docencia Universitaria con Énfasis en TIC</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/Diplomado_de_insolvencia_de_persona_natural_no_comerciante"> Diplomado de Insolvencia de Persona Natural No Comerciante</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/Diplomado_en_gestion_educativa_en_el_contexto_de_la_participacion"> Diplomado en Gestión Educativa en el Contexto de la Participación</a>
                  </li>
                   </div>
                                    <div class="col m6">
                  <li style="font-size:12px !important;">
                    <a href="//urepublicana.edu.co/pages/programas/Diplomado/diplomado_de_formacion_y_capacitacion_de_conciliadores_en_derecho"> Diplomado de Formación y Capacitación de Conciliadores en Derecho</a>
                  </li>
                   </div>
                              </ul>
                    <!-- 
          <ul id="prom_edcontinua" class="programas ocultar" >
            <li><a target="_blank" href="http://urepublicana.edu.co/contratacion-estatal/">Contratación Estatal</a></li>
            <li><a target="_blank" href="http://urepublicana.edu.co/educacion-continuada/derecho-disciplinario-colombiano/">Derecho Disciplinario Colombiano</a></li>
            <li><a target="_blank" href="http://urepublicana.edu.co/educacion-continuada/regimen-disciplinario-de-las-fuerzas-militares/">Regimen Disciplinario de las Fuerzas Militares</a></li>
            <li><a target="_blank" href="http://urepublicana.edu.co/educacion-continuada/diplomado-en-formacion-y-capacitacion-de-conciliadores/">Diplomado en Formación y Capacitación de Conciliadores</a></li>
          </ul>
        -->
      </div>
     <!-- <div class="col m2">
        <img src="//urepublicana.edu.co/images/web/menu/Programas.png" width="100%">
      </div>  -->
    </div>
  </div>


</div>
</div>
</div>
	<div class="breadcrumb"><a href="//urepublicana.edu.co/pages/index.php"> Inicio </a> > <a href="//urepublicana.edu.co/pages/biblioteca.php"> Biblioteca </a></div>

	<div class="container">
		<div class="row center">
			<div class="col s12">
				<h2>Biblioteca</h2>
				<img src="//urepublicana.edu.co/images/web/biblioteca/biblioteca_urepublicana.jpg" width="100%">
			</div>
		</div>
		<div class="row lnk_first">
			<div class="col s4 m2">
				<span class="enlace_urep" name="#biblio_general">
					<img class="atajo" name="//urepublicana.edu.co/images/web/biblioteca/bibilo_general_1.png" src="//urepublicana.edu.co/images/web/biblioteca/bibilo_general.png">
					<p>Información General</p>
				</span>
			</div>
			<div class="col s4 m2">
				<a target="_blank" href="http://republicana.redbiblio.net/">
					<span>
						<img class="atajo" name="//urepublicana.edu.co/images/web/biblioteca/biblio_catalogo_1.png" src="//urepublicana.edu.co/images/web/biblioteca/biblio_catalogo.png">
						<p>Catálogo en Línea</p>
					</span>
				</a>
			</div>
			<div class="col s4 m2">
				<span class="enlace_urep" name="#biblio_servicios">
					<img class="atajo" name="//urepublicana.edu.co/images/web/biblioteca/biblio_servicios_1.png" src="//urepublicana.edu.co/images/web/biblioteca/biblio_servicios.png">
					<p>Servicios</p>
				</span>
			</div>
			<div class="col s4 m2">
				<span class="enlace_urep" name="#biblio_recursos">
					<img class="atajo" name="//urepublicana.edu.co/images/web/biblioteca/biblio_recursos_1.png" src="//urepublicana.edu.co/images/web/biblioteca/biblio_recursos.png">
					<p>Recursos Electrónicos</p>
				</span>
			</div>
	 <div class="col s4 m2">
                                <span class="enlace_urep" name="#">
                                       <a href="https://urepublicana.edu.co/images/documentos/1616544775.pdf" target="_blank"> <img class="atajo" name="//urepublicana.edu.co/images/web/biblioteca/biblio_recursos_1.png" src="//urepublicana.edu.co/images/web/biblioteca/biblio_recursos.png"> </a>
                                        <p>Apoyo a la Investigación</p>
                                </span>
                        </div>



<div class="col s4 m2">
                                <span class="enlace_urep" name="#">
                                       <a href="https://urepublicana.edu.co/images/documentos/1729869829.pdf" target="_blank"> <img class="atajo" name="//urepublicana.edu.co/images/web/biblioteca/biblio_recursos_1.png" src="//urepublicana.edu.co/images/web/biblioteca/biblio_recursos.png"> </a>
                                        <p>Nuevas Adquisiciones</p>
                                </span>
                        </div>







<!--			<div class="col s4 m2"> -->
<!--				<span class="enlace_urep" name="#biblio_nuevas"> -->
<!--					<img class="atajo" name="//urepublicana.edu.co/images/web/biblioteca/biblio_adquiciciones_1.png" src="//urepublicana.edu.co/images/web/biblioteca/biblio_adquiciciones.png"> -->
<!--					<p>Nuevas Adquisiciones</p> -->
<!--				</span> -->
<!--			</div> -->

		</div>


		<div class="row">
			<!-- GENERAL -->
			<div id="biblio_general" class="col s12 content_urep ocultar">
				<p>	
					<h5>Misión</h5>
					La Biblioteca de la Corporación Universitaria Republicana tiene como misión ofrecer a la comunidad Republicana recursos bibliográficos pertinentes  y servicios de alta calidad para apoyar  los programas de docencia, investigación y extensión que desarrolla la Institución.
					<h5>Visión</h5>
					Constituirnos en un referente en el entorno como biblioteca universitaria, en cuanto a sus buenas prácticas y gestión de la calidad de los servicios y productos ofrecidos.
					<h5>Objetivos</h5>
					<ul>
						<li><b> * </b> Brindar a los miembros de la comunidad universitaria el acceso y difusión de la información apropiada y actualizada acorde a los programas académicos de la Corporación.</li>
						<li><b> * </b> Suministrar servicios de información que respondan a las necesidades de la comunidad universitaria.</li>
						<li><b> * </b> Cooperar en el desarrollo de planes de extensión universitaria. Establecer los nexos correspondientes para la vinculación a redes bibliotecarias locales, nacionales e internacionales.</li>
					</ul>
					<h5>Ubicación</h5>
					Calle 20 No. 5 - 67 Primer piso.
					<h5>Horario</h5>
					<ul>
						<li>Lunes a viernes de 7:00 a.m.  a  10:00 p.m.</li>
						<li>Sábados de 9:00 a.m.  a  1:00 p.m.</li>
					</ul>
				</p>
			</div>
			<!-- SERVICIOS -->
			<div id="biblio_servicios" class="col s12 content_urep ocultar">
				<p>
					Para acceder a cualquiera de los servicios de la Biblioteca, todos los usuarios deben presentar el carné actualizado, el cual es personal e intransferible.
					<br>Toda la comunidad republicana tiene acceso a los siguientes servicios:
				</p>
				<div class="row">
					<div class="col s12 m3">
						<ul>
                                                        <li name="#serv_busqueda" class="enlace_inter"> Búsqueda de Material</li>
							<li name="#serv_prestamo" class="enlace_inter"> Préstamo de Material</li>
							<li name="#serv_renovacion" class="enlace_inter"> Renovación y reserva de material</li>
							<li name="#serv_otros" class="enlace_inter"> Otros Servicios </li>
                                                         <li name="#reglamento" class="enlace_inter"> Reglamento </li>

						</ul>
					</div>
					<div class="col s12 m9">
                                              <!-- REGLAMENTO -->       
                                               <div id="reglamento" class="content_inter ocultar">
                                                        <p>
                                                                <h4>Prestamo de Material</h4>
                                                                <a target="_blank" href="https://urepublicana.edu.co/images/documentos/1616635143.pdf"> Ver reglamento aquí.</a>
                                                         </p>
</div>
					
				<!-- BÚSQUEDA -->


<div id="serv_busqueda" class="content_inter ocultar">
                                                        <p>
                                                                <h4>Búsqueda de Material</h4>
<p>En el catálogo en línea Koha puedes consultar el material bibliográfico en formato físico presente en la Biblioteca, que se encuentra a disposición de toda la comunidad universitaria. Contamos con libros, revistas, trabajos de grado y analíticas de revistas, entre otros materiales, con temáticas para todos los programas que ofrece la Corporación. En los siguientes videos te enseñaremos cómo hacer uso acertado del catálogo para optimizar los resultados de tus búsquedas, y dar con material idóneo para tus clases y trabajos.  </p>



                                                                <h5>Búsqueda simple</h5>
                                                              <p>Te proporciona resultados rápidos haciendo uso de los filtros básicos, que te ayudarán a depurar la cantidad y calidad de ítems, brindándote opciones más acertadas. Puedes buscar por título, tema, editorial, entre otras. En el siguiente video te explicaremos como usar este tipo de búsqueda.  </p>
                                          
<iframe width="100%" height="315" src="https://www.youtube.com/embed/q6W7e8CaCoQ" frameborder="0" allowfullscreen></iframe>

                                                                <h5> Búsqueda avanzada </h5>
                                                                <p>Te permite buscar utilizando una mayor cantidad de filtros que pueden ser relacionados a su vez, logrando mayor especificidad en los resultados. También puedes elegir el tipo de material, colección, fecha de publicación o rangos de fecha, búsqueda por bibliografía, entre otras. En el siguiente video te explicaremos como usar este tipo de búsqueda. </p>

<iframe width="100%" height="315" src="https://www.youtube.com/embed/rnGhlkEqDFY" frameborder="0" allowfullscreen></iframe>

                                                                
                                                </div>









					<!-- PRESTAMOS -->
						<div id="serv_prestamo" class="content_inter ocultar">
							<p>
								<h4>Préstamo de Material</h4>
							<!--	<h5>Tutorial - Búsqueda de material en el Catálogo</h5>
								<iframe width="100%" height="315" src="https://www.youtube.com/embed/q6W7e8CaCoQ" frameborder="0" allowfullscreen></iframe> -->
								<h5>Préstamo externo o a domicilio</h5>
								Es el servicio mediante el cual los usuarios de Comunidad Republicana pueden llevar dos materiales (libros, revistas, videos, etc.) de la colección general, por dos días hábiles; este préstamo puede ser renovado por el mismo tiempo, siempre y cuando el material no haya sido reservado por otro usuario.
								<br>El material de la colección de reserva y de referencia, se presta para domicilio después de las 9:30 p.m., para su devolución al día siguiente antes de las 9:00 a.m.; si el préstamo se solicita el día sábado, éste se debe realizar después de las 12:30 p.m. y tendrá que ser devuelto el siguiente día hábil, antes de las 9:00 a.m. El préstamo de este material no puede ser renovado.
								<h5> Préstamo interno </h5> 
								Mediante este servicio los usuarios pueden consultar todas las colecciones de la Biblioteca durante el horario de servicio de la misma, dentro o fuera de las salas de lectura; se exceptúan las tesis de grado, las cuales solamente se pueden consultar dentro de las instalaciones de la Biblioteca.
								<h5> Préstamo interbibliotecario </h5> 
								A través de este servicio, los miembros de la comunidad republicana pueden tener acceso al préstamo externo del material bibliográfico de otras bibliotecas universitarias y de entidades públicas y privadas, con las cuales la Biblioteca de la Corporaciíon ha establecido convenio. Ingrese aquí para conocer la lista y los catálogos en línea  de las instituciones con las cuales se tiene convenio de préstamo interbibliotecario.
								<br>El servicio puede solicitarse en la biblioteca o diligenciando el formato que encontrará en el sistema académico en la sección de Biblioteca, <a target="_blank" href="https://academiaurepublicana.org/ArKa/test/new_login.php"> aquí.</a>
							</p>
						</div>
						<!-- RENOVACION -->
						<div id="serv_renovacion" class="content_inter ocultar">
							<p>
								<h4>Renovación y reserva de material</h4>
								Los usuarios pueden ampliar la fecha de devolución del material bibliográfico e igualmente pueden reservar el material que se encuentra prestado. La renovación del préstamo solamente se puede hacer el día de vencimiento del mismo.
								<br>La renovación y la reserva se pueden realizar presencialmente en la Biblioteca o el línea ingresando al catálogo con su usuario y contraseña.
								<h5>Tutorial - Renovación y Reserva de Material</h5>
								<iframe width="100%" height="315" src="https://www.youtube.com/embed/OzQq_3lRrCA" frameborder="0" allowfullscreen></iframe>
							<!-- 	<h5>Tutorial - Reserva de Material</h5>
								<iframe width="100%" height="315" src="https://www.youtube.com/embed/VqFN04oZtqo?rel=0" frameborder="0" allowfullscreen></iframe> -->
							</p>
						</div>
						<!-- OTROS -->
						<div id="serv_otros" class="content_inter ocultar">
							<p>	
								<h4>Otros Servicios</h4>
								<h5> Cartas de Presentación</h5>
								Las cartas de presentación permiten a la comunidad republicana el acceso a otras bibliotecas de la ciudad.
								<br>El servicio puede solicitarse en la biblioteca o diligenciando el formato que encontrará en el sistema académico en la sección de Biblioteca, <a target="_blank" href="https://academiaurepublicana.org/ArKa/test/new_login.php">aquí</a>
								<h5> Elaboración de Bibliografías</h5>
								Recopilación de las reseñas bibliográficas sobre un tema específico, a solicitud del usuario, a partir de las colecciones de la Biblioteca de la Corporación.
								<br>El servicio puede solicitarse en la biblioteca o diligenciando el formato que encontrará en el sistema académico en la sección de Biblioteca, <a target="_blank" href="https://academiaurepublicana.org/ArKa/test/new_login.php">aquí</a>
								<h5> Formación de Usuarios</h5>
								Inducciones y capacitaciones sobre el uso y el manejo de los servicios y recursos de la Biblioteca.
								<br>Las inducciones están dirigidas a los docentes y los estudiantes nuevos y consiste en una revisión general de los servicios presenciales y en línea que ofrece la Biblioteca.
<br>
Mediante las capacitaciones se ofrece a estudiantes y docentes la posibilidad de aprender a utilizar el Catálogo en línea y las bases de datos. Las capacitaciones se pueden solicitar personalmente en la Biblioteca o enviando un correo a <a href='mailto:biblioteca@urepublicana.edu.co' target='_blank'>:biblioteca@urepublicana.edu.co</a>								
<h5> Servicio de Referencia</h5>
								Es el servicio de asesoría que el personal de la Biblioteca presta de forma individualizada a un usuario, para la búsqueda y recuperación de información.
								<h5> Préstamo de equipos audiovisuales</h5>
								La Biblioteca cuenta con herramientas como video beam y computadores portátiles, disponibles para apoyar las actividades académicas de la comunidad republicana. La reserva de estos equipos debe hacerse directamente en la Biblioteca, con mínimo 3 días de anticipación a la actividad.
								<h5> Red Inalámbrica</h5>
								Contamos con red inalámbrica en todos los espacios de la Biblioteca para la conexión de equipos móviles.
							</p>
						</div>
					</div>
				</div>
			</div>
			<!-- RECURSOS -->
<br>
<div id="biblio_recursos" class="col s12 content_urep ocultar">
<p>
La Biblioteca cuenta con gran variedad de recursos electrónicos que puedes consultar en línea. Entre ellos se encuentran las bibliotecas digitales, con alrededor de 1000 libros de reconocidas editoriales académicas, con temáticas para todos los programas de la Corporación.

<br><br>

También puedes acceder a las bases por suscripción de Legis, plataforma que brinda información jurídica, tributaria y contable. Así mismo, encontrarás bases de datos de recursos libres que cuentan con libros, revistas, artículos, tesis de grado, material audiovisual, entre otros.
 </p>

<br>
<h6><b>¿CÓMO PUEDO ACCEDER A LOS RECURSOS ELECTRÓNICOS?  EN EL SIGUIENTE VIDEO TE LO EXPLICAMOS DE FORMA MUY SENCILLA. </b> </h6>
<br>
<iframe width="100%" height="315" src="https://www.youtube.com/embed/ywUKBiaC8vI" frameborder="0" allowfullscreen></iframe>
<br><br>
<ul class="collapsible">
  



 
<!-- Bases de datos por suscripción -->



<li class="">
      <div class="collapsible-header"><i class="material-icons">folder_shared</i>Bases de datos por suscripción</div>
      <div class="collapsible-body" style="display: none;"><!-- abro div colapsable -->


<div class="row">
<div class="col s12 m3"><a href="https://academiaurepublicana.org/ArKa/test/new_login.php" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1557346413.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>MULTILEGIS</b><br>
Solución para la investigación jurídica, tributaria y contable, financiera, laboral, seguridad social y salud, ambiental, comercial, administrativa y pública, que permite el desarrollo de habilidades para el ejercicio de la profesión. Incorpora publicaciones especializadas en todas las áreas. Incluye Normas de información financiera, normativo de paz, entre otras. Contiene ayudas prácticas y flujogramas de procesos,  noticias diarias, normas, jurisprudencia y doctrina experta. Encuentre el acceso al periódico Ámbito Jurídico y la Comunidad Contable.</p></div>
 </div>


<div class="row">
<div class="col s12 m3"><a href="https://academiaurepublicana.org/ArKa/test/new_login.php" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1631302946.png" width="90%"></a></div>
      <div class="col s12 m9"><p><b>LEGIS ÁMBITO JURÍDICO</b><br>
Es una solución que permite estar actualizado y conocer la información y las noticias jurídicas y contables más importantes del país, como también estudios y opiniones de interés general, análisis de normas y sentencias, temas contables y de auditoría, entre otros, en un portal que se transforma al ritmo de las exigencias del mundo actual.</p></div>
 </div>


<div class="row">
<div class="col s12 m3"><a href="https://academiaurepublicana.org/ArKa/test/new_login.php" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1557346559.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>LEGIS ANALÍTICA</b><br>
Herramienta necesaria para el aprendizaje del precedente jurisprudencial. permite la generación de las mejores estrategias en los procesos, conociendo como se han aplicado las reglas del derecho a diferentes casos en un periodo de tiempo. Incluye 24 líneas jurisprudenciales en los temas de laboral, seguridad social, contratación estatal y responsabilidad extracontractual civil y del estado.</p></div>
 </div>





<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://academiaurepublicana.org/ArKa/test/new_login.php" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553194671.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>VIRTUAL PRO</b><br>
Se publican trabajos de investigación, artículos, manuales, libros (todo full text), software, tutoriales, herramientas complementarias, noticias, eventos, becas, documentos de gerencia y empresa, y además ejemplos de vida y documentos de liderazgo y crecimiento personal.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://academiaurepublicana.org/ArKa/test/new_login.php" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1631303444.png" width="90%"></a></div>
      <div class="col s12 m9"><p><b>LEGIS ARANCEL ELECTRÓNICO</b><br>
Herramienta de consulta informática, que permite consultar toda la nomenclatura arancelaria de Colombia y asocia a cada subpartida arancelaria los vistos buenos, permisos especiales, impuestos y derechos a la Importación, Normas de Origen, Resoluciones Oficiales de Clasificación Arancelaría, índice de productos y notas explicativas y legales, entre otros atributos. Permite: clasificar correctamente las mercancías, conocer los Derecho e Impuestos a la Importación y cumplir adecuadamente con las exigencias impuestas por las diferentes entidades regulatorias y de control.
</p></div>
 </div><!-- cierro fila -->



     
        </div><!-- cierro div colapsable -->
          </li>







<!-- Libros Electrónicos -->

    <li class="">
      <div class="collapsible-header"><i class="material-icons">library_books</i>Libros Electrónicos</div>
      <div class="collapsible-body" style="display: none;">
 
<div class="row">
<div class="col s12 m3"><a href="https://academiaurepublicana.org/ArKa/test/new_login.php" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1713210964.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>SIGLO DEL HOMBRE DIGITAL</b><br>
Colección de libros digitales en texto completo, especializados en las diferentes áreas del Derecho. </p></div>
 </div>


<div class="row">
<div class="col s12 m3"><a href="https://academiaurepublicana.org/ArKa/test/new_login.php" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1713211037.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>IBÁÑEZ DIGITAL</b><br>
Colección de libros digitales en texto completo, especializados en las diferentes áreas del Derecho </p></div>
 </div>

 
<div class="row">
<div class="col s12 m3"><a href="https://academiaurepublicana.org/ArKa/test/new_login.php" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1602798105.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>PEARSON EDUCATION</b><br>
Colección de títulos electrónicos que proporciona el texto completo de libros especializados en las áreas académicas de administración, economía, derecho, ingeniería, historia, matemáticas, cálculo, álgebra, filosofía, sistemas, entre otras. </p></div>
 </div>


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://academiaurepublicana.org/ArKa/test/new_login.php" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553194719.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>McGrawnGil Digital</b><br>
Plataforma que permite fácil acceso en línea a una colección de más de 200 títulos de libros electrónicos en las áreas de ciencias básicas, ingeniería aplicada, negocios y ciencias sociales.</p></div>
 </div><!-- cierro fila -->


    

<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://academiaurepublicana.org/ArKa/test/new_login.php" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553194736.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>Ecoe Ebooks</b><br>
Ofrece acceso en línea a libros electrónicos e las pareas Administración, Finanzas, Economía, Derecho, Ciencias Básicas, Ingeniería, Ciencias Ambientales, Humanidades, Educación y Pedagogía.</p></div>
 </div><!-- cierro fila -->

      </div>
         </li>










<!-- Bases de datos Libres -->


    <li class="">
      <div class="collapsible-header"><i class="material-icons">archive</i>Bases de datos Libres</div>
      <div class="collapsible-body" style="display: none;">


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://ieeexplore.ieee.org/document/6461145" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1729870354.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>IEEE XPLORE DIGITAL LIBRARY</b><br>
Es una base de datos de investigación académica que proporciona acceso al texto completo de artículos y trabajos sobre Ciencias de la Computación, Ingeniería Eléctrica y Electrónica.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://ntrs.nasa.gov/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1729870873.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>NASA TECHNICAL REPORTS SERVER (NTRS)</b><br>
Acceso a registros de metadatos de la NASA, documentos en línea de texto completo, imágenes y videos. Los tipos de información incluidos son artículos de conferencias, artículos de revistas, documentos de reuniones, patentes, informes de investigación, imágenes, películas y videos técnicos.</p></div>
 </div><!-- cierro fila -->

<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://uniwebsidad.com/?from=librosweb" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1729870978.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>UNIWEBSIDAD</b><br>
Portal de Libros electrónicos especializado en la programación de páginas web en XHTML, CSS y otros, además de libros para la programación en Javascript.</p></div>
 </div><!-- cierro fila -->

<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.minjusticia.gov.co/programas-co/LegalApp" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1729871299.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>LEGALApp</b><br>
Es una herramienta electrónica para todos los ciudadanos que necesiten conocer cómo adelantar un trámite o hacer uso de algún servicio relacionado con la Justicia.</p></div>
 </div><!-- cierro fila -->

<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://worldwide.espacenet.com/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1729871608.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>ESP@CENET</b><br>
Permite la consulta de diferentes bases de datos relacionadas con las patentes: AP Database, WIPO Database y Worldwide Database.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.dynapubli.com/inicio-dynapubli" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1729871812.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>PUBLICACIONES DYNA </b><br>
Es una editorial técnico-científica de la Federación de Asociaciones de Ingenieros Industriales de España (FAIIE), que publica contenidos y revistas en el campo de la ingeniería multidisciplinar.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.ellibrototal.com/ltotal/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1729875853.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>EL LIBRO TOTAL </b><br>
Es la mayor plataforma digital gratuita de libros en español, más grande de América; tiene más de 50 000 títulos diferentes.  Acceso a más de 50 diccionarios.</p></div>
 </div><!-- cierro fila -->



<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.lareferencia.info/es/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1729876244.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>LA REFERENCIA </b><br>
Es una red latinoamericana de repositorios de acceso abierto.  Apoya las estrategias nacionales de acceso abierto en América Latina, dando visibilidad a la producción científica generada en las instituciones de educación superior y de investigación científica.</p></div>
 </div><!-- cierro fila -->






<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://citeseerx.ist.psu.edu/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1729876579.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>CiteSeer</b><br>
Es una biblioteca digital de literatura científica centrada principalmente en la literatura en informática y ciencias de la información.</p></div>
 </div><!-- cierro fila -->



<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://hapi.ucla.edu/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1729876713.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>HAPI</b><br>
Base de datos de acceso libre, ofrece información de política, economía, artes, literatura, ciencias sociales y humanidades.</p></div>
 </div><!-- cierro fila -->

<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.sciencedirect.com/#open-access" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1729876900.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>ScienceDirect®</b><br>
Es la mayor colección electrónica en ciencia, tecnología y medicina, en texto completo y de libre acceso</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://biblat.unam.mx/es/sobre-biblat" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1729877193.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>BIBLAT</b><br>
Bibla - Bibliografía Latinoamericana, es un Portal especializado en revistas científicas y académicas publicadas en América Latina y el Caribe, que ofrece referencias bibliográficas y texto completo de los artículos y documentos publicados en más de 3,000 revistas indizadas. Posee visualización gráfica de indicadores.</p></div>
 </div><!-- cierro fila -->

<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.ifac.org/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1729877320.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>INTERNATIONAL FEDERATION OF ACCOUNTANTS</b><br>
International Federation of Accountants,  está conformada por organizaciones de contaduría profesional reconocidas por ley o por el consenso general en sus países.  Su propósito es proteger al interés público, mediante el desarrollo de estándares internacionales de calidad, la promoción de valores éticos, fomento de la calidad en la práctica profesional y el apoyo de la profesión en todo el mundo.</p></div>
 </div><!-- cierro fila -->

<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.dgb.unam.mx/index.php/catalogos/bibliografia-latinoamericana/periodica" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1729877615.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>PERIODICA</b><br>
Índice de Revistas Latinoamericanas en Ciencias es una base de datos en la Universidad Nacional Autónoma de México (UNAM). Ofrece registros bibliográficos de artículos originales, informes técnicos, estudios de caso, estadísticas y otros documentos publicados en revistas de América Latina y el Caribe, especializadas en ciencia y tecnología. Abarca áreas en: agro ciencias, computación, física, geofísica, ingeniería, matemáticas, química, entre otras.</p></div>
 </div><!-- cierro fila -->









<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://bibliotecadigital.ccb.org.co/home" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1713212505.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>CÁMARA DE COMERCO DE BOGOTÁ</b><br>
Material especializado de libre acceso y gratuito en temas relacionados con el entorno de los negocios, creación de empresas, emprendimiento, temas jurídicos, cívicos y sociales de Bogotá y la Región</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="http://www.springeropen.com/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1713212667.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>SPRINGER OPEN</b><br>
Ofrece a los investigadores de todas las áreas de la ciencia, la tecnología, las humanidades y las ciencias sociales un lugar para publicar en acceso abierto en revistas, haciendo que los trabajos estés disponibles inmediatamente después de su publicación. Los libros de acceso abierto son publicados por el sello Springer.</p></div>
 </div><!-- cierro fila -->



<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://biblioteca.ciess.org/adiss/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1713213066.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>ACERVO DIGITAL INSTITUCIONAL EN SEGURIDAD SOCIAL – ADISS</b><br>
Acervo Digital en Seguridad Social es el repositorio institucional de la Conferencia Interamericana de Seguridad Social y su Centro de Estudios. Creado con la finalidad de preservar y poner a disposición de los usuarios, su producción editorial histórica y académica.</p></div>
 </div><!-- cierro fila -->



<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://datos.bancomundial.org/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1713213269.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>BANCO MUNDIAL / DATOS ESTADÍSTICOS</b><br>
Datos sectoriales, macroeconómicos y financieros del Banco Mundial, claves en cualquier estrategia general de desarrollo y útiles para realizar estudios sobre pobreza.</p></div>
 </div><!-- cierro fila -->



<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.bancomundial.org/es/who-we-are/contacts/publications" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1713213269.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>BANCO MUNDIAL / PUBLICACIONES</b><br>
Biblioteca Digital con cerca de 25 000 títulos de informes, libros, revistas y otros documentos editados por el Banco Mundial o auspiciados por él.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://bapp.com.co/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1713213787.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>Biblioteca Abierta del Proceso de Paz colombiano (BAPP)</b><br>
La BAPP busca ser el centro de conocimiento interactivo más completo sobre el proceso de paz entre el gobierno colombiano y las FARC-EP. En este sentido, la plataforma se actualizará frecuentemente para incluir contenidos que complementen las diferentes secciones.</p></div>
 </div><!-- cierro fila -->



<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.uexternado.edu.co/delfos-centro-analisis-datos/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1713215020.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b></b><br>
Galería de mapas que muestra los datos trabajados en los proyectos del Centro de Análisis de Datos de la Universidad Externado de Colombia, en diferentes ejes de investigación, como muertes por conflictos, terrorismo y violencia colectiva. Los mapas son de elaboración propia con base en datos de Global Burden Disease (GBD) y a la Organización Mundial de la Salud (OMS).</p></div>
 </div><!-- cierro fila -->



<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.doabooks.org/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1713214384.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>DOAB – DIRECTORY OF OPEN ACCESS BOOKS</b><br>
Índice de títulos revisados por expertos, publicados bajo un modelo de negocio de acceso abierto. Contiene enlaces a textos completos en diferentes sitios web o repositorios.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.asobancaria.com/biblioteca/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1713215206.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>LIBROS – ASOBANCARIA</b><br>
Selección de publicaciones que se han realizado desde la Asociación Bancaria y de Entidades Financieras de Colombia, donde se pueden consultar los diferentes libros, cartillas, memorias, guías. Están organizados por temas de interés y por año publicación.</p></div>
 </div><!-- cierro fila -->



<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://oatd.org/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1713215397.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>OPEN ACCESS THESES AND DISSERTATIONS</b><br>
Buscador especializado que recupera tesis doctorales y trabajos académicos de todo el mundo, de más de 1100 universidades e instituciones de investigación, disponibles en acceso abierto.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.gutenberg.org/ebooks/search/?query=spanish" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1713215673.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>PROYECTO GUTEMBERG</b><br>
Este sitio ofrece el acceso a más de 46 000 libros electrónicos gratuitos, en diferentes formatos, con la posibilidad de descargarlos inmediatamente.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.mendeley.com/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1713216108.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>MENDELEY</b><br>
Es una aplicación web gratuita que funciona como gestor de referencias bibliográficas, de tal forma que el investigador pueda organizar la información mediante la administración de los documentos en línea</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.zotero.org/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1713216530.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>ZOTERO</b><br>
Este programa de acceso libre permite administrar las referencias bibliográficas de libros, revistas, medios web, Etc.</p></div>
 </div><!-- cierro fila -->




<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://scielo.conicyt.cl/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553194806.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>SCIENTIFIC ELECTRONIC LIBRARY ONLINE</b><br>
Bases de Datos de acceso a texto Completo de Revistas Científicas especializada en Ciencias de la Salud, organizadas por materias.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.doaj.org/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553194831.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>DIRECTORY OF OPEN ACCESS JOURNAL</b><br>
Directorio de Revistas Científicas de Acceso Abierto, gratuito y de texto completo, cubre Revistas cientificas y de Calidad de todos los temas e idiomas.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://arxiv.org/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553194851.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>ARXIV</b><br>
Es una plataforma que incluye artículos de las disciplinas de la Física, Matemáticas, Computación y Biología cuantitativa.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.biomedcentral.com/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553194878.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>PHYSMATHCENTRAL</b><br>
Plataforma de publicaciones independientes, manejada por el comité de Biomed Central para proveer el acceso abierto a investigaciones en los campos de la Física y las Matemáticas.</p></div>
 </div><!-- cierro fila -->



    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.comunidadandina.org/bibliocan/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553194916.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>BIBLIOTECA DIGITAL ANDINA</b><br>
Informacion en todas las áreas del conocimiento.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->

<div class="col s12 m3"><a href="https://www.tesisenred.net/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553194931.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>TRABAJOS DOCTORALES EN LA RED</b><br>
Acceso a texto completo de tesis doctorales de universidades españolas, en todas las áreas del conocimiento.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://eumed.net/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553194949.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>EUMED.NET</b><br>
Libros digitales en texto completo en temas de ciencias sociales.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.wdl.org/es/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553194967.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>BIBLIOTECA DIGITAL MUNDIAL</b><br>
Información en todas las áreas del conocimiento.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="http://www.humanindex.unam.mx/humanindex/consultas/parametros.html" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553194983.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>HUMANINDEX</b><br>
Proporciona información sobre los productos científicos generados por los investigadores de los 10 institutos, 7 centros y 3 programas del Subsistema de Humanidades de la Universidad Nacional Autónoma de México.</p></div>
 </div><!-- cierro fila -->

 
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://openknowledge.worldbank.org/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195010.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>OPEN KNOWLEDGE REPOSITORY</b><br>
Repositorio de acceso libre del Banco Mundial que contiene sus informes de investigación y demás productos de conocimiento.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="http://www.cervantesvirtual.com/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195032.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>BIBLIOTECA VIRTUAL MIGUEL DE CERVANTES</b><br>
Información en todas las áreas del conocimiento.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="http://biblioteca.clacso.edu.ar/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195048.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>CLACSO</b><br>
Red de Bibliotecas Virtuales de Ciencias Sociales de América Latina y el Caribe con información en todas las áreas del conocimiento.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://cybertesis.unmsm.edu.pe/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195063.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>CYBERTESIS</b><br>
Base de datos de tesis de diferentes universidades con acceso abierto en texto completo.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://dialnet.unirioja.es/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195077.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>DIALNET</b><br>
Es una base de datos de artículos de revistas españolas e hispanoamericanas que ofrece el acceso a más 730.000 artículos de unas 2.850 revistas de todas las disciplinas científicas. No todos los accesos a los artículos de texto completo son gratuitos.</p></div>
 </div><!-- cierro fila -->



    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://books.google.com/?hl=es" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195107.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>GOOGLE BOOKS</b><br>
Google Books ofrece libros digitales completos de dominio público de diversa temática y libros que no poseen una visión total de su contenido, por encontrarse aún en venta.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="http://repec.org/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195123.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>RePEc - Research Papers in Economics</b><br>
Es un esfuerzo de colaboración de cientos de voluntarios en 93 países para mejorar la difusión de la investigación en Economía y ciencias relacionadas.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://ddd.uab.cat/pub/ciencies/ciencies_a2012m3n21/suplement/index.html.4" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195147.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>E- REVISTAS</b><br>
La Plataforma Open Access de Revistas Científicas Electrónicas Españolas y Latinoamericanas e-Revistas es un proyecto impulsado por el Consejo Superior de Investigaciones Científicas (CSIC) con el fin de contribuir a la difusión y visibilidad de las revistas científicas publicadas en América Latina, Caribe, España y Portugal.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="http://portal.pepsic.bvsalud.org/php/index.php" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195166.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>PEPSIC</b><br>
Este portal tiene como objetivo principal contribuir a la visibilidad del conocimiento psicológico y científico generado en los países de América Latina, a partir de la publicación de revistas científicas en acceso abierto.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="http://www.oapen.org/home" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195183.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>OAPEN</b><br>
Contiene libros académicos de acceso libre, principalmente en el área de Humanidades y Ciencias Sociales.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://onlinelibrary.wiley.com/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195198.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>Wiley Open Access</b><br>
Es un programa de revistas de acceso abierto. Todos los artículos de investigación publicados disponibles de forma gratuita para leer, descargar y compartir.</p></div>
 </div><!-- cierro fila -->



    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="http://www.suin-juriscol.gov.co/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195227.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>SUIN-JURISCOL</b><br>
Permite ubicar de forma rápida y gratuita, normas de carácter general y abstracto como las constituciones de 1886 y de 1991, actos legislativos, leyes, decretos, directivas presidenciales, resoluciones, circulares, entre otros, a partir de 1886, con sus respectivas concordancias y afectaciones normativas y jurisprudenciales.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.osti.gov/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195247.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>SCITECH CONNECT</b><br>
Conexión a la información de investigación científica, tecnológica y de ingeniería del Departamento de Energía de EE. UU.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://eur-lex.europa.eu/homepage.html" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195263.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>EUR-LEX</b><br>
El acceso al Derecho de la Unión Europea.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://worldwidescience.org/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195285.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>WORLD WIDE SCIENCE ALLIANCE</b><br>
Es una puerta de acceso científica mundial compuesta por bases de datos y portales científicos nacionales e internacionales.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.artehistoria.com/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195313.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>ARTE HISTORIA</b><br>
Contiene información de consulta libre sobre acontecimientos mundiales historia del arte, historia universal e historia de España.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.wipo.int/reference/es/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195337.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>OMPI</b><br>
Es la principal fuente de datos en el mundo sobre el sistema de propiedad intelectual (P.I.), así como sobre estudios empíricos, informes y datos sobre P.I. Todas las publicaciones y las colecciones de datos de la OMPI están disponibles en Internet sin cargo.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.sic.gov.co/pi/cigepi" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195361.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>CIGEPI</b><br>
El Centro de Información Tecnológica y Apoyo a la Gestión de la Propiedad Industrial (CIGEPI) es el encargado de proporcionar servicios de información tecnológica y orientación especializada en temas de Propiedad Industrial en Colombia.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="http://oaji.net/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195384.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>OPEN ACADEMIC JOURNALS INDEX (OAJI)</b><br>
Es una base de datos de texto completo de revistas científicas de acceso abierto. Fundador - Centro de redes internacionales para investigación fundamental y aplicada, Federación de Rusia. Nuestra misión es desarrollar una plataforma internacional para indexar las revistas científicas de acceso abierto.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://scholar.google.es/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195412.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>GOOGLE ACADÉMICO</b><br>
Es un buscador que te permite localizar documentos académicos como artículos, tesis, libros y resúmenes de fuentes diversas como editoriales universitarias, asociaciones profesionales, repositorios de preprints, universidades y otras organizaciones académicas.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="http://www.dotec-colombia.org/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195426.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>DOTEC-COLOMBIA</b><br>
Es un proyecto virtual que busca centralizar y divulgar la investigación económica en Colombia.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="http://www.citchile.cl/b2c.htm" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195437.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>ACTUALIDAD IBEROAMERICANA</b><br>
Es un índice Internacional de revistas publicadas en idioma Castellano, en diversos países iberoamericanos. Actualidad Iberoamericana provee información básica sobre revistaz en idioma castellano en diversas áreas de las ciencias, las ingenierías y las humanidades, y las cataloga por áreas del conocimiento.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://econpapers.repec.org/article/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195462.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>EconPapers</b><br>
EconPapers proporciona acceso a RePEc, es la mayor colección del mundo de la economía en línea documentos de trabajo, artículos de revistas y software.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://ideas.repec.org/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195482.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>Ideas</b><br>
Ideas es la base de datos bibliográfica más grande dedicada a la economía; indexa más de 2.500.000 artículos de investigación, incluidos más de 2.300.000 que se pueden descargar en texto completo.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.ssrn.com/index.cfm/en/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195498.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>SSRN</b><br>
SSRN contiene áreas de contabilidad financiera, administrativa y auditoria, impuestos y litigios; ciencias cognitivas (psicología, sociología, lingüística, neurofisiología, etc.); gobierno corporativo, economía, administración empresarial; economía financiera, finanzas corporativas, banca e instituciones financieras, mercado de capitales, derivados y bienes inmuebles; comercio electrónico y sistemas de información, administración y negocios internacionales; liderazgo, derecho, producción, investigación de operaciones, mercadeo, música y composición y filosofía.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.redalyc.org/home.oa" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195515.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>Redalyc</b><br>
Es una base de datos multidisciplinaria. Red de revistas científicas de América Latina y El Caribe, España y Portugal.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://sisjur.bogotajuridica.gov.co/sisjur/index.jsp" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553196022.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>Biblioteca Virtual Jurídica de Bogotá</b><br>
La Biblioteca Virtual Jurídica de Bogotá - BVB es un instrumento de documentación para la difusión de la normatividad, la doctrina distrital y las decisiones judiciales de impacto para la administración distrital.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://redib.org/?lng=es" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195549.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>REDIB</b><br>
Red Iberoamericana de Innovación y Conocimiento Científico - REDIB es una plataforma de agregación de contenidos científicos y académicos en formato electrónico producidos en el ámbito iberoamericano, relacionados con él en un sentido cultural y social más amplio y geográficamente no restrictivo.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://www.e-booksdirectory.com/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195563.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>E-BOOKS</b><br>
E-Books Directory es una lista de enlaces a libros electrónicos, documentos y notas de conferencias de acceso libre. Contiene aproximadamente 10587 libros electrónicos gratuitos en 688 categorías.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="http://www.freefullpdf.com/#menu&amp;gsc.tab=0" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195578.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>FreeFullpdf</b><br>
FreeFullpdf es un buscador de artículos científicos, patentes, tesis doctorales y posters, en formato pdf. Ofrece unos 80 millones de documentos pertenecientes a las principales áreas científicas relacionadas con ciencias de la salud, biología, medicina-, ciencias físicas, ingeniería y también ciencias sociales y humanidades.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://revistas.unam.mx/catalogo/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195593.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>Revistas unam</b><br>
El portal Revistas UNAM de la Universidad Nacional Autónoma de México, es un sistema de información en línea que permite, tanto a los universitarios como al público en general, consultar información catalográfica y acceder a una gran cantidad de artículos que se encuentran publicados en formato digital en distintos sitios web institucionales.</p></div>
 </div><!-- cierro fila -->



    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="http://cogprints.org/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195622.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>Cogprints</b><br>
Cogprints es un archivo electrónico de artículos en las áreas de Psicología, Neurociencia y Lingüística.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="http://www.ifac.org/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195638.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>IFAC</b><br>
IFAC es la organización global de la profesión contable dedicada a servir al interés público mediante el fortalecimiento de la profesión y la contribución al desarrollo de economías internacionales. Está compuesta por más de 175 miembros y asociados en más de 130 países, que representan a casi 3 millones de contadores en la práctica pública, la educación, el servicio gubernamental, la industria y el comercio.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://docs.wto.org/dol2fe/Pages/FE_Search/FE_S_S005.aspx" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195655.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>WTO DOCUMENTS ONLINE</b><br>
Permite acceder a la documentación oficial de la Organización Mundial del Comercio. Contiene más de 100.000 documentos en los tres idiomas oficiales, distribuidos a partir de 1995. Todos los documentos de la OMC están disponibles en formato PDF y en formato WORD. La aplicación incluye un registro descriptivo de cada documento archivado. Es posible consultar en línea todos esos documentos y descargarlos.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://docta.ucm.es/home" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195670.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>Eprints</b><br>
Contiene todo tipo de documentos elaborados por docentes e investigadores de la Universidad Complutense de Madrid.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://bookboon.com/es" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195685.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>bookboon</b><br>
Base de datos multidisciplinaria de libros.</p></div>
 </div><!-- cierro fila -->


<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="https://eric.ed.gov/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195698.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>Eric</b><br>
Es una base de datos bibliográfica, con acceso a textos completos de artículos y otros materiales educativos, tales como audio y video, con un cubrimiento desde 1966 hasta la fecha.</p></div>
 </div><!-- cierro fila -->

    
<div class="row"><!-- abro fila -->
<div class="col s12 m3"><a href="http://www.gestorcc.org/" target="_blank"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1553195711.jpg" width="90%"></a></div>
      <div class="col s12 m9"><p><b>GestorCC</b><br>
Gestor Comercial y de Crédito es un sistema de Administración de Información Financiera de más de 45.000 empresas Colombianas con el fin de realizar análisis financieros de: Competencia Comercial, Grupos Económicos, Sectores especializados como Pyme, Empresariales o Corporativos, identificación de la muestra "Pareto 80/20", empresas en su tendencia financiera, comparación frente a la economía en general, frente al sector y frente a otra empresa tipo.</p></div>
 </div><!-- cierro fila -->





















<!-- Revistas Electrónicas de Acceso Libre -->


 </div></li><li>
      <div class="collapsible-header"><i class="material-icons">system_update</i>Revistas Electrónicas de Acceso Libre</div>
      <div class="collapsible-body">

<br><h5 style="text-align: center;"><b>DERECHO</b></h5><h5 style="text-align: center;"><iframe class="video" src="https://urepublicana.edu.co/images/web/biblioteca/revistasDerecho.pdf" =""="" frameborder="0" style="font-size: 15px; height: 900px;"></iframe><br></h5>

<br><h5 style="text-align: center;"><b>TRABAJO SOCIAL</b></h5><h5 style="text-align: center;"><iframe class="video" src="https://urepublicana.edu.co/images/web/biblioteca/revistasTrabajoSocial.pdf" =""="" frameborder="0" style="font-size: 15px; height: 900px;"></iframe><br></h5>

<br><h5 style="text-align: center;"><b>CONTADURÍA Y FINANZAS</b></h5><h5 style="text-align: center;"><iframe class="video" src="https://urepublicana.edu.co/images/web/biblioteca/revistasFinanzasyContadura.pdf" =""="" frameborder="0" style="font-size: 15px; height: 900px;"></iframe><br></h5>

<br><h5 style="text-align: center;"><b>INGENIERÍA Y MATEMÁTICAS</b></h5><h5 style="text-align: center;"><iframe class="video" src="https://urepublicana.edu.co/images/web/biblioteca/revistasIngenieriaMatematica.pdf" =""="" frameborder="0" style="font-size: 15px; height: 900px;"></iframe><br></h5>

</div>
</li> 
   </ul>

</div>			
                        
                        
		<!-- NUEVAS ADQUISICIONES -->
			<div id="biblio_nuevas" class="col s12 content_urep ocultar">
				<h5>Nuevas Adquisiciones</h5>
				<div class="row center">


<br>
	
	<!-- Libros -->
	
	
<ul class="collapsible">
    <li>
      <div class="collapsible-header"><i class="material-icons">library_books</i>Libros</div>
      <div class="collapsible-body">
		  
		  
<div class="col s12 m12"><h4 align="center"><b>Boletín de Nuevas Adquisiciones / Marzo de 2019</b></h4></div>
<div class="col s12 m12"><h4 align="center"><b>Libros</b></h4></div>
		  
<div class="row"><!-- abro fila -->
<div class="col s12 m3" align="center"><div class="material-placeholder" style=""><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554322553.jpg" class="materialboxed initialized" data-caption="Manual de retención en la fuente 2019" width="80%"></div></div>      
        <div class="col s12 m9">
<p><b>Título:</b><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15162&amp;query_desc=ti,wrdl:%20manual%20de%20retencion%20en%20la%20fuente" target="_blank">Manual de retención en la fuente 2019</a></p>
<p><b>Autor:</b> Legis Editores (Colombia).</p>
<p><b>Editorial, Año:</b> Legis, 2019.</p>
<p><b>Temas:</b> RETENCIÓN EN LA FUENTE - MANUALES - COLOMBIA | IMPUESTOS SOBRE LA RENTA - MANUALES - COLOMBIA</p>
<p><b>Solicítelo como:</b>336.209 M15 / 2019</p></div>
       </div><!-- cierro fila -->
		  
		
		<div class="row">
<div class="col s12 m3" align="center"><div class="material-placeholder"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554322567.jpg" class="materialboxed initialized" data-caption="Reforma  tributaria  comentada : ley de financiamiento" width="80%"></div></div>
      <div class="col s12 m9"><!-- abro fila -->
<p><b>Título:</b><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15166&amp;query_desc=ti%2Cwrdl%3A%20reforma%20tributaria%20comentada" target="_blank"> Reforma  tributaria  comentada : ley de financiamiento (L. 1943/2018)</a></p>
<p><b>Autor:</b> Fernando Zarama Vásquez</p>
<p><b>Editorial, Año:</b> Legis, 2019.</p>
<p><b>Temas:</b> REFORMA TRIBUTARIA - COLOMBIA | IMPUESTOS SOBRE LA RENTA - LEGISLACION | IMPUESTOS SOBRE LAS VENTAS - LEGISLACION - COLOMBIA | DERECHO FISCAL - COLOMBIA</p>
<p><b>Solicítelo como:</b>336.205 Z84r</p></div>
</div><!-- cierro fila -->


<div class="row">
<div class="col s12 m3" align="center"><div class="material-placeholder"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554324250.jpg" class="materialboxed initialized" data-caption="Guía para atender las visitas y requerimientos de la UGPP" width="80%"></div></div>
      <div class="col s12 m9"><!-- abro fila -->
<p><b>Título:</b><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15164&amp;query_desc=ti%2Cwrdl%3A%20VISITAS" target="_blank"> Guía para atender las visitas y requerimientos de la UGPP</a></p>
<p><b>Autor:</b> Andrés Felipe Torrado Álvarez, Carla Alexandra Sarmiento Colmenares.</p>
<p><b>Editorial, Año:</b> Legis, 2019.</p>
<p><b>Temas:</b> AUDITORÍA FISCAL – LEGISLACIÓN - COLOMBIA | DERECHO FISCAL - LEGISLACIÓN - COLOMBIA | SEGURIDAD SOCIAL - LEGISLACIÓN - COLOMBIA</p>
<p><b>Solicítelo como:</b>344.3 C65g  /  2019</p></div>
</div><!-- cierro fila -->


<div class="row">
<div class="col s12 m3" align="center"><div class="material-placeholder"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554324278.jpg" class="materialboxed initialized" data-caption="Cartilla laboral 2019" width="80%"></div></div>
      <div class="col s12 m9"><!-- abro fila -->
<p><b>Título:</b><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15161&amp;query_desc=kw%2Cwrdl%3A%20Cartilla%20laboral%202019" target="_blank"> Cartilla laboral 2019</a></p>
<p><b>Autor:</b> Legis Editores (Colombia).</p>
<p><b>Editorial, Año:</b> Legis, 2019.</p>
<p><b>Temas:</b> LEGISLACIÓN LABORAL - COLOMBIA | LEGISLACIÓN SOBRE CONTRATOS DE TRABAJO - COLOMBIA  | LEGISLACIÓN EN SUSPENSIÓN DE EMPLEADOS - COLOMBIA  |  PRESTACIONES SOCIALES - COLOMBIA </p>
<p><b>Solicítelo como:</b>344.01 L23c  /  2019</p></div>
</div><!-- cierro fila -->


<div class="row">
<div class="col s12 m3" align="center"><div class="material-placeholder"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554324406.jpg" class="materialboxed initialized" data-caption="Cartilla de Seguridad Social y Pensiones 2019" width="80%"></div></div>
      <div class="col s12 m9"><!-- abro fila -->
<p><b>Título:</b><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15159&amp;query_desc=kw%2Cwrdl%3A%20Cartilla%20de%20Seguridad%20Social%20y%20Pensiones%20Legis%20Editores" target="_blank"> Cartilla de Seguridad Social y Pensiones 2019</a></p>
<p><b>Autor:</b> Legis Editores (Colombia).</p>
<p><b>Editorial, Año:</b> Legis, 2019.</p>
<p><b>Temas:</b> SEGURIDAD SOCIAL -- LEGISLACIÓN -- COLOMBIA | PENSIONES A LA VEJEZ -- LEGISLACIÓN -- COLOMBIA | SISTEMA GENERAL DE SEGURIDAD SOCIAL EN SALUD -- COLOMBIA | SISTEMA GENERAL DE RIESGOS PROFESIONALES -- COLOMBIA | LEY 100 DE 1993 </p>
<p><b>Solicítelo como:</b>344.02 C17c  /  2019</p></div>
</div><!-- cierro fila -->


<div class="row">
<div class="col s12 m3" align="center"><div class="material-placeholder"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554324470.jpg" class="materialboxed initialized" data-caption="NAI Normas de aseguramiento de la información : DUR 2420 de 2015" width="80%"></div></div>
      <div class="col s12 m9"><!-- abro fila -->
<p><b>Título:</b><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15165&amp;query_desc=kw%2Cwrdl%3A%20normas%20de%20aseguramiento%202019" target="_blank"> NAI Normas de aseguramiento de la información : DUR 2420 de 2015 (anexos 4, 4.1 y 4.2 integrados ) : actualizado con los cambios del Decreto 2170 de 2017</a></p>
<p><b>Autor:</b> Legis Editores (Colombia).</p>
<p><b>Editorial, Año:</b> Legis, 2019.</p>
<p><b>Temas:</b> AUDITORÍA - NORMAS INTERNACIONALES | AUDITORÍA FINANCIERA - NORMAS INTERNACIONALES | CONTABILIDAD - NORMAS INTERNACIONALES | CONTABILIDAD - CONTROL DE CALIDAD - NORMAS INTERNACIONALES | CONTADORES - ÉTICA PROFESIONAL -- NORMAS INTERNACIONALES </p>
<p><b>Solicítelo como:</b>657.45 N67</p></div>
</div><!-- cierro fila -->


<div class="row">
<div class="col s12 m3" align="center"><div class="material-placeholder"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554324603.jpg" class="materialboxed initialized" data-caption="Manual práctico de IVA y facturación 2019" width="80%"></div></div>
      <div class="col s12 m9"><!-- abro fila -->
<p><b>Título:</b><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15160&amp;query_desc=kw%2Cwrdl%3A%20manual%20practico%20iva" target="_blank"> Manual práctico de IVA y facturación 2019</a></p>
<p><b>Autor:</b> Carlos Giovanni Rodríguez Vásquez.</p>
<p><b>Editorial, Año:</b> Legis, 2019.</p>
<p><b>Temas:</b> IMPUESTOS AL VALOR AGREGADO - COLOMBIA | IMPUESTOS DE TIMBRE - COLOMBIA | IMPUESTOS SOBRE LAS VENTAS - COLOMBIA | IMPUESTOS - COLOMBIA  </p>
<p><b>Solicítelo como:</b>336.271 M15</p></div>
</div><!-- cierro fila -->


<div class="row">
<div class="col s12 m3" align="center"><div class="material-placeholder"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554324614.jpg" class="materialboxed initialized" data-caption="Medios magnéticos presentación de información tributaria 2019" width="80%"></div></div>
      <div class="col s12 m9"><!-- abro fila -->
<p><b>Título:</b><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15163&amp;query_desc=kw%2Cwrdl%3A%20MEDIOS%20MAGNETICOS%20LEGIS" target="_blank"> Medios magnéticos presentación de información tributaria 2019</a></p>
<p><b>Autor:</b> Legis Editores (Colombia).</p>
<p><b>Editorial, Año:</b> Legis, 2019.</p>
<p><b>Temas:</b> IMPUESTOS - COLOMBIA - PREGUNTAS Y RESPUESTAS | RECAUDACIÓN DE IMPUESTOS - COLOMBIA - PREGUNTAS Y RESPUESTAS | DERECHO FISCAL - COLOMBIA - PREGUNTAS Y RESPUESTAS  </p>
<p><b>Solicítelo como:</b>343.04 L23m</p></div>
</div><!-- cierro fila -->


<div class="row">
<div class="col s12 m3" align="center"><div class="material-placeholder"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554325284.jpg" class="materialboxed initialized" data-caption="Administración y control de la calidad" width="80%"></div></div>
      <div class="col s12 m9"><!-- abro fila -->
<p><b>Título:</b><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=12563" target="_blank"> Administración y control de la calidad</a></p>
<p><b>Autor:</b> James R. Evans </p>
<p><b>Editorial, Año:</b> Thomson, 2015</p>
<p><b>Temas:</b> CALIDAD TOTAL EN ADMINISTRACIÓN | CONTROL DE CALIDAD – MÉTODOS ESTADÍSTICOS | CALIDAD DE LOS PRODUCTOS  </p>
<p><b>Solicítelo como:</b>658.568 E81a</p></div>
</div><!-- cierro fila -->


<div class="row">
<div class="col s12 m3" align="center"><div class="material-placeholder"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554325297.jpg" class="materialboxed initialized" data-caption="Acuerdo final para la terminación del conflicto y la construcción de una paz estable y duradera." width="80%"></div></div>
      <div class="col s12 m9"><!-- abro fila -->
<p><b>Título:</b><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=10716" target="_blank"> Acuerdo final para la terminación del conflicto y la construcción de una paz estable y duradera.</a></p>
<p><b>Autor:</b> Gobierno de Colombia -FARC- EP. </p>
<p><b>Editorial, Año:</b> Editorial Temis, 2016.</p>
<p><b>Temas:</b> FUERZAS ARMADAS REVOLUCIONARIAS DE COLOMBIA - ACUERDOS DE PAZ - SIGLO XXI / PROCESO DE PAZ - SIGLO XXI - COLOMBIA | DESMOVILIZACIÓN DE GUERRILLAS - SIGLO XXI - COLOMBIA | PAZ - SIGLO XXI - COLOMBIA | SOLUCIÓN DE CONFLITOS - SIGLO XXI - COLOMBIA  </p>
<p><b>Solicítelo como:</b>303.690 A12</p></div>
</div><!-- cierro fila -->


<div class="row">
<div class="col s12 m3" align="center"><div class="material-placeholder"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554325312.jpg" class="materialboxed initialized" data-caption="Acuerdos y allanamientos : descubrimiento acusatorio anticipado" width="80%"></div></div>
      <div class="col s12 m9"><!-- abro fila -->
<p><b>Título:</b><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=11482" target="_blank"> Acuerdos y allanamientos : descubrimiento acusatorio anticipado </a></p>
<p><b>Autor:</b> Alejandro Felipe Sánchez Cerón </p>
<p><b>Editorial, Año:</b> Universidad Externado de Colombia, 2016</p>
<p><b>Temas:</b> SISTEMA ACUSATORIO | PROCESO PENAL | ALLANAMIENTO | CONTROL JUDICIAL | PRUEBAS JUDICIALES ECONOMICOS  </p>
<p><b>Solicítelo como:</b>345.6 S17a</p></div>
</div><!-- cierro fila -->


<div class="row">
<div class="col s12 m3" align="center"><div class="material-placeholder"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554325324.jpg" class="materialboxed initialized" data-caption="Alfabetización digital para excombatientes de grupo irregulares contexto colombiano de inclusión educativa para la paz" width="80%"></div></div>
      <div class="col s12 m9"><!-- abro fila -->
<p><b>Título:</b><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=12351" target="_blank"> Alfabetización digital para excombatientes de grupo irregulares contexto colombiano de inclusión educativa para la paz </a></p>
<p><b>Autor:</b> Sandra Liliana torres Taborda  </p>
<p><b>Editorial, Año:</b> Unisabaneta, 2016</p>
<p><b>Temas:</b> INCLUSIÓN SOCIAL – COLOMBIA | ALFABETIZACIÓN DIGITAL – ENSEÑANZA – COLOMBIA | REINTEGRACIÓN SOCIAL  </p>
<p><b>Solicítelo como:</b>374.22 T67a</p></div>
</div><!-- cierro fila -->


<div class="row">
<div class="col s12 m3" align="center"><div class="material-placeholder"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554325335.jpg" class="materialboxed initialized" data-caption="Algebra lineal y programación lineal con aplicaciones a ciencias administrativas, contables y financieras, con uso de Derive, Q.S.B y Excel" width="80%"></div></div>
      <div class="col s12 m9"><!-- abro fila -->
<p><b>Título:</b><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=13423&amp;query_desc=kw%2Cwrdl%3A%20Algebra%20lineal%20y%20programaci%C3%B3n%20lineal%20con%20aplicaciones%20a%20ciencias%20administrativas%2C%20contables%20y%20financieras%2C%20con%20uso%20de%20Derive%2C%20Q.S.B%20y%20Excel%20Francisco%20Soler%20Fajardo%2C%20Fabio%20Molina%20Focazzio%2C%20Lucio%20Rojas%20Cort%C3%A9s" target="_blank"> Algebra lineal y programación lineal con aplicaciones a ciencias administrativas, contables y financieras, con uso de Derive, Q.S.B y Excel </a></p>
<p><b>Autor:</b> Francisco Soler Fajardo.  </p>
<p><b>Editorial, Año:</b> ECOE Ediciones, 2016</p>
<p><b>Temas:</b> IALGEBRA -- PROBLEMAS, EJERCICIOS, ETC. |  PROGRAMACIÓN LINEAL | MATRICES (ALGEBRA) | TEORÍA DE LOS JUEGOS | CADENA DE MARKOVDE   </p>
<p><b>Solicítelo como:</b>512.5 S65a1</p></div>
</div><!-- cierro fila -->


<div class="row">
<div class="col s12 m3" align="center"><div class="material-placeholder"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554325345.jpg" class="materialboxed initialized" data-caption="Análisis crítico de la reforma  tributaria : Ley 1819 de 2016" width="80%"></div></div>
      <div class="col s12 m9"><!-- abro fila -->
<p><b>Título:</b><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=14650" target="_blank"> Análisis crítico de la reforma  tributaria : Ley 1819 de 2016 </a></p>
<p><b>Autor:</b> Julio Roberto Piza Rodríguez  </p>
<p><b>Editorial, Año:</b> Universidad Externado de Colombia, 2017</p>
<p><b>Temas:</b> DERECHO FISCAL - COLOMBIA | IMPUESTOS - LEGISLACIÓN | COLOMBIA | REFORMAS TRIBUTARIAS - COLOMBIA | PROCEDIMIENTO TRIBUTARIO - COLOMBIA | SANCIONES TRIBUTARIAS - COLOMBIA  </p>
<p><b>Solicítelo como:</b>512.5 S65a1</p></div>
</div><!-- cierro fila -->


<div class="row">
<div class="col s12 m3" align="center"><div class="material-placeholder"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554325355.jpg" class="materialboxed initialized" data-caption="Aproximación a la codificación procesal constitucional" width="80%"></div></div>
      <div class="col s12 m9"><!-- abro fila -->
<p><b>Título:</b><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=12267 " target="_blank"> Aproximación a la codificación procesal constitucional </a></p>
<p><b>Autor:</b> Rene Moreno Alfonso  </p>
<p><b>Editorial, Año:</b> Corporación Universitaria Republicana, Ediciones Nueva Jurídica, 2017</p>
<p><b>Temas:</b> ESTRUCTURA DEL ESTADO COLOMBIANO | EMPRESAS ESTATALES - COLOMBIA | MINISTERIOS - COLOMBIA | COLOMBIA - ADMINISTRACION PUBLICA - ASPECTOS ECONOMICOS  </p>
<p><b>Solicítelo como:</b>347.05 M67a</p></div>
</div><!-- cierro fila -->


<div class="row">
<div class="col s12 m3" align="center"><div class="material-placeholder"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554325370.jpg" class="materialboxed initialized" data-caption="Cálculo en una variable" width="80%"></div></div>
      <div class="col s12 m9"><!-- abro fila -->
<p><b>Título:</b><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=13376" target="_blank"> Cálculo en una variable </a></p>
<p><b>Autor:</b> Venancio Tomeo Perucha, Isaías Uña Juárez y Jesús San Martín Moreno  </p>
<p><b>Editorial, Año:</b> Alfaomega Grupo Editor, 2017.</p>
<p><b>Temas:</b> CÁLCULO | ANÁLISIS MARTEMÁTICO - PROBLEMAS, EJERCICIOS, ETC.  </p>
<p><b>Solicítelo como:</b>515 T65c</p></div>
</div><!-- cierro fila -->


<div class="row">
<div class="col s12 m3" align="center"><div class="material-placeholder"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554325385.jpg" class="materialboxed initialized" data-caption="Acuerdo comercial entre Colombia, Perú y la Unión Europea contenido, análisis y aplicación" width="80%"></div></div>
      <div class="col s12 m9"><!-- abro fila -->
<p><b>Título:</b><a href="" target="_blank"> Acuerdo comercial entre Colombia, Perú y la Unión Europea contenido, análisis y aplicación </a></p>
<p><b>Autor:</b> Juan Carlos Agudelo Calderón, Juan David Barbosa Mariño, Helena Camargo Williamson, etc. </p>
<p><b>Editorial, Año:</b> Grupo Editorial Ibáñez, 2015</p>
<p><b>Temas:</b> ARBITRAMIENTO COMERCIAL – COLOMBIA | TRATADOS COMERCIALES - COLOMBIA | INTEGRACIÓN ECONÓMICA   </p>
<p><b>Solicítelo como:</b>303.66 A28</p></div>
</div><!-- cierro fila -->


<div class="row">
<div class="col s12 m3" align="center"><div class="material-placeholder"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554325398.jpg" class="materialboxed initialized" data-caption="Administración financiera internacional" width="80%"></div></div>
      <div class="col s12 m9"><!-- abro fila -->
<p><b>Título:</b><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=1590&amp;query_desc=kw%2Cwrdl%3A%20Administraci%C3%B3n%20financiera%20internacional%20Jeff%20Madura" target="_blank"> Administración financiera internacional </a></p>
<p><b>Autor:</b> JJeff Madura. </p>
<p><b>Editorial, Año:</b> México: Cengge Learning, 2015</p>
<p><b>Temas:</b> EMPRESAS INTERNACIONALES - FINANZAS | FINANZAS INTERNACIONALES | TASA DE CAMBIO | ADMINISTRACION DE ACTIVO-PASIVO  </p>
<p><b>Solicítelo como:</b>658.159 M12a</p></div>
</div><!-- cierro fila -->

		  
		  
		</div>
    </li>
    
	
	
<!-- Revistas -->

<li class="active">
      <div class="collapsible-header"><i class="material-icons">chrome_reader_mode</i>Revistas</div>
      <div class="collapsible-body">

		  
		  
		  <div class="col s12 m12"><h4 align="center"><b>Boletín de Nuevas Adquisiciones / Marzo de 2019</b></h4></div>
<div class="col s12 m12"><h4 align="center"><b>Revistas</b></h4></div>
		  
		  
		  <!-- Derecho penal contemporaneo -->
		  
<div class="row"> <!-- abro fila -->
<div class="col s12 m12">
      <div class="card horizontal"> <!-- abro card horizontal -->
      <div class="card-image"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554397970.jpg" style="width:80% !important"></div>
		  
<div class="card-stacked">
        <div class="card-content">
          <p><b>Derecho Penal Contemporáneo / LEGIS Editores</b></p>
			<p>No. 66,  enero-marzo 2019</p>
          </div>
        <div class="card-action"> <!-- abro card action -->
         	
		
 <ul class="collapsible">
    <li>
      <div class="collapsible-header"><i class="material-icons">import_contacts</i>Contenido</div>
      <div class="collapsible-body">
      <p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15079&amp;query_desc=kw%2Cwrdl%3A%20EL%20RENACIMIENTO%20DEL%20PENSAMIENTO"><em>El renacimiento del pensamiento kantiano como fundamento del castigo y su efecto en la creación "absoluto" de las víctimas al castigo de los culpables</em></a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15081&amp;query_desc=kw%2Cwrdl%3A%20aCERCA%20DEL%20OBJETO"><em>Acerca del objeto y la tarea de la ciencia del derecho penal</em></a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15086&amp;query_desc=kw%2Cwrdl%3A%20Excusas%20absolutarias%20y%20condiciones"><em>Excusas absolutorias y condiciones objetivas de punibilidad</em></a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15087&amp;query_desc=kw%2Cwrdl%3A%20el%20analisis%20forense"><em>El análisis forense de los accidentes de tránsito: el perito y el informe pericial</em></a></p>

</div>
    </li>

</ul>   

    </div> <!-- cierro card action -->
     </div> 

</div> <!-- cierro card horizontal -->
    </div>
		  </div> <!-- cierro fila -->
	
	
		  
		  
		  <!-- Contabilidad y Auditoría -->
		  
		  <div class="row"> <!-- abro fila -->
<div class="col s12 m12">
      <div class="card horizontal"> <!-- abro card horizontal -->
      <div class="card-image"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554408746.jpg" style="width:80% !important"></div>
		  
<div class="card-stacked">
        <div class="card-content">
          <p><b>Contabilidad y Auditoría / LEGIS Editores</b></p>
			<p>No. 77, enero-marzo 2019</p>
          </div>
        <div class="card-action"> <!-- abro card action -->
         
<ul class="collapsible">
	<li>
      <div class="collapsible-header"><i class="material-icons">import_contacts</i>Contenido</div>
      <div class="collapsible-body">
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15083&amp;query_desc=kw%2Cwrdl%3A%20la%20formacion%20tecnica%20y">La formación técnica y tecnológica en áreas contables en Colombia</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15095&amp;query_desc=kw%2Cwrdl%3A%20aplicaci%C3%B3n%20de%20la%20niif%2016%20legis">Aplicación de la NIIF 16. Identificación de un arrendamiento</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15110">El auditor de sistemas al servicio de la revisoría Fiscal. generalidades sobre la auditoría de sistemas</a></p>
		</div>
	</li>
	</ul>    

    </div> <!-- cierro card action -->
		  </div> 
	</div> <!-- cierro card horizontal -->
			  </div>
		  </div> <!-- cierro fila -->
		  
		  
		  
		  
		  
		  	  <!-- Manual del Contador -->
		  
		  <div class="row"> <!-- abro fila -->
<div class="col s12 m12">
      <div class="card horizontal"> <!-- abro card horizontal -->
      <div class="card-image"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554408887.jpg" style="width:80% !important"></div>
		  
<div class="card-stacked">
        <div class="card-content">
          <p><b>Manual del Contador / Ediciones Gerenciales </b></p>
			<p>No 399, diciembre de 2018</p>
          </div>
        <div class="card-action"> <!-- abro card action -->
         
<ul class="collapsible">
	<li>
		<div class="collapsible-header"><i class="material-icons">import_contacts</i>Contenido</div>
      <div class="collapsible-body">
		<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15282">Reforma Tributaria 2018 : estructura e impacto a corto plazo</a></p>
		</div>
	</li>
		</ul>    

    </div> <!-- cierro card action -->
		  </div> 
	</div> <!-- cierro card horizontal -->
			  </div>
		  </div> <!-- cierro fila -->
	
		  
		  
		  
		  
		   <!-- Actualidad Laboral y Seguridad Social -->
		  
		  <div class="row"> <!-- abro fila -->
<div class="col s12 m12">
      <div class="card horizontal"> <!-- abro card horizontal -->
      <div class="card-image"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554408925.jpg" style="width:80% !important"></div>
		  
<div class="card-stacked">
        <div class="card-content">
          <p><b>Actualidad Laboral y Seguridad Social / LEGIS Editores</b></p>
			<p>No. 211, enero-febrero de 2019</p>
          </div>
        <div class="card-action"> <!-- abro card action -->
         
<ul class="collapsible">
	<li>
		<div class="collapsible-header"><i class="material-icons">import_contacts</i>Contenido</div>
      <div class="collapsible-body">
		<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15135">La ética de la compasión: ¿Mecanismo para aumentar el compromiso de los empleados?</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15138&amp;query_desc=kw%2Cwrdl%3A%20visi%C3%B3n%20colombiana%20del%20centenario">Visión colombiana del centenario de la OIT</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15141">Fútbol y derecho del trabajo: pasado, presente y futuro</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15143">El derecho a la fertilidad: un estado de la discusión en la jurisprudencia constitucional</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15142&amp;query_desc=kw%2Cwrdl%3A%20la%20normativa%20laboral%20ha%20estado">La normativa laboral ha estado más preocupada de la crisis económica que de la revolución tecnológica</a></p>
	<p><a href="C:UsersUsuario CURDocumentsREPUBLICANAARCHIVO 2019BoletinesImplementación del Registro Único de Trabajadores Extranjeros">Implementación del Registro Único de Trabajadores Extranjeros "RUTEC"</a></p>
	</div>
			</li>
	</ul>    

    </div> <!-- cierro card action -->
		  </div> 
	</div> <!-- cierro card horizontal -->
			  </div>
		  </div> <!-- cierro fila -->
		 
		  
		  
		  
		  
		  
		     <!-- Jurisprudencia y Doctrina -->
		  
		  <div class="row"> <!-- abro fila -->
<div class="col s12 m12">
      <div class="card horizontal"> <!-- abro card horizontal -->
      <div class="card-image"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554409075.jpg" style="width:80% !important"></div>
		  
<div class="card-stacked">
        <div class="card-content">
          <p><b>Jurisprudencia y Doctrina / LEGIS Editores</b></p>
			<p>Tomo XLVIII – No. 566, febrero de 2019</p>
          </div>
        <div class="card-action"> <!-- abro card action -->
         
<ul class="collapsible">
	<li>
		<div class="collapsible-header"><i class="material-icons">import_contacts</i>Contenido parcial</div>
      <div class="collapsible-body">
		<p><a href="#">Corte Suprema de Justicia: terminación de contrato laboral e incapacidad mayor a 180 días</a></p>
	<p><a href="#">Consejo de Estado: entidad que define el registro catastral y el impuesto predial</a></p>
	<p><a href="#">Corte Constitucional: excepciones al régimen de relación de créditos</a></p>
	</div>
			</li>
		</ul>    

    </div> <!-- cierro card action -->
		  </div> 
	</div> <!-- cierro card horizontal -->
			  </div>
		  </div> <!-- cierro fila -->
		  
		  
		  
		  
		  
		  
		  
		  	     <!-- La Nota Económica -->
		  
		  <div class="row"> <!-- abro fila -->
<div class="col s12 m12">
      <div class="card horizontal"> <!-- abro card horizontal -->
      <div class="card-image"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554409237.jpg" style="width:80% !important"></div>
		  
<div class="card-stacked">
        <div class="card-content">
          <p><b>La Nota Económica,</b></p>
			<p>Febrero de 2019</p>
			<p>Colombia Regional Bicentenario</p>
          </div>
        <div class="card-action"> <!-- abro card action -->
         
<ul class="collapsible">
	<li>
		<div class="collapsible-header"><i class="material-icons">import_contacts</i>Contenido parcial</div>
      <div class="collapsible-body">
		<p><a href="#">Las trabas de la descentralización en Colombia</a></p>
	<p><a href="#">“Es fundamental que el crecimiento económico sea más inclusivo”</a></p>
	<p><a href="#">Blockchain: el camino para la innovación empresarial</a></p>
	<p><a href="#">Una mirada internacional al salario mínimo diferencial</a></p>
	</div>
			</li>

		</ul>    

    </div> <!-- cierro card action -->
		  </div> 
	</div> <!-- cierro card horizontal -->
			  </div>
		  </div> <!-- cierro fila -->
		  
		  
		  
		  
		  
		  
		  
		  	  	     <!-- Foro de Derecho Mercantil -->
		  
		  <div class="row"> <!-- abro fila -->
<div class="col s12 m12">
      <div class="card horizontal"> <!-- abro card horizontal -->
      <div class="card-image"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554409259.jpg" style="width:80% !important"></div>
		  
<div class="card-stacked">
        <div class="card-content">
          <p><b>Foro de Derecho Mercantil / LEGIS Editores</b></p>
			<p>No. 62, enero-marzo de 2019</p>
	</div>
        <div class="card-action"> <!-- abro card action -->
         
<ul class="collapsible">
	<li>
		<div class="collapsible-header"><i class="material-icons">import_contacts</i>Contenido</div>
      <div class="collapsible-body">
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15066">La simplificación de la constitución societaria en España</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15071&amp;query_desc=kw%2Cwrdl%3A%20puede%20la%20fiducia">¿ Puede la fiducia reemplazar a la SAS ?</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15072&amp;query_desc=kw%2Cwrdl%3A%20el%20abuso%20de%20posicion%20dominante">El abuso de posición dominante (algunas reflexiones sobre el interés económico general)</a></p>
		</div>
	</li>
			</ul>    

    </div> <!-- cierro card action -->
		  </div> 
	</div> <!-- cierro card horizontal -->
			  </div>
		  </div> <!-- cierro fila -->
		  
		  
		  
		  
		  
		  	  	  	     <!-- Revista de Logística  -->
		  
		  <div class="row"> <!-- abro fila -->
<div class="col s12 m12">
      <div class="card horizontal"> <!-- abro card horizontal -->
      <div class="card-image"><img src="https://urepublicana.edu.co/images/noticias_eventos/galeria/1554409273.jpg" style="width:80% !important"></div>
		  
<div class="card-stacked">
        <div class="card-content">
          <p><b>Revista de Logística / LEGIS Editores</b></p>
			<p>No. 43, noviembre de 2018 – enero de  2019</p>
	</div>
        <div class="card-action"> <!-- abro card action -->
         
<ul class="collapsible">
	<li>
		<div class="collapsible-header"><i class="material-icons">import_contacts</i>Contenido parcial</div>
      <div class="collapsible-body">
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15394">Plantas eléctricas: practicidad, tecnología y servicio</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15395&amp;query_desc=ti%2Cwrdl%3A%20tecnolog%C3%ADa%205g">Tecnología 5G: todo lo que necesitas para entenderla</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15396">Avanzará China en su apertura comercial y apoyará la globalización económica de otros países?</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15399">Esferificación y ecologística: dígale no al plástico en el mar</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15400">Biocarbón, una alternativa para aprovechar los residuos de las zonas francas</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15401&amp;query_desc=ti%2Cwrdl%3A%20el%20cambio%20climatico">El cambio climático y el transporte marítimo global</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15402">Por pasarelas de moda más sustentables</a></p>
		  <p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15403&amp;query_desc=ti%2Cwrdl%3A%20digitalizaci%C3%B3n">•	Digitalización: 5 pasos para optimizar su empresa</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15404">Bioempaques: camino de transformación</a></p>
		  <p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15405">Envases inteligentes: claves en la industria de alimentos y bebidas</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15409">ERP a toda máquina</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15409">SMR: el CRM para proveedores</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15416&amp;query_desc=ti%2Cwrdl%3A%20c%C3%B3mo%20escoger%20bodega">Cómo escoger mi bodega?</a></p>
		  <p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15417">Carrocerías: carga liviana para el transporte pesado</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15418">Importaciones y exportaciones de las pymes en América Latina</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15419&amp;query_desc=ti%2Cwrdl%3A%20la%20analitica">La analítica: pienso luego existo</a></p>
	<p><a href="http://republicana.redbiblio.net/cgi-bin/koha/opac-detail.pl?biblionumber=15420">Sistemas logísticos colaborativos</a></p>
		</div>
	</li>
			</ul>    

    </div> <!-- cierro card action -->
		  </div> 
	</div> <!-- cierro card horizontal -->
			  </div>
		  </div> <!-- cierro fila -->
		  
		  
		  
		  
		  
		  
		  
	</div>	
	
	</li>
   

<!-- Trabajos de grado -->


 <li>
      <div class="collapsible-header"><i class="material-icons">list_alt</i>Trabajos de grado</div>
      <div class="collapsible-body"><iframe class="video" src="https://urepublicana.edu.co/images/web/biblioteca/Nuevas-Adquisiciones-Tesis.pdf" style="height:900px;"></iframe></div>
    </li>
  </ul>




				</div>	
			</div>
		</div>
	</div>				
	<div class="footer-copyright">
  <div class="container">
   <div class="row">
    <div class="col s12 m3 l3 center-align">
      <img src="//urepublicana.edu.co/images/web/footer/1521576084.png" class="logo_footer"><br>
      <i class="contacto" style="background-color: transparent;">
        Iesus Christus hanc dat fructum. Gloria in sancta Trinitate. Et providere nos, misericordem gloriam Dei vivi       </i>
    </div>
    <div class="col s12 m9 l9">
      <div class="row center-align">
        
<a target="_blank" href="https://www.facebook.com/CorporacionUniversitariaRepublicana/" ><img src="//urepublicana.edu.co/images/web/footer/facebook.png" class="social_urep"></a>

<a target="_blank" href="https://twitter.com/URepublicana_?lang=en" ><img src="//urepublicana.edu.co/images/web/footer/twitter.png" class="social_urep"></a>

<a target="_blank" href="https://www.instagram.com/urepublicana/" ><img src="//urepublicana.edu.co/images/web/footer/instagram.png" class="social_urep"></a>

<a target="_blank" href="https://www.youtube.com/channel/UC38BS2DLRSwXvnS_6QnS5Zg" ><img src="//urepublicana.edu.co/images/web/footer/youtube.png" class="social_urep"></a>

<a target="_blank" href="https://www.linkedin.com/in/corporaci%C3%B3n-universitaria-republicana-6bb35110b" ><img src="//urepublicana.edu.co/images/web/footer/linkedin.png" class="social_urep"></a>


<!-- <a target="_blank" href="https://api.whatsapp.com/send?phone=573057498050"><img src="//urepublicana.edu.co/images/web/footer/whatsapp.png" class="social_urep"></a> -->
      </div>
      <div class="left-align row enlaces_urep">
       <div class="col s12 m6 l4">
        <ul>
                        <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/1649868637.pdf">Ley de Protección de datos</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="http://urepublicana.edu.co/trabaje_con_nosotros/">Trabaje con Nosotros</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/pages/publicaciones/principal/noticia/codigos_para_consignacion">Listado Códigos de Consignaciones</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/iberoamericana/pages/publicaciones/Institucion/0/nosotros">Convenio Corporación Iberoamericana de Estudios Jurídicos</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/1674235905.pdf">Protocolo para la prevención y atención de casos de violencia y equidad de género</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/images/documentos/footer/directorio_institucional.pdf">Directorio Institucional</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                              <li><a target="_blank" href="https://urepublicana.edu.co/pages/ccaac/">Centro de Conciliación, Arbitraje y Amigable Composición</a> </li>
                            </ul>
            </div>
            <div class="col s12 m6 l4">
              <ul>
                        </ul>
      </div>
    </div>
  </div>
</div>
</div>
<div class="row center-align contacto">
 Institución de Educación Superior Sujeta a Inspección y Vigilancia por el Ministerio de Educación Nacional, con Personería jurídica reconocida mediante resolución No 3061 del 02 de diciembre de 1999, expedida por el Ministerio de Educación Nacional.<br>  Sede Administrativa: Cr 7 No 19-38 | Horario de atención. lunes a viernes de 8:00 a.m a 8:00 p.m, Sábados:9:00 a.m a 1:00 p.m <br>  PBX: 286 23 84 | Información Admisiones: ext. 143 | www.urepublicana.edu.co <br>  Bogotá, Colombia</div>
<div class="center-align legal">
 &copy; Corporación Universitaria Republicana 2017
</div>
<!-- <script src="http://code.jquery.com/jquery-2.1.4.min.js"></script> -->
<!-- <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script> -->
<script src="//urepublicana.edu.co/assets/js/bootstrap-colorpicker.js"></script>
<script src="//urepublicana.edu.co/assets/js/docs.js"></script>
<!-- VALIDACION -->
<!-- <script src="//urepublicana.edu.co/assets/js/jquery.validate.min.js"></script> -->

<!-- JQUERY VALIDATE -->
<script type="text/javascript" src="//urepublicana.edu.co/assets/js/validation/dist/jquery.validate.min.js"></script>
<script src="//urepublicana.edu.co/assets/js/materialize.min.js"></script>
<script src="//urepublicana.edu.co/assets/js/init.js"></script>
<script type="text/javascript">
  function downloadJSAtOnload() {
    var element = document.createElement("script");
    element.src = "https://www.google.com/recaptcha/api.js";
    document.body.appendChild(element);
  }
  if (window.addEventListener)
    window.addEventListener("load", downloadJSAtOnload, false);
  else if (window.attachEvent)
    window.attachEvent("onload", downloadJSAtOnload);
  else window.onload = downloadJSAtOnload;
</script>




<script type="text/javascript" charset="utf-8">

	function correctCaptcha(){
     	$('button.btn_captcha').removeAttr("disabled");
    }
    
	$(document).ready(function(){
		$('button.btn_captcha').attr("disabled","disabled");
		
	// parametros( ids - separados por comas )
	var mostrar = function(ids) {
		var id = ids.split(',');
		jQuery.each( id, function( i, val ) {
			$("#cont_"+val).addClass("mostrar").removeClass("ocultar");
			$("#"+val).addClass("mostrar").removeClass("ocultar");
		});
	};


	// parametros(destino, consulta, valor);
	var cargar_valores = function(clase, metodo, valores) {
		var formData = {clase:clase,metodo:metodo,valores:valores};
		var url = "//urepublicana.edu.co/admin/class/class_metodos_form.php"; // El script a dónde se realizará la petición.
		$.ajax({
		type: "POST",
		url: url,
		async: false,
		data: formData,
			success: function(data){
			valores = jQuery.parseJSON(data);
			}
		});
		return valores;
	};

	// CARGAR VALIDACION INICIAL
	$( "#").validate( {
		rules: {
		//fin de la prueba de validación
		},
		errorElement : 'div',
		errorPlacement: function(error, element) {
			var placement = $(element).data('error');
			if (placement) {
				$(placement).append(error)
			} else {
				error.insertAfter(element);
			}
		}
	});
});
</script>
</body>
</html>
		
